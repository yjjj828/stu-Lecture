package org.stu.stulecture.entity;

import java.time.LocalDateTime;

/**
 * 场地实体类
 * 对应数据库venues表
 */
public class Venue {
    private Long venueId;       // 场地ID
    private String name;        // 场地名称
    private Integer capacity;   // 容纳人数
    private String location;    // 位置
    private Integer status;     // 状态：1 可用 0 维护
    private LocalDateTime createdTime; // 创建时间
    private LocalDateTime updatedTime; // 更新时间
    
    // 构造函数
    public Venue() {}
    
    public Venue(String name, Integer capacity, String location) {
        this.name = name;
        this.capacity = capacity;
        this.location = location;
        this.status = 1;
    }
    
    // Getter和Setter方法
    public Long getVenueId() { return venueId; }
    public void setVenueId(Long venueId) { this.venueId = venueId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    
    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }
    
    public LocalDateTime getCreatedTime() { return createdTime; }
    public void setCreatedTime(LocalDateTime createdTime) { this.createdTime = createdTime; }
    
    public LocalDateTime getUpdatedTime() { return updatedTime; }
    public void setUpdatedTime(LocalDateTime updatedTime) { this.updatedTime = updatedTime; }
    
    // 获取状态描述
    public String getStatusDescription() {
        return status == 1 ? "可用" : "维护中";
    }
    
    // 判断是否可用
    public boolean isAvailable() {
        return status == 1;
    }
    
    @Override
    public String toString() {
        return "Venue{" +
                "venueId=" + venueId +
                ", name='" + name + '\'' +
                ", capacity=" + capacity +
                ", location='" + location + '\'' +
                ", status=" + status +
                ", createdTime=" + createdTime +
                ", updatedTime=" + updatedTime +
                '}';
    }
}