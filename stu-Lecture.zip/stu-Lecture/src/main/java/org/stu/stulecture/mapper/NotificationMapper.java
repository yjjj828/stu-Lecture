package org.stu.stulecture.mapper;

import org.apache.ibatis.annotations.*;
import org.stu.stulecture.entity.Notification;

import java.util.List;

/**
 * 通知 Mapper 接口
 */
@Mapper
public interface NotificationMapper {
    
    /**
     * 插入通知
     */
    @Insert("INSERT INTO notifications (title, content, type, receiver_id, sender_id, status) " +
            "VALUES (#{title}, #{content}, #{type}, #{receiverId}, #{senderId}, #{status})")
    @Options(useGeneratedKeys = true, keyProperty = "notificationId")
    int insert(Notification notification);
    
    /**
     * 批量插入通知
     */
    @Insert("<script>INSERT INTO notifications (title, content, type, receiver_id, sender_id, status) VALUES " +
            "<foreach collection='notifications' item='notification' separator=','>" +
            "(#{notification.title}, #{notification.content}, #{notification.type}, " +
            "#{notification.receiverId}, #{notification.senderId}, 'unread')" +
            "</foreach></script>")
    int batchInsert(@Param("notifications") List<Notification> notifications);
    
    /**
     * 根据 ID 查询通知
     */
    @Select("SELECT * FROM notifications WHERE notification_id = #{notificationId}")
    @Results({
        @Result(property = "notificationId", column = "notification_id"),
        @Result(property = "title", column = "title"),
        @Result(property = "content", column = "content"),
        @Result(property = "type", column = "type"),
        @Result(property = "receiverId", column = "receiver_id"),
        @Result(property = "senderId", column = "sender_id"),
        @Result(property = "status", column = "status"),
        @Result(property = "sendTime", column = "send_time"),
        @Result(property = "readTime", column = "read_time")
    })
    Notification findById(Long notificationId);
    
    /**
     * 分页查询用户的通知列表
     */
    @Select("SELECT n.*, u.name as receiver_name " +
            "FROM notifications n " +
            "LEFT JOIN users u ON n.receiver_id = u.user_id " +
            "WHERE n.receiver_id = #{userId} " +
            "ORDER BY n.send_time DESC " +
            "LIMIT #{offset}, #{pageSize}")
    @Results({
        @Result(property = "notificationId", column = "notification_id"),
        @Result(property = "title", column = "title"),
        @Result(property = "content", column = "content"),
        @Result(property = "type", column = "type"),
        @Result(property = "receiverId", column = "receiver_id"),
        @Result(property = "receiverName", column = "receiver_name"),
        @Result(property = "status", column = "status"),
        @Result(property = "sendTime", column = "send_time")
    })
    List<Notification> findByUserId(@Param("userId") Long userId, 
                                   @Param("offset") Integer offset, 
                                   @Param("pageSize") Integer pageSize);
    
    /**
     * 统计用户的通知数量
     */
    @Select("SELECT COUNT(*) FROM notifications WHERE receiver_id = #{userId}")
    int countByUserId(@Param("userId") Long userId);
    
    /**
     * 统计用户的未读通知数量
     */
    @Select("SELECT COUNT(*) FROM notifications WHERE receiver_id = #{userId} AND status = 'unread'")
    int countUnread(@Param("userId") Long userId);
    
    /**
     * 标记为已读
     */
    @Update("UPDATE notifications SET status = 'read', read_time = NOW() WHERE notification_id = #{notificationId}")
    int markAsRead(@Param("notificationId") Long notificationId);
    
    /**
     * 批量标记为已读（用户所有未读通知）
     */
    @Update("UPDATE notifications SET status = 'read', read_time = NOW() WHERE receiver_id = #{userId} AND status = 'unread'")
    int markAllAsRead(@Param("userId") Long userId);
    
    /**
     * 删除通知（物理删除）
     */
    @Delete("DELETE FROM notifications WHERE notification_id = #{notificationId}")
    int deleteById(@Param("notificationId") Long notificationId);
    
    /**
     * 批量删除通知（物理删除）
     */
    @Delete("<script>" +
            "DELETE FROM notifications WHERE notification_id IN " +
            "<foreach item='id' collection='ids' open='(' separator=',' close=')'>#{id}</foreach>" +
            "</script>")
    int batchDelete(@Param("ids") List<Long> ids);
    
    /**
     * 清理过期无用通知（可选的维护操作）
     */
    @Delete("DELETE FROM notifications WHERE status = 'read' AND send_time < DATE_SUB(NOW(), INTERVAL 30 DAY)")
    int cleanExpiredNotifications();
    
    /**
     * 查询所有通知（管理员用）
     */
    @Select("SELECT n.*, u.name as receiver_name, s.name as sender_name " +
            "FROM notifications n " +
            "LEFT JOIN users u ON n.receiver_id = u.user_id " +
            "LEFT JOIN users s ON n.sender_id = s.user_id " +
            "ORDER BY n.send_time DESC " +
            "LIMIT #{offset}, #{pageSize}")
    @Results({
        @Result(property = "notificationId", column = "notification_id"),
        @Result(property = "title", column = "title"),
        @Result(property = "content", column = "content"),
        @Result(property = "type", column = "type"),
        @Result(property = "receiverId", column = "receiver_id"),
        @Result(property = "receiverName", column = "receiver_name"),
        @Result(property = "senderId", column = "sender_id"),
        @Result(property = "senderName", column = "sender_name"),
        @Result(property = "status", column = "status"),
        @Result(property = "sendTime", column = "send_time")
    })
    List<Notification> findAll(@Param("offset") Integer offset, @Param("pageSize") Integer pageSize);
    
    /**
     * 统计所有通知数量
     */
    @Select("SELECT COUNT(*) FROM notifications")
    int countAll();
    
    /**
     * 根据类型查询通知
     */
    @Select("SELECT n.*, u.name as receiver_name, s.name as sender_name " +
            "FROM notifications n " +
            "LEFT JOIN users u ON n.receiver_id = u.user_id " +
            "LEFT JOIN users s ON n.sender_id = s.user_id " +
            "WHERE n.type = #{type} " +
            "ORDER BY n.send_time DESC " +
            "LIMIT #{offset}, #{pageSize}")
    List<Notification> findByType(@Param("type") String type, 
                                  @Param("offset") Integer offset, 
                                  @Param("pageSize") Integer pageSize);
    
    /**
     * 统计某类型的通知数量
     */
    @Select("SELECT COUNT(*) FROM notifications WHERE type = #{type}")
    int countByType(@Param("type") String type);
    
    /**
     * 按接收人搜索通知
     */
    @Select("SELECT n.*, u.name as receiver_name, s.name as sender_name " +
            "FROM notifications n " +
            "LEFT JOIN users u ON n.receiver_id = u.user_id " +
            "LEFT JOIN users s ON n.sender_id = s.user_id " +
            "WHERE u.name LIKE CONCAT('%', #{receiver}, '%') " +
            "ORDER BY n.send_time DESC " +
            "LIMIT #{offset}, #{pageSize}")
    List<Notification> findByReceiver(@Param("receiver") String receiver, 
                                      @Param("offset") Integer offset, 
                                      @Param("pageSize") Integer pageSize);
    
    /**
     * 统计按接收人搜索的通知数量
     */
    @Select("SELECT COUNT(*) FROM notifications n " +
            "LEFT JOIN users u ON n.receiver_id = u.user_id " +
            "WHERE u.name LIKE CONCAT('%', #{receiver}, '%')")
    int countByReceiver(@Param("receiver") String receiver);
    
    /**
     * 按类型和接收人搜索通知
     */
    @Select("SELECT n.*, u.name as receiver_name, s.name as sender_name " +
            "FROM notifications n " +
            "LEFT JOIN users u ON n.receiver_id = u.user_id " +
            "LEFT JOIN users s ON n.sender_id = s.user_id " +
            "WHERE n.type = #{type} AND u.name LIKE CONCAT('%', #{receiver}, '%') " +
            "ORDER BY n.send_time DESC " +
            "LIMIT #{offset}, #{pageSize}")
    List<Notification> findByTypeAndReceiver(@Param("type") String type, 
                                             @Param("receiver") String receiver, 
                                             @Param("offset") Integer offset, 
                                             @Param("pageSize") Integer pageSize);
    
    /**
     * 统计按类型和接收人搜索的通知数量
     */
    @Select("SELECT COUNT(*) FROM notifications n " +
            "LEFT JOIN users u ON n.receiver_id = u.user_id " +
            "WHERE n.type = #{type} AND u.name LIKE CONCAT('%', #{receiver}, '%')")
    int countByTypeAndReceiver(@Param("type") String type, @Param("receiver") String receiver);
}
