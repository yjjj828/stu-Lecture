package org.stu.stulecture.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.service.UserService;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * 记住我自动登录拦截器
 */
@Component
public class RememberMeInterceptor implements HandlerInterceptor {

    @Autowired
    private UserService userService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // 已登录则跳过
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("currentUser") != null) {
            return true;
        }

        // 检查 rememberMe Cookie
        User user = userService.checkRememberMe(request);
        if (user != null) {
            HttpSession newSession = request.getSession(true);
            newSession.setAttribute("currentUser", user);
            newSession.setAttribute("userRole", user.getRole());
        }

        return true;
    }
}
