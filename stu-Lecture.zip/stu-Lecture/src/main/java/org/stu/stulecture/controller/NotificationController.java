package org.stu.stulecture.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.stu.stulecture.entity.Notification;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.service.NotificationService;
import org.stu.stulecture.mapper.NotificationMapper;
import org.stu.stulecture.util.PageInfo;

import jakarta.servlet.http.HttpSession;

/**
 * 通知控制器
 */
@Controller
@RequestMapping("/notification")
public class NotificationController {
    
    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private NotificationMapper notificationMapper;
    
    /**
     * 通知列表页面
     */
    @GetMapping("/list")
    public String notificationList(
            HttpSession session,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            Model model) {
        
        User user = (User) session.getAttribute("currentUser");
        if (user == null) {
            return "redirect:/user/login";
        }
        
        PageInfo<Notification> pageInfo = notificationService.getUserNotifications(
            user.getUserId(), pageNum, pageSize);
        
        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("user", user);
        model.addAttribute("pageTitle", "我的通知");
        
        return "notification/list";
    }
    
    /**
     * 标记为已读
     */
    @PostMapping("/mark-read/{id}")
    public String markAsRead(@PathVariable Long id, HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        
        if (user == null) {
            return "redirect:/user/login";
        }
        
        try {
            notificationService.markAsRead(id);
        } catch (Exception e) {
            // 忽略异常，继续跳转
        }
        
        // 重定向回通知列表页
        return "redirect:/notification/list";
    }
    
    /**
     * 全部标记为已读
     */
    @PostMapping("/mark-all-read")
    public String markAllAsRead(HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        
        if (user == null) {
            return "redirect:/user/login";
        }
        
        try {
            notificationService.markAllAsRead(user.getUserId());
        } catch (Exception e) {
            // 忽略异常，继续跳转
        }
        
        // 重定向回通知列表页
        return "redirect:/notification/list";
    }
    
    /**
     * 删除通知
     */
    @GetMapping("/delete/{id}")
    public String deleteNotification(@PathVariable Long id, HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        if (user == null) {
            return "redirect:/user/login";
        }
        
        notificationService.deleteNotification(id, user.getUserId());
        
        return "redirect:/notification/list";
    }
    
    /**
     * 通知详情页面
     */
    @GetMapping("/detail/{id}")
    public String notificationDetail(@PathVariable Long id, HttpSession session, Model model) {
        User user = (User) session.getAttribute("currentUser");
        if (user == null) {
            return "redirect:/user/login";
        }
        
        // 获取通知详情
        Notification notification = notificationService.getNotificationById(id);
        if (notification == null || !notification.getReceiverId().equals(user.getUserId())) {
            return "redirect:/notification/list";
        }
        
        // 如果是未读通知，自动标记为已读
        if ("unread".equals(notification.getStatus())) {
            notificationService.markAsRead(id);
            notification.setStatus("read");
        }
        
        model.addAttribute("notification", notification);
        model.addAttribute("user", user);
        model.addAttribute("pageTitle", "通知详情");
        
        return "notification/detail";
    }
    
    /**
     * 批量删除通知
     */
    @PostMapping("/batch-delete")
    public String batchDeleteNotifications(@RequestParam String ids, HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        if (user == null) {
            return "redirect:/user/login";
        }
        
        try {
            // 解析逗号分隔的 ID 字符串
            String[] idArray = ids.split(",");
            java.util.List<Long> idList = new java.util.ArrayList<>();
            for (String idStr : idArray) {
                Long notificationId = Long.parseLong(idStr.trim());
                idList.add(notificationId);
            }
            
            // 使用 Mapper 的批量删除方法
            notificationMapper.batchDelete(idList);
        } catch (Exception e) {
            // 忽略异常
        }
        
        return "redirect:/notification/list";
    }
    
    /**
     * 批量标记为已读
     */
    @PostMapping("/batch-mark-read")
    public String batchMarkAsRead(@RequestParam String ids, HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        if (user == null) {
            return "redirect:/user/login";
        }
        
        try {
            // 解析逗号分隔的 ID 字符串
            String[] idArray = ids.split(",");
            for (String idStr : idArray) {
                Long notificationId = Long.parseLong(idStr.trim());
                notificationService.markAsRead(notificationId);
            }
        } catch (Exception e) {
            // 忽略异常
        }
        
        return "redirect:/notification/list";
    }
}
