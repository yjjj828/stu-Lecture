package org.stu.stulecture.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.stu.stulecture.entity.Notification;
import org.stu.stulecture.mapper.NotificationMapper;
import org.stu.stulecture.util.PageInfo;
import org.stu.stulecture.entity.NotificationTemplate;
import org.stu.stulecture.mapper.NotificationTemplateMapper;
import org.stu.stulecture.entity.OperationLog;
import org.stu.stulecture.mapper.OperationLogMapper;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.mapper.UserMapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 通知业务逻辑处理
 */
@Service
public class NotificationService {
    
    @Autowired
    private NotificationMapper notificationMapper;
    
    @Autowired
    private NotificationTemplateMapper notificationTemplateMapper;
    
    @Autowired
    private OperationLogMapper operationLogMapper;
    
    @Autowired
    private UserMapper userMapper;
    
    /**
     * 显示用户名：账号+姓名
     */
    private String formatUserName(Long userId) {
        if (userId == null) {
            return "系统";
        }
        User user = userMapper.findById(userId);
        if (user == null) {
            return "用户 ID:" + userId;
        }
        if (user.getName() != null && !user.getName().isEmpty()) {
            return user.getUsername() + "（" + user.getName() + "）";
        }
        return user.getUsername();
    }
    
    /**
     * 发送单条通知
     */
    @Transactional
    public boolean sendNotification(String title, String content, String type, 
                                   Long receiverId, Long senderId) {
        try {
            Notification notification = new Notification(title, content, type, receiverId, senderId);
            int result = notificationMapper.insert(notification);
            
            if (result > 0) {
                String receiverName = receiverId == null ? "所有用户" : formatUserName(receiverId);
                OperationLog log = new OperationLog(senderId, formatUserName(senderId), 
                    "发送通知", "通知管理", 
                    "发送通知【" + title + "】给 " + receiverName);
                operationLogMapper.insert(log);
                return true;
            }
            return false;
        } catch (Exception e) {
            throw new RuntimeException("发送通知失败：" + e.getMessage());
        }
    }
    
    /**
     * 批量群发通知
     */
    @Transactional
    public boolean batchSendNotification(List<Long> receiverIds, String title, 
                                        String content, String type, Long senderId) {
        try {
            List<Notification> notifications = receiverIds.stream()
                .map(userId -> new Notification(title, content, type, userId, senderId))
                .collect(Collectors.toList());
            
            int result = notificationMapper.batchInsert(notifications);
            
            if (result > 0) {
                OperationLog log = new OperationLog(senderId, formatUserName(senderId), 
                    "群发通知", "通知管理", 
                    "群发通知【" + title + "】给 " + receiverIds.size() + " 个用户");
                operationLogMapper.insert(log);
                return true;
            }
            return false;
        } catch (Exception e) {
            throw new RuntimeException("批量发送通知失败：" + e.getMessage());
        }
    }
    
    /**
     * 分页查询用户通知
     */
    public PageInfo<Notification> getUserNotifications(Long userId, int pageNum, int pageSize) {
        int offset = (pageNum - 1) * pageSize;
        List<Notification> notifications = notificationMapper.findByUserId(userId, offset, pageSize);
        int total = notificationMapper.countByUserId(userId);
        return new PageInfo<>(notifications, pageNum, pageSize, total);
    }
    
    /**
     * 统计未读数量
     */
    public int getUnreadCount(Long userId) {
        return notificationMapper.countUnread(userId);
    }
    
    /**
     * 标记为已读
     */
    @Transactional
    public boolean markAsRead(Long notificationId) {
        return notificationMapper.markAsRead(notificationId) > 0;
    }
    
    /**
     * 全部标记已读
     */
    @Transactional
    public boolean markAllAsRead(Long userId) {
        return notificationMapper.markAllAsRead(userId) > 0;
    }
    
    /**
     * 删除通知（记录日志）
     */
    @Transactional
    public boolean deleteNotification(Long notificationId, Long operatorId) {
        Notification notification = getNotificationById(notificationId);
        int result = notificationMapper.deleteById(notificationId);
        
        if (result > 0) {
            String receiverName = formatUserName(notification.getReceiverId());
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "删除通知", "通知管理", 
                "删除了 [" + notification.getTitle() + "] 通知（接收人：" + receiverName + "）");
            operationLogMapper.insert(log);
            return true;
        }
        return false;
    }
    
    /**
     * 按ID查询通知
     */
    public Notification getNotificationById(Long notificationId) {
        return notificationMapper.findById(notificationId);
    }
    
    /**
     * 使用模板发送通知
     */
    @Transactional
    public boolean sendTemplateNotification(String scene, Map<String, String> variables, 
                                           Long receiverId, Long senderId) {
        try {
            NotificationTemplate template = notificationTemplateMapper.findByScene(scene);
            
            String title;
            String content;
            
            if (template != null) {
                title = replaceTemplateVariables(template.getTitleTemplate(), variables);
                content = replaceTemplateVariables(template.getContentTemplate(), variables);
            } else {
                title = variables.getOrDefault("title", generateDefaultTitle(scene));
                content = variables.getOrDefault("content", generateDefaultContent(scene, variables));
            }
            
            // 从 scene 提取类型，如果有模板则使用模板的类型
            String type;
            if (template != null) {
                type = template.getType();
            } else {
                type = scene.contains(".") ? scene.split("\\.")[0] : "reminder";
            }
            
            Notification notification = new Notification(title, content, type, receiverId, senderId);
            notification.setStatus("unread");
            
            int result = notificationMapper.insert(notification);
            return result > 0;
        } catch (Exception e) {
            throw new RuntimeException("发送模板通知失败：" + e.getMessage());
        }
    }
    
    /**
     * 替换模板中的变量
     */
    private String replaceTemplateVariables(String template, Map<String, String> variables) {
        if (template == null || template.isEmpty()) {
            return "";
        }
        
        String result = template;
        for (Map.Entry<String, String> entry : variables.entrySet()) {
            String key = "{" + entry.getKey() + "}";
            String value = entry.getValue();
            result = result.replace(key, value);
        }
        return result;
    }
    
    /**
     * 根据场景生成默认标题
     */
    private String generateDefaultTitle(String scene) {
        switch (scene) {
            case "lecture.audit_approved":
                return "讲座审核通过通知";
            case "lecture.audit_rejected":
                return "讲座审核未通过通知";
            case "reservation.reservation_success":
                return "预约成功通知";
            case "reservation.reservation_cancelled":
                return "预约取消通知";
            case "lecture.lecture_cancelled":
                return "讲座取消通知";
            default:
                return "系统通知";
        }
    }
    
    /**
     * 根据场景和变量生成默认内容
     */
    private String generateDefaultContent(String scene, Map<String, String> variables) {
        StringBuilder content = new StringBuilder();
        
        switch (scene) {
            case "lecture.audit_approved":
                content.append("您的讲座《").append(variables.getOrDefault("lectureTitle", "未知讲座"));
                content.append("》已通过审核，感谢您的提交！");
                break;
            case "lecture.audit_rejected":
                content.append("很抱歉，您的讲座《").append(variables.getOrDefault("lectureTitle", "未知讲座"));
                content.append("》未通过审核。");
                if (variables.containsKey("rejectReason")) {
                    content.append("\n原因：").append(variables.get("rejectReason"));
                }
                content.append("请联系管理员了解详情。");
                break;
            case "reservation.reservation_success":
                content.append("恭喜您已成功预约讲座《").append(variables.getOrDefault("lectureTitle", "未知讲座"));
                content.append("》。\n");
                if (variables.containsKey("lectureTime")) {
                    content.append("时间：").append(variables.get("lectureTime")).append("\n");
                }
                if (variables.containsKey("location")) {
                    content.append("地点：").append(variables.get("location"));
                }
                content.append("\n请准时参加！");
                break;
            case "reservation.reservation_cancelled":
                content.append("您预约的讲座《").append(variables.getOrDefault("lectureTitle", "未知讲座"));
                content.append("》已被取消。\n");
                if (variables.containsKey("reason")) {
                    content.append("原因：").append(variables.get("reason"));
                }
                break;
            case "lecture.lecture_cancelled":
                content.append("很抱歉，您预约的讲座《").append(variables.getOrDefault("lectureTitle", "未知讲座"));
                content.append("》已被取消。\n");
                if (variables.containsKey("reason")) {
                    content.append("原因：").append(variables.get("reason"));
                }
                break;
            case "lecture.full":
                content.append("恭喜！您的讲座《").append(variables.getOrDefault("lectureTitle", "未知讲座"));
                content.append("》预约人数已满（").append(variables.getOrDefault("capacity", "0")).append("人）。");
                content.append("\n感谢您的精彩分享！");
                break;
            case "lecture.changed":
                content.append("您关注的讲座《").append(variables.getOrDefault("lectureTitle", "未知讲座"));
                content.append("》信息发生变更，请相互转告，准时参加！");
                break;
            case "lecture.cancelled_by_admin":
                content.append("很抱歉，讲座《").append(variables.getOrDefault("lectureTitle", "未知讲座"));
                content.append("》已被管理员取消。请相互转告，给您带来不便，深表歉意！");
                break;
            default:
                content.append("这是一条系统通知，请注意查看。");
        }
        
        return content.toString();
    }
    
    /**
     * 发送讲座审核通知
     */
    public void sendAuditResultNotification(Long lectureId, String lectureTitle, 
                                           Long speakerId, boolean approved, 
                                           String rejectReason, Long adminId,
                                           String lectureTime, String location) {
        Map<String, String> variables = new HashMap<>();
        variables.put("lectureTitle", lectureTitle);
        if (!approved) {
            variables.put("rejectReason", rejectReason != null ? rejectReason : "未通过审核");
        }
        // 添加时间和地点信息
        variables.put("lectureTime", lectureTime != null ? lectureTime : "待定");
        variables.put("location", location != null ? location : "待定");
        
        String scene = approved ? "lecture.audit_approved" : "lecture.audit_rejected";
        sendTemplateNotification(scene, variables, speakerId, adminId);
    }
    
    /**
     * 发送预约成功通知
     */
    public void sendReservationSuccessNotification(Long lectureId, String lectureTitle, 
                                                   String lectureTime, String location, 
                                                   Long userId) {
        Map<String, String> variables = new HashMap<>();
        variables.put("lectureTitle", lectureTitle);
        variables.put("lectureTime", lectureTime);
        variables.put("location", location);
        
        sendTemplateNotification("reservation.reservation_success", variables, userId, null);
    }
    
    /**
     * 发送预约取消通知
     */
    public void sendReservationCancelledNotification(Long lectureId, String lectureTitle, 
                                                     Long userId) {
        Map<String, String> variables = new HashMap<>();
        variables.put("lectureTitle", lectureTitle);
        variables.put("reason", "讲座已被删除或取消");
        
        sendTemplateNotification("reservation.reservation_cancelled", variables, userId, null);
    }
    
    /**
     * 发送预约满员通知（给讲座发布人）
     */
    public void sendFullNotification(Long lectureId, String lectureTitle, Long speakerId) {
        Map<String, String> variables = new HashMap<>();
        variables.put("lectureTitle", lectureTitle);
        variables.put("capacity", "已满");
        
        sendTemplateNotification("lecture.full", variables, speakerId, null);
    }
    
    /**
     * 发送讲座变更通知（时间/地点变更）
     */
    public void sendLectureChangedNotification(Long lectureId, String lectureTitle,
                                                String oldTime, String newTime,
                                                String oldLocation, String newLocation,
                                                String changeReason,
                                                Long receiverId, Long senderId) {
        Map<String, String> variables = new HashMap<>();
        variables.put("lectureTitle", lectureTitle);
        variables.put("oldTime", oldTime != null ? oldTime : "原时间");
        variables.put("newTime", newTime != null ? newTime : "新时间");
        variables.put("oldLocation", oldLocation != null ? oldLocation : "原地点");
        variables.put("newLocation", newLocation != null ? newLocation : "新地点");
        variables.put("changeReason", changeReason != null ? changeReason : "原因不详");
        
        sendTemplateNotification("lecture.changed", variables, receiverId, senderId);
    }
    
    /**
     * 发送讲座取消通知（给发布人和所有预约用户）
     */
    public void sendLectureCancelledNotificationToAll(Long lectureId, String lectureTitle,
                                                       Long speakerId, List<Long> reservedUserIds) {
        Map<String, String> variables = new HashMap<>();
        variables.put("lectureTitle", lectureTitle);
        variables.put("reason", "很抱歉，该讲座已被取消");
        
        // 通知发布人
        sendTemplateNotification("lecture.cancelled_by_admin", variables, speakerId, null);
        
        // 通知所有预约用户
        for (Long userId : reservedUserIds) {
            sendTemplateNotification("lecture.cancelled_by_admin", variables, userId, null);
        }
    }
    
    /**
     * 发送讲座变更通知给所有人
     */
    public void sendLectureChangedNotificationToAll(Long lectureId, String lectureTitle,
                                                     String oldTime, String newTime,
                                                     String oldLocation, String newLocation,
                                                     String changeReason,
                                                     Long speakerId, List<Long> reservedUserIds) {
        // 通知发布人
        sendLectureChangedNotification(lectureId, lectureTitle, oldTime, newTime,
                                       oldLocation, newLocation, changeReason,
                                       speakerId, null);
        
        // 通知所有预约用户
        for (Long userId : reservedUserIds) {
            sendLectureChangedNotification(lectureId, lectureTitle, oldTime, newTime,
                                          oldLocation, newLocation, changeReason,
                                          userId, null);
        }
    }
    
    /**
     * 获取所有通知模板
     */
    public List<NotificationTemplate> getAllTemplates() {
        return notificationTemplateMapper.findAll();
    }
    
    /**
     * 根据 ID 获取模板
     */
    public NotificationTemplate getTemplateById(Long templateId) {
        return notificationTemplateMapper.findById(templateId);
    }
    
    /**
     * 更新模板
     */
    @Transactional
    public boolean updateTemplate(NotificationTemplate template, Long operatorId) {
        try {
            template.setUpdatedTime(java.time.LocalDateTime.now());
            int result = notificationTemplateMapper.update(template);
            
            if (result > 0) {
                // 记录操作日志
                String enabledDesc = template.getIsEnabled() == 1 ? "启用" : "禁用";
                OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                    "编辑通知模板", "通知管理", 
                    "更新通知模板 [" + template.getTemplateName() + "]（" + enabledDesc + "）");
                operationLogMapper.insert(log);
                return true;
            }
            return false;
        } catch (Exception e) {
            throw new RuntimeException("更新模板失败：" + e.getMessage());
        }
    }
    
    /**
     * 搜索通知（管理员用）
     */
    public PageInfo<Notification> searchNotifications(String type, String receiver, int pageNum, int pageSize) {
        int offset = (pageNum - 1) * pageSize;
        List<Notification> notifications;
        int total;
        
        if (type != null && !type.isEmpty() && receiver != null && !receiver.isEmpty()) {
            // 同时按类型和接收人搜索
            notifications = notificationMapper.findByTypeAndReceiver(type, receiver, offset, pageSize);
            total = notificationMapper.countByTypeAndReceiver(type, receiver);
        } else if (type != null && !type.isEmpty()) {
            // 只按类型搜索
            notifications = notificationMapper.findByType(type, offset, pageSize);
            total = notificationMapper.countByType(type);
        } else if (receiver != null && !receiver.isEmpty()) {
            // 只按接收人搜索
            notifications = notificationMapper.findByReceiver(receiver, offset, pageSize);
            total = notificationMapper.countByReceiver(receiver);
        } else {
            // 查询所有
            notifications = notificationMapper.findAll(offset, pageSize);
            total = notificationMapper.countAll();
        }
        
        return new PageInfo<>(notifications, pageNum, pageSize, total);
    }
    
    /**
     * 统计某类型的通知数量
     */
    public int countByType(String type) {
        return notificationMapper.countByType(type);
    }
}
