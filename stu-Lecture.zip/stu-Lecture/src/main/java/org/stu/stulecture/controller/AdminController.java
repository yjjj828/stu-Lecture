package org.stu.stulecture.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.entity.OperationLog;
import org.stu.stulecture.entity.Venue;
import org.stu.stulecture.entity.Lecture;
import org.stu.stulecture.entity.Notification;
import org.stu.stulecture.entity.NotificationTemplate;
import org.stu.stulecture.entity.Reservation;
import org.stu.stulecture.service.AdminUserService;
import org.stu.stulecture.service.VenueService;
import org.stu.stulecture.service.LectureService;
import org.stu.stulecture.service.ReservationService;
import org.stu.stulecture.service.NotificationService;
import org.stu.stulecture.util.PageInfo;
import org.stu.stulecture.util.ExcelUtil;
import org.stu.stulecture.util.FileUploadUtil;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.ByteArrayInputStream;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

/**
 * 管理员控制器
 * 处理管理员相关功能请求
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminUserService adminUserService;
    
    @Autowired
    private VenueService venueService;
    
    @Autowired
    private LectureService lectureService;
    
    @Autowired
    private ReservationService reservationService;
    
    @Autowired
    private NotificationService notificationService;

    /**
     * 讲座管理页面（支持分页）
     */
    @GetMapping("/lectures/manage")
    public String manageLectures(
             @RequestParam(required = false) String title,
             @RequestParam(required = false) String speaker,
             @RequestParam(required = false) String status,
             @RequestParam(defaultValue = "1") Integer pageNum,
             @RequestParam(defaultValue = "10") Integer pageSize,
             HttpSession session,
             Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "讲座管理");

        // 分页查询讲座列表
        PageInfo<Lecture> pageInfo = lectureService.searchLecturesByPage(title, speaker, status, pageNum, pageSize);
        
        model.addAttribute("lectures", pageInfo.getList());
        model.addAttribute("lectureCount", pageInfo.getTotal());
        model.addAttribute("pageInfo", pageInfo);
          
        // 回传筛选条件
        model.addAttribute("searchTitle", title);
        model.addAttribute("searchSpeaker", speaker);
        model.addAttribute("currentStatus", status);
        model.addAttribute("pageNum", pageNum);
        model.addAttribute("pageSize", pageSize);
          
        // 统计各状态讲座数量
        model.addAttribute("pendingCount", lectureService.getLectureCountByStatus("pending"));
        model.addAttribute("approvedCount", lectureService.getLectureCountByStatus("approved"));
        model.addAttribute("expiredCount", lectureService.getLectureCountByStatus("expired"));

        return "admin/lecture-management";
    }

    /**
     * 删除讲座（GET 请求）
     */
    @GetMapping("/lectures/delete/{lectureId}")
    public String deleteLecture(@PathVariable Long lectureId, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        try {
            Lecture lecture = lectureService.getLectureById(lectureId);
            if (lecture == null) {
                return "redirect:/admin/lectures/manage?error=" + 
                       java.net.URLEncoder.encode("讲座不存在", java.nio.charset.StandardCharsets.UTF_8);
            }
            
            boolean success = lectureService.deleteLecture(lectureId, currentUser.getUserId(), currentUser.getName());
            
            if (success) {
                return "redirect:/admin/lectures/manage?success=" + 
                       java.net.URLEncoder.encode("讲座已删除", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/lectures/manage?error=" + 
                       java.net.URLEncoder.encode("删除失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/lectures/manage?error=" + 
                   java.net.URLEncoder.encode("操作失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }
    
    /**
     * 批量删除讲座
     */
    @PostMapping("/lectures/batch-delete")
    public String batchDeleteLectures(@RequestParam String ids, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
        
        try {
            String[] idArray = ids.split(",");
            for (String id : idArray) {
                try {
                    Long lectureId = Long.parseLong(id.trim());
                    lectureService.deleteLecture(lectureId, currentUser.getUserId(), currentUser.getName());
                } catch (Exception e) {
                    // 跳过删除失败的记录
                }
            }
            return "redirect:/admin/lectures/manage";
        } catch (Exception e) {
            return "redirect:/admin/lectures/manage";
        }
    }
    
    /**
     * 编辑讲座页面
     */
    @GetMapping("/lectures/edit/{lectureId}")
    public String editLecturePage(@PathVariable Long lectureId, HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        Lecture lecture = lectureService.getLectureById(lectureId);
        if (lecture == null) {
            return "redirect:/admin/lectures/manage?error=" + 
                   java.net.URLEncoder.encode("讲座不存在", java.nio.charset.StandardCharsets.UTF_8);
        }

        // 获取所有场地列表（包括维护中的）
        List<Venue> venues = venueService.getAllVenues();

        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "编辑讲座");
        model.addAttribute("lecture", lecture);
        model.addAttribute("venues", venues);
        
        // 添加状态描述和形式描述（模板需要）
        model.addAttribute("statusDesc", lectureService.getStatusDescription(lecture.getStatus()));
        model.addAttribute("formatDesc", lectureService.getFormatDescription(lecture.getFormat()));
        
        // 格式化讲座时间为 datetime-local 格式
        if (lecture.getLectureTime() != null) {
            model.addAttribute("formattedLectureTime", 
                lecture.getLectureTime().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm")));
        } else {
            model.addAttribute("formattedLectureTime", "");
        }

        return "admin/lecture-edit";
    }
    
    /**
     * 保存讲座编辑
     */
    @PostMapping("/lectures/edit/{lectureId}")
    public String editLectureSubmit(@PathVariable Long lectureId,
                                    @RequestParam String title,
                                    @RequestParam String description,
                                    @RequestParam String lectureTime,
                                    @RequestParam Long venueId,
                                    @RequestParam Integer duration,
                                    @RequestParam Integer capacity,
                                    @RequestParam String category,
                                    @RequestParam String format,
                                    @RequestParam(required = false) String notice,
                                    @RequestParam String status,
                                    @RequestParam(required = false) org.springframework.web.multipart.MultipartFile poster,
                                    HttpSession session,
                                    Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        try {
            Lecture lecture = lectureService.getLectureById(lectureId);
            if (lecture == null) {
                return "redirect:/admin/lectures/manage?error=" + 
                       java.net.URLEncoder.encode("讲座不存在", java.nio.charset.StandardCharsets.UTF_8);
            }
            
            // 获取场地信息以填充 location
            Venue venue = venueService.getVenueById(venueId);
            if (venue == null) {
                return "redirect:/admin/lectures/edit/" + lectureId + "?error=" + 
                       java.net.URLEncoder.encode("场地不存在", java.nio.charset.StandardCharsets.UTF_8);
            }
            
            // 更新讲座信息
            lecture.setTitle(title);
            lecture.setDescription(description);
            // 解析并更新时间
            if (lectureTime != null && !lectureTime.isEmpty()) {
                try {
                    java.time.LocalDateTime newTime = java.time.LocalDateTime.parse(lectureTime);
                    lecture.setLectureTime(newTime);
                } catch (Exception e) {
                    return "redirect:/admin/lectures/edit/" + lectureId + "?error=" + 
                           java.net.URLEncoder.encode("时间格式错误", java.nio.charset.StandardCharsets.UTF_8);
                }
            }
            lecture.setLocation(venue.getLocation()); // 使用场地的 location
            lecture.setVenueId(venueId); // 设置场地 ID
            lecture.setDuration(duration);
            lecture.setCapacity(capacity);
            lecture.setCategory(category);
            lecture.setFormat(format); // 设置讲座形式
            lecture.setNotice(notice); // 设置注意事项
            lecture.setStatus(status); // 设置讲座状态
            
            // 处理海报上传
            if (poster != null && !poster.isEmpty()) {
                try {
                    // 删除旧海报
                    if (lecture.getPoster() != null && !lecture.getPoster().isEmpty()) {
                        String oldPosterPath = "src/main/resources/static/poster/" + lecture.getPoster();
                        java.io.File oldFile = new java.io.File(oldPosterPath);
                        if (oldFile.exists()) {
                            oldFile.delete();
                        }
                    }
                    
                    // 上传新海报
                    String posterFilename = FileUploadUtil.uploadFile(poster, "src/main/resources/static/poster");
                    lecture.setPoster(posterFilename);
                } catch (Exception e) {
                    return "redirect:/admin/lectures/edit/" + lectureId + "?error=" + 
                           java.net.URLEncoder.encode("海报上传失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
                }
            }
            
            boolean success = lectureService.updateLecture(lecture, currentUser.getUserId(), currentUser.getName());
            
            if (success) {
                return "redirect:/admin/lectures/manage?success=" + 
                       java.net.URLEncoder.encode("讲座信息已更新", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/lectures/edit/" + lectureId + "?error=" + 
                       java.net.URLEncoder.encode("更新失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/lectures/edit/" + lectureId + "?error=" + 
                   java.net.URLEncoder.encode("操作失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }

    /**
     * 审核讲座（通过/拒绝）- 表单提交模式
     * 拒绝时会删除讲座并发送通知
     */
    @PostMapping("/lectures/review/{lectureId}")
    public String reviewLecture(@PathVariable Long lectureId,
                                 @RequestParam String action,
                                 @RequestParam(required = false) String rejectReason,
                                 HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        try {
            if ("approve".equals(action)) {
                // 通过审核
                boolean success = lectureService.updateLectureStatus(lectureId, "approved", currentUser.getUserId(), currentUser.getName(), null);
                if (success) {
                    return "redirect:/admin/lectures/manage?success=" + java.net.URLEncoder.encode("审核通过", java.nio.charset.StandardCharsets.UTF_8);
                } else {
                    return "redirect:/admin/lectures/manage?error=" + java.net.URLEncoder.encode("审核操作失败", java.nio.charset.StandardCharsets.UTF_8);
                }
            } else {
                // 拒绝审核 - 删除讲座并发送未通过通知
                Lecture lecture = lectureService.getLectureById(lectureId);
                if (lecture == null) {
                    return "redirect:/admin/lectures/manage?error=" + java.net.URLEncoder.encode("讲座不存在", java.nio.charset.StandardCharsets.UTF_8);
                }
                
                // 发送审核未通过通知（只发送这个）
                notificationService.sendAuditResultNotification(
                    lectureId, 
                    lecture.getTitle(), 
                    lecture.getSpeakerId(), 
                    false, 
                    rejectReason, 
                    currentUser.getUserId(),
                    lecture.getLectureTime() != null ? lecture.getLectureTime().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "待定",
                    lecture.getLocation() != null ? lecture.getLocation() : "待定"
                );
                
                // 删除讲座（不发送取消通知，因为已经发送了未通过审核通知）
                boolean success = lectureService.deleteLectureWithoutNotification(lectureId, currentUser.getUserId(), currentUser.getName());
                if (success) {
                    return "redirect:/admin/lectures/manage?success=" + java.net.URLEncoder.encode("审核拒绝，讲座已删除", java.nio.charset.StandardCharsets.UTF_8);
                } else {
                    return "redirect:/admin/lectures/manage?error=" + java.net.URLEncoder.encode("操作失败", java.nio.charset.StandardCharsets.UTF_8);
                }
            }
        } catch (Exception e) {
            return "redirect:/admin/lectures/manage?error=" + java.net.URLEncoder.encode("操作异常，请稍后重试", java.nio.charset.StandardCharsets.UTF_8);
        }
    }

    /**
     * 管理员首页
     */
    @GetMapping("/dashboard")
    public String adminDashboard(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        // 获取未读通知数量
        int unreadCount = notificationService.getUnreadCount(currentUser.getUserId());
        model.addAttribute("unreadCount", unreadCount);
        
        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "管理后台");

        // 获取用户统计数据
        AdminUserService.UserStatistics stats = adminUserService.getUserStatistics();
        model.addAttribute("userStats", stats);
        
        // 获取讲座统计数据
        model.addAttribute("lectureCount", lectureService.getTotalLectureCount());
        model.addAttribute("pendingCount", lectureService.getLectureCountByStatus("pending"));
        model.addAttribute("approvedCount", lectureService.getLectureCountByStatus("approved"));
        
        // 获取今日预约数量（简化实现：统计所有 confirmed 状态的预约）
        model.addAttribute("todayReservationCount", reservationService.getReservationsByStatus("confirmed").size());
        
        // 获取待审核讲座列表（最新 5 条）
        List<Lecture> pendingLectures = lectureService.getLecturesByStatus("pending").stream()
                .limit(5)
                .toList();
        model.addAttribute("pendingLectures", pendingLectures);
        
        // 获取所有用户（用于发送通知）
        List<User> allUsers = adminUserService.getAllUsers();
        model.addAttribute("allUsers", allUsers);

        return "admin/dashboard";
    }

    /**
     * 用户管理页面
     */
    @GetMapping("/users")
    public String userManagement(
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String role,
            @RequestParam(required = false) Integer status,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            HttpSession session,
            Model model) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "用户管理");

        // 分页查询用户列表
        PageInfo<User> pageInfo = adminUserService.searchUsersByPage(username, role, status, pageNum, pageSize);
        
        model.addAttribute("users", pageInfo.getList());
        model.addAttribute("userCount", pageInfo.getTotal());
        model.addAttribute("pageInfo", pageInfo);
        
        // 获取统计数据
        model.addAttribute("totalUsers", adminUserService.getTotalUserCount());
        model.addAttribute("teacherCount", adminUserService.getUserCountByRole("teacher"));
        model.addAttribute("studentCount", adminUserService.getUserCountByRole("student"));
        model.addAttribute("disabledCount", adminUserService.getUserCountByStatus(-1)); // 禁用
        model.addAttribute("inactiveCount", adminUserService.getUserCountByStatus(0)); // 未激活

        // 回传筛选条件
        model.addAttribute("searchUsername", username);
        model.addAttribute("searchRole", role);
        model.addAttribute("searchStatus", status);
        model.addAttribute("pageNum", pageNum);
        model.addAttribute("pageSize", pageSize);

        // 角色选项
        model.addAttribute("roles", new String[]{"admin", "teacher", "student"});
        // 状态选项
        Map<Integer, String> statusMap = new HashMap<>();
        statusMap.put(0, "未激活");
        statusMap.put(1, "启用");
        statusMap.put(-1, "禁用");
        model.addAttribute("statusOptions", statusMap);

        return "admin/user-management";
    }

    /**
     * 操作日志页面（支持分页）
     */
    @GetMapping("/logs")
    public String logManagement(
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String operation,
            @RequestParam(required = false) String module,
            @RequestParam(required = false) String logDate,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            HttpSession session,
            Model model) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "操作日志");

        // 分页查询操作日志
        PageInfo<OperationLog> pageInfo = adminUserService.searchOperationLogsByPage(
            username, operation, module, logDate, pageNum, pageSize);
        
        model.addAttribute("logs", pageInfo.getList());
        model.addAttribute("logCount", pageInfo.getTotal());
        model.addAttribute("pageInfo", pageInfo);

        // 回传筛选条件
        model.addAttribute("searchUsername", username);
        model.addAttribute("searchOperation", operation);
        model.addAttribute("searchModule", module);
        model.addAttribute("logDate", logDate);
        model.addAttribute("pageNum", pageNum);
        model.addAttribute("pageSize", pageSize);

        return "admin/log-management";
    }
    
    /**
     * 导出操作日志为 Excel 文件
     */
    @GetMapping("/logs/export")
    public ResponseEntity<byte[]> exportLogs(
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String operation,
            @RequestParam(required = false) String module,
            @RequestParam(required = false) String logDate,
            HttpSession session) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        try {
            // 空字符串转为 null
            String u = (username == null || username.trim().isEmpty()) ? null : username.trim();
            String o = (operation == null || operation.trim().isEmpty()) ? null : operation.trim();
            String m = (module == null || module.trim().isEmpty()) ? null : module.trim();
            String d = (logDate == null || logDate.trim().isEmpty()) ? null : logDate.trim();
            
            // 获取所有符合条件的日志（不分页）
            List<OperationLog> logs = adminUserService.searchOperationLogs(u, o, m, d);
            
            // 导出为 Excel
            byte[] bytes = ExcelUtil.exportOperationLogs(logs);
            
            // 记录操作日志
            adminUserService.logExportLogs(logs.size(), currentUser.getUserId());
            
            // 设置响应头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            String filename = java.net.URLEncoder.encode("操作日志_" + System.currentTimeMillis() + ".xlsx", "UTF-8");
            headers.setContentDispositionFormData("attachment", filename);
            
            return new ResponseEntity<>(bytes, headers, HttpStatus.OK);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 更新用户信息（模态框表单提交）
     */
    @PostMapping("/users/update")
    public String updateUser(@RequestParam Long userId,
                            @RequestParam String username,
                            @RequestParam String name,
                            @RequestParam String role,
                            @RequestParam Integer status,
                            @RequestParam(required = false) String department,
                            @RequestParam(required = false) String email,
                            @RequestParam(required = false) String phone,
                            @RequestParam(required = false) String position,
                            @RequestParam(required = false) String major,
                            @RequestParam(required = false) String grade,
                            HttpSession session) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        try {
            User userToUpdate = new User();
            userToUpdate.setUserId(userId);
            userToUpdate.setUsername(username);
            userToUpdate.setName(name);
            userToUpdate.setRole(role);
            userToUpdate.setStatus(status);
            userToUpdate.setDepartment(department);
            userToUpdate.setEmail(email);
            userToUpdate.setPhone(phone);
            userToUpdate.setPosition(position);
            userToUpdate.setMajor(major);
            userToUpdate.setGrade(grade);
            
            boolean success = adminUserService.updateUser(userToUpdate, currentUser.getUserId(), currentUser.getUsername());
            
            return success ? "redirect:/admin/users?success=" + java.net.URLEncoder.encode("用户信息更新成功", java.nio.charset.StandardCharsets.UTF_8) : "redirect:/admin/users?error=" + java.net.URLEncoder.encode("更新失败", java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "redirect:/admin/users?error=" + java.net.URLEncoder.encode("操作失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }

    /**
     * 重置用户密码
     */
    @GetMapping("/users/reset-password/{userId}")
    public String resetUserPassword(@PathVariable Long userId, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        try {
            boolean success = adminUserService.resetUserPassword(userId, currentUser.getUserId(), currentUser.getUsername());
            if (success) {
                return "redirect:/admin/users?success=" + 
                       java.net.URLEncoder.encode("密码重置成功，默认密码为：123456", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/users?error=" + 
                       java.net.URLEncoder.encode("密码重置失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/users?error=" + 
                   java.net.URLEncoder.encode("操作失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }
    
    /**
     * 删除用户
     */
    @GetMapping("/users/delete/{userId}")
    public String deleteUser(@PathVariable Long userId, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
        
        try {
            boolean success = adminUserService.deleteUser(userId, currentUser.getUserId(), currentUser.getUsername());
            if (success) {
                return "redirect:/admin/users?success=" + 
                       java.net.URLEncoder.encode("用户删除成功", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/users?error=" + 
                       java.net.URLEncoder.encode("用户删除失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/users?error=" + 
                   java.net.URLEncoder.encode("操作失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }
        
    /**
     * 启用用户 - 表单提交模式
     */
    @PostMapping("/users/enable/{userId}")
    public String enableUser(@PathVariable Long userId, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
    
        try {
            boolean success = adminUserService.enableUser(userId, currentUser.getUserId(), currentUser.getUsername());
            if (success) {
                return "redirect:/admin/users?success=" + java.net.URLEncoder.encode("用户已启用", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/users?error=" + java.net.URLEncoder.encode("启用失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/users?error=" + java.net.URLEncoder.encode("操作异常", java.nio.charset.StandardCharsets.UTF_8);
        }
    }
    
    /**
     * 禁用用户 - 表单提交模式
     */
    @PostMapping("/users/disable/{userId}")
    public String disableUser(@PathVariable Long userId, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
    
        try {
            boolean success = adminUserService.disableUser(userId, currentUser.getUserId(), currentUser.getUsername());
            if (success) {
                return "redirect:/admin/users?success=" + java.net.URLEncoder.encode("用户已禁用", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/users?error=" + java.net.URLEncoder.encode("禁用失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/users?error=" + java.net.URLEncoder.encode("操作异常", java.nio.charset.StandardCharsets.UTF_8);
        }
    }
    
    /**
     * 变更用户角色 - 表单提交模式
     */
    @PostMapping("/users/change-role/{userId}")
    public String changeUserRole(@PathVariable Long userId,
                                  @RequestParam String newRole,
                                  HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
    
        try {
            boolean success = adminUserService.changeUserRole(userId, newRole, currentUser.getUserId(), currentUser.getUsername());
            if (success) {
                return "redirect:/admin/users?success=" + java.net.URLEncoder.encode("角色变更成功", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/users?error=" + java.net.URLEncoder.encode("角色变更失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/users?error=" + java.net.URLEncoder.encode("操作异常", java.nio.charset.StandardCharsets.UTF_8);
        }
    }
    
    /**
     * 添加用户（管理员添加，默认未激活）
     */
    @PostMapping("/users/add")
    public String addUser(@RequestParam String username,
                          @RequestParam String password,
                          @RequestParam String name,
                          @RequestParam String role,
                          @RequestParam(required = false) String email,
                          @RequestParam(required = false) String department,
                          HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
            
        try {
            boolean success = adminUserService.addUser(username, password, name, role, email, department, 
                                                       currentUser.getUserId(), currentUser.getUsername());
            if (success) {
                return "redirect:/admin/users?success=" + java.net.URLEncoder.encode("用户添加成功", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/users?error=" + java.net.URLEncoder.encode("添加失败，用户名可能已存在", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/users?error=" + java.net.URLEncoder.encode("操作异常：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }
    
    /**
     * 批量删除用户
     */
    @PostMapping("/users/batch-delete")
    public String batchDeleteUsers(@RequestParam String ids, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
            
        try {
            String[] idArray = ids.split(",");
            for (String id : idArray) {
                try {
                    Long userId = Long.parseLong(id.trim());
                    adminUserService.deleteUser(userId, currentUser.getUserId(), currentUser.getUsername());
                } catch (Exception e) {
                    // 跳过删除失败的记录
                }
            }
            return "redirect:/admin/users?success=" + 
                   java.net.URLEncoder.encode("批量删除成功", java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "redirect:/admin/users?error=" + 
                   java.net.URLEncoder.encode("操作失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }
    
    /**
     * 清理操作日志（GET 方式）
     */
    @GetMapping("/logs/clean")
    public String cleanLogsForm(@RequestParam String beforeDate, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        try {
            LocalDateTime beforeTime = LocalDateTime.parse(beforeDate + "T00:00:00");
            int deletedCount = adminUserService.cleanOldLogs(beforeTime, currentUser.getUserId(), currentUser.getUsername());
            return "redirect:/admin/logs?success=" + 
                   java.net.URLEncoder.encode("日志清理成功，共删除 " + deletedCount + " 条记录", java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "redirect:/admin/logs?error=" + 
                   java.net.URLEncoder.encode("清理失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }
    
    /**
     * 场地管理页面（支持分页）
     */
    @GetMapping("/venues")
    public String venueManagement(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) Integer status,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            HttpSession session,
            Model model) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "场地管理");

        // 分页查询场地列表
        PageInfo<Venue> pageInfo = venueService.searchVenuesByPage(name, status, pageNum, pageSize);
        
        model.addAttribute("venues", pageInfo.getList());
        model.addAttribute("venueCount", pageInfo.getTotal());
        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("totalVenues", venueService.getTotalVenueCount());
        model.addAttribute("availableVenues", venueService.getAvailableVenueCount());

        // 回传筛选条件
        model.addAttribute("searchName", name);
        model.addAttribute("searchStatus", status);
        model.addAttribute("pageNum", pageNum);
        model.addAttribute("pageSize", pageSize);

        return "admin/venue-management";
    }
    
    /**
     * 添加场地页面
     */
    @GetMapping("/venues/add")
    public String addVenuePage(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "添加场地");

        return "admin/venue-add";
    }
    
    /**
     * 编辑场地页面
     */
    @GetMapping("/venues/edit/{venueId}")
    public String editVenuePage(@PathVariable Long venueId, HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        Venue venue = venueService.getVenueById(venueId);
        if (venue == null) {
            return "redirect:/admin/venues?error=" + 
                   java.net.URLEncoder.encode("场地不存在", java.nio.charset.StandardCharsets.UTF_8);
        }

        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "编辑场地");
        model.addAttribute("venue", venue);

        return "admin/venue-edit";
    }

    /**
     * 获取场地详细信息
     */
    @GetMapping("/api/venues/{venueId}")
    @ResponseBody
    public Map<String, Object> getVenueDetail(@PathVariable Long venueId, HttpSession session) {
        Map<String, Object> result = new HashMap<>();
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            result.put("success", false);
            result.put("message", "权限不足");
            return result;
        }

        try {
            Venue venue = venueService.getVenueById(venueId);
            if (venue != null) {
                result.put("success", true);
                result.put("venue", venue);
            } else {
                result.put("success", false);
                result.put("message", "场地不存在");
            }
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "获取场地信息失败：" + e.getMessage());
        }
        
        return result;
    }

    /**
     * 更新场地
     */
    @PostMapping("/venues/update")
    public String updateVenue(@RequestParam Long venueId,
                              @RequestParam String name,
                              @RequestParam Integer capacity,
                              @RequestParam String location,
                              HttpSession session) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        try {
            Venue venue = venueService.getVenueById(venueId);
            if (venue == null) {
                return "redirect:/admin/venues?error=" + 
                       java.net.URLEncoder.encode("场地不存在", java.nio.charset.StandardCharsets.UTF_8);
            }
            
            venue.setVenueId(venueId);
            venue.setName(name);
            venue.setCapacity(capacity);
            venue.setLocation(location);
            
            boolean success = venueService.updateVenue(venue, currentUser.getUserId(), currentUser.getName());
            
            if (success) {
                return "redirect:/admin/venues?success=" + 
                       java.net.URLEncoder.encode("场地更新成功", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/venues/edit/" + venueId + "?error=" + 
                       java.net.URLEncoder.encode("更新失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/venues/edit/" + venueId + "?error=" + 
                   java.net.URLEncoder.encode("操作失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }

    /**
     * 保存场地（添加或更新）
     */
    @PostMapping("/venues/save")
    public String saveVenue(
            @RequestParam(required = false) Long venueId,
            @RequestParam String name,
            @RequestParam Integer capacity,
            @RequestParam(required = false) String location,
            @RequestParam(defaultValue = "1") Integer status,
            HttpSession session,
            Model model) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        try {
            Venue venue = new Venue();
            if (venueId != null) {
                venue.setVenueId(venueId);
            }
            venue.setName(name);
            venue.setCapacity(capacity);
            venue.setLocation(location);
            venue.setStatus(status);
            
            boolean success;
            if (venueId != null) {
                // 更新场地
                success = venueService.updateVenue(venue, currentUser.getUserId(), currentUser.getName());
            } else {
                // 添加新场地
                success = venueService.addVenue(venue, currentUser.getUserId(), currentUser.getName());
            }
            
            if (success) {
                return "redirect:/admin/venues?success=" + 
                       java.net.URLEncoder.encode("场地保存成功", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/venues?error=" + 
                       java.net.URLEncoder.encode("保存失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            // 记录错误但不影响用户看到成功消息（因为场地可能已经保存成功）
            System.err.println("场地保存后记录日志失败：" + e.getMessage());
            e.printStackTrace();
            // 仍然返回成功，因为场地数据已经插入
            return "redirect:/admin/venues?success=" + 
                   java.net.URLEncoder.encode("场地保存成功", java.nio.charset.StandardCharsets.UTF_8);
        }
    }

    /**
     * 启用场地
     */
    @GetMapping("/venues/enable/{venueId}")
    public String enableVenue(@PathVariable Long venueId, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
    
        try {
            boolean success = venueService.enableVenue(venueId, currentUser.getUserId(), currentUser.getName());
            if (success) {
                return "redirect:/admin/venues?success=" + 
                       java.net.URLEncoder.encode("场地启用成功", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/venues?error=" + 
                       java.net.URLEncoder.encode("启用失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/venues?error=" + 
                   java.net.URLEncoder.encode("操作失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }
        
    /**
     * 禁用场地（设为维护）
     */
    @GetMapping("/venues/disable/{venueId}")
    public String disableVenue(@PathVariable Long venueId, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
    
        try {
            boolean success = venueService.disableVenue(venueId, currentUser.getUserId(), currentUser.getName());
            if (success) {
                return "redirect:/admin/venues?success=" + 
                       java.net.URLEncoder.encode("场地设为维护成功", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/venues?error=" + 
                       java.net.URLEncoder.encode("操作失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/venues?error=" + 
                   java.net.URLEncoder.encode("操作失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }
        
    /**
     * 删除场地
     */
    @GetMapping("/venues/delete/{venueId}")
    public String deleteVenue(@PathVariable Long venueId, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
    
        try {
            boolean success = venueService.deleteVenue(venueId, currentUser.getUserId(), currentUser.getName());
            if (success) {
                return "redirect:/admin/venues?success=" + 
                       java.net.URLEncoder.encode("场地删除成功", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/venues?error=" + 
                       java.net.URLEncoder.encode("删除失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/venues?error=" + 
                   java.net.URLEncoder.encode("操作失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }
    
    /**
     * 批量删除场地
     */
    @PostMapping("/venues/batch-delete")
    public String batchDeleteVenues(@RequestParam String ids, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
        
        try {
            String[] idArray = ids.split(",");
            for (String id : idArray) {
                try {
                    Long venueId = Long.parseLong(id.trim());
                    venueService.deleteVenue(venueId, currentUser.getUserId(), currentUser.getName());
                } catch (Exception e) {
                    // 跳过删除失败的记录
                }
            }
            return "redirect:/admin/venues?success=" + 
                   java.net.URLEncoder.encode("批量删除成功，共删除" + idArray.length + "个场地", java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "redirect:/admin/venues?error=" + 
                   java.net.URLEncoder.encode("操作失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }

    /**
     * 批量删除预约
     */
    @PostMapping("/reservations/batch-delete")
    public String batchDeleteReservations(@RequestParam String ids, @RequestParam Long lectureId, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
        
        try {
            String[] idArray = ids.split(",");
            for (String id : idArray) {
                try {
                    Long reservationId = Long.parseLong(id.trim());
                    reservationService.deleteReservation(reservationId, currentUser.getUserId(), currentUser.getName());
                } catch (Exception e) {
                    // 跳过删除失败的记录
                }
            }
            return "redirect:/admin/reservations/list/" + lectureId;
        } catch (Exception e) {
            return "redirect:/admin/reservations/list/" + lectureId;
        }
    }
    
    /**
     * 确认预约（管理员操作）
     */
    @PostMapping("/reservations/confirm/{reservationId}")
    @ResponseBody
    public Map<String, Object> confirmReservation(@PathVariable Long reservationId, HttpSession session) {
        return updateReservationStatus(reservationId, "confirmed", session);
    }

    /**
     * 取消预约（管理员操作）
     */
    @PostMapping("/reservations/cancel/{reservationId}")
    @ResponseBody
    public Map<String, Object> cancelReservation(@PathVariable Long reservationId, HttpSession session) {
        return updateReservationStatus(reservationId, "cancelled", session);
    }

    /**
     * 更新预约状态通用方法
     */
    private Map<String, Object> updateReservationStatus(Long reservationId, String status, HttpSession session) {
        Map<String, Object> result = new HashMap<>();
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            result.put("success", false);
            result.put("message", "权限不足");
            return result;
        }

        try {
            boolean success = reservationService.updateReservationStatus(reservationId, status, currentUser.getUserId(), currentUser.getName());
            
            if (success) {
                result.put("success", true);
                String actionDesc = "confirmed".equals(status) ? "已确认" : "已取消";
                result.put("message", "预约" + actionDesc);
            } else {
                result.put("success", false);
                result.put("message", "操作失败");
            }
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "操作失败：" + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * 发布系统通知
     */
    @PostMapping("/send-notification")
    public String sendNotification(
            @RequestParam String title,
            @RequestParam String content,
            @RequestParam(required = false) String batchReceiver,
            @RequestParam(required = false) String selectedUserIds,
            HttpSession session) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
        
        try {
            List<Long> userIds = new java.util.ArrayList<>();
            
            // 优先处理指定用户
            if (selectedUserIds != null && !selectedUserIds.trim().isEmpty()) {
                // 解析选中的用户 ID
                String[] idArray = selectedUserIds.split(",");
                for (String id : idArray) {
                    try {
                        Long userId = Long.parseLong(id.trim());
                        if (userId > 0) {
                            userIds.add(userId);
                        }
                    } catch (NumberFormatException e) {
                        // 忽略无效 ID
                    }
                }
            } else if (batchReceiver != null && !batchReceiver.isEmpty()) {
                // 根据群发角色筛选用户
                List<User> users;
                if ("all".equals(batchReceiver)) {
                    // 所有用户
                    users = adminUserService.getAllUsers();
                } else {
                    // 按角色筛选
                    users = adminUserService.getUsersByRole(batchReceiver);
                }
                
                if (users != null && !users.isEmpty()) {
                    userIds = users.stream()
                            .map(User::getUserId)
                            .toList();
                }
            }
            
            // 发送通知
            if (!userIds.isEmpty()) {
                notificationService.batchSendNotification(userIds, title, content, "system", currentUser.getUserId());
                return "redirect:/admin/dashboard?success=" + 
                       java.net.URLEncoder.encode("通知发送成功", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/dashboard?error=" + 
                       java.net.URLEncoder.encode("未选择有效的接收对象", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/dashboard?error=" + 
                   java.net.URLEncoder.encode("发送失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }
    
    /**
     * 通知模板管理页面
     */
    @GetMapping(value = {"/templates/manage", "/templates/edit"})
    public String templateManagement(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
        
        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "通知模板配置");
        
        // 获取所有模板
        List<NotificationTemplate> templates = notificationService.getAllTemplates();
        model.addAttribute("templates", templates);
        
        // 统计数据
        int enabledCount = 0;
        int disabledCount = 0;
        for (NotificationTemplate template : templates) {
            if (template.getIsEnabled() == 1) {
                enabledCount++;
            } else {
                disabledCount++;
            }
        }
        model.addAttribute("enabledCount", enabledCount);
        model.addAttribute("disabledCount", disabledCount);
        
        return "admin/template-management";
    }
    
    /**
     * 更新通知模板
     */
    @PostMapping("/templates/update")
    public String updateTemplate(
            @RequestParam Long templateId,
            @RequestParam String titleTemplate,
            @RequestParam String contentTemplate,
            @RequestParam Integer isEnabled,
            HttpSession session) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
        
        try {
            NotificationTemplate template = notificationService.getTemplateById(templateId);
            if (template == null) {
                return "redirect:/admin/templates/manage?error=" + 
                       java.net.URLEncoder.encode("模板不存在", java.nio.charset.StandardCharsets.UTF_8);
            }
            
            template.setTitleTemplate(titleTemplate);
            template.setContentTemplate(contentTemplate);
            template.setIsEnabled(isEnabled);
            
            boolean success = notificationService.updateTemplate(template, currentUser.getUserId());
            
            if (success) {
                return "redirect:/admin/templates/manage?success=" + 
                       java.net.URLEncoder.encode("模板已更新", java.nio.charset.StandardCharsets.UTF_8);
            } else {
                return "redirect:/admin/templates/manage?error=" + 
                       java.net.URLEncoder.encode("更新失败", java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            return "redirect:/admin/templates/manage?error=" + 
                   java.net.URLEncoder.encode("更新失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }
    
    /**
     * 通知管理页面
     */
    @GetMapping("/notifications/manage")
    public String manageNotifications(
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String receiver,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            HttpSession session,
            Model model) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
        
        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "通知管理");
        
        // 分页查询通知列表
        PageInfo<Notification> pageInfo = notificationService.searchNotifications(type, receiver, pageNum, pageSize);
        
        model.addAttribute("notifications", pageInfo.getList());
        model.addAttribute("notificationCount", pageInfo.getTotal());
        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("searchType", type);
        model.addAttribute("searchReceiver", receiver);
        model.addAttribute("pageNum", pageNum);
        model.addAttribute("pageSize", pageSize);
        
        // 统计各类型通知数量
        model.addAttribute("systemCount", notificationService.countByType("system"));
        model.addAttribute("lectureCount", notificationService.countByType("lecture"));
        
        return "admin/notification-management";
    }
    
    /**
     * 删除通知
     */
    @GetMapping("/notifications/delete/{notificationId}")
    public String deleteNotification(@PathVariable Long notificationId, 
                                     @RequestParam(defaultValue = "1") Integer pageNum,
                                     @RequestParam(defaultValue = "10") Integer pageSize,
                                     @RequestParam(required = false) String type,
                                     @RequestParam(required = false) String receiver,
                                     HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
        
        try {
            notificationService.deleteNotification(notificationId, currentUser.getUserId());
            // 构建重定向 URL，保留分页和筛选条件
            StringBuilder redirectUrl = new StringBuilder("redirect:/admin/notifications/manage?pageNum=" + pageNum + "&pageSize=" + pageSize);
            if (type != null && !type.isEmpty()) {
                redirectUrl.append("&type=").append(java.net.URLEncoder.encode(type, java.nio.charset.StandardCharsets.UTF_8));
            }
            if (receiver != null && !receiver.isEmpty()) {
                redirectUrl.append("&receiver=").append(java.net.URLEncoder.encode(receiver, java.nio.charset.StandardCharsets.UTF_8));
            }
            redirectUrl.append("&success=").append(java.net.URLEncoder.encode("通知已删除", java.nio.charset.StandardCharsets.UTF_8));
            return redirectUrl.toString();
        } catch (Exception e) {
            StringBuilder redirectUrl = new StringBuilder("redirect:/admin/notifications/manage?pageNum=" + pageNum + "&pageSize=" + pageSize);
            if (type != null && !type.isEmpty()) {
                redirectUrl.append("&type=").append(java.net.URLEncoder.encode(type, java.nio.charset.StandardCharsets.UTF_8));
            }
            if (receiver != null && !receiver.isEmpty()) {
                redirectUrl.append("&receiver=").append(java.net.URLEncoder.encode(receiver, java.nio.charset.StandardCharsets.UTF_8));
            }
            redirectUrl.append("&error=").append(java.net.URLEncoder.encode("删除失败：" + e.getMessage(), java.nio.charset.StandardCharsets.UTF_8));
            return redirectUrl.toString();
        }
    }
    
    /**
     * 批量删除通知
     */
    @PostMapping("/notifications/batch-delete")
    public String batchDeleteNotifications(@RequestParam String ids, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }
        
        try {
            String[] idArray = ids.split(",");
            for (String id : idArray) {
                try {
                    notificationService.deleteNotification(Long.parseLong(id.trim()), currentUser.getUserId());
                } catch (NumberFormatException e) {
                    // 忽略无效 ID
                }
            }
            return "redirect:/admin/notifications/manage";
        } catch (Exception e) {
            return "redirect:/admin/notifications/manage";
        }
    }
    
    /**
     * 预约管理页面（只显示已通过或已失效的讲座）
     */
    @GetMapping("/reservations/manage")
    public String manageReservations(
             @RequestParam(required = false) String title,
             @RequestParam(required = false) String speaker,
             @RequestParam(required = false) String status,
             @RequestParam(defaultValue = "1") Integer pageNum,
             @RequestParam(defaultValue = "10") Integer pageSize,
             HttpSession session,
             Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "预约管理");

        // 如果用户选择了待审核，直接返回空结果
        if ("pending".equals(status)) {
            model.addAttribute("lectures", new java.util.ArrayList<>());
            model.addAttribute("lectureCount", 0);
            model.addAttribute("pageInfo", null);
            model.addAttribute("pageNum", pageNum);
            model.addAttribute("pageSize", pageSize);
            model.addAttribute("searchTitle", title);
            model.addAttribute("searchSpeaker", speaker);
            model.addAttribute("currentStatus", status);
            model.addAttribute("totalReservations", reservationService.getTotalReservationCount());
            return "admin/reservation-management";
        }
        
        // 分页查询讲座列表
        PageInfo<Lecture> pageInfo = lectureService.searchLecturesByPage(title, speaker, status, pageNum, pageSize);
        
        // 过滤掉待审核状态的讲座（预约管理不显示待审核讲座）
        java.util.List<Lecture> filteredLectures = pageInfo.getList().stream()
                .filter(l -> !"pending".equals(l.getStatus()))
                .collect(java.util.stream.Collectors.toList());
        
        // 过滤已过期的讲座状态
        for (Lecture lecture : filteredLectures) {
            if (lecture.getEnrolledCount() == null) {
                lecture.setEnrolledCount(0);
            }
            if ("approved".equals(lecture.getStatus()) && lecture.isExpired()) {
                lecture.setStatus("expired");
            }
        }
        
        model.addAttribute("lectures", filteredLectures);
        model.addAttribute("lectureCount", filteredLectures.size());
        model.addAttribute("pageInfo", new PageInfo<>(filteredLectures, pageNum, pageSize, filteredLectures.size()));
        model.addAttribute("pageNum", pageNum);
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("searchTitle", title);
        model.addAttribute("searchSpeaker", speaker);
        model.addAttribute("currentStatus", status);
        model.addAttribute("totalReservations", reservationService.getTotalReservationCount());

        return "admin/reservation-management";
    }
    
    /**
     * 预约详情页面（显示某讲座的预约列表）
     */
    @GetMapping("/reservations/list/{lectureId}")
    public String reservationList(@PathVariable Long lectureId,
             @RequestParam(defaultValue = "1") Integer pageNum,
             @RequestParam(defaultValue = "50") Integer pageSize,
             HttpSession session,
             Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return "redirect:/user/login";
        }

        Lecture lecture = lectureService.getLectureById(lectureId);
        if (lecture == null) {
            return "redirect:/admin/reservations/manage?error=" + 
                   java.net.URLEncoder.encode("讲座不存在", java.nio.charset.StandardCharsets.UTF_8);
        }

        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "预约详情");
        model.addAttribute("lecture", lecture);

        // 获取该讲座的预约列表
        PageInfo<Reservation> pageInfo = reservationService.getReservationsByLecturePage(lectureId, pageNum, pageSize);
        
        model.addAttribute("reservations", pageInfo.getList());
        model.addAttribute("reservationCount", pageInfo.getTotal());
        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("pageNum", pageNum);
        model.addAttribute("pageSize", pageSize);
        
        // 已签到人数
        int checkedInCount = 0;
        // 已确认人数
        int confirmedCount = 0;
        for (Reservation r : pageInfo.getList()) {
            if ("confirmed".equals(r.getStatus())) {
                confirmedCount++;
            }
            if ("checked".equals(r.getCheckinStatus())) {
                checkedInCount++;
            }
        }
        model.addAttribute("checkedInCount", checkedInCount);
        model.addAttribute("confirmedCount", confirmedCount);

        return "admin/reservation-list";
    }
    
    /**
     * 导出预约名单（Excel 格式）
     */
    @GetMapping("/reservations/export/{lectureId}")
    public ResponseEntity<byte[]> exportReservations(@PathVariable Long lectureId, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null || !"admin".equals(currentUser.getRole())) {
            return null;
        }
        
        Lecture lecture = lectureService.getLectureById(lectureId);
        if (lecture == null) {
            return null;
        }
        
        List<Reservation> reservations = reservationService.getLectureReservations(lectureId);
        
        try {
            // 准备数据
            List<Map<String, Object>> dataList = new java.util.ArrayList<>();
            int confirmedCount = 0;
            for (Reservation r : reservations) {
                if ("confirmed".equals(r.getStatus())) {
                    java.util.Map<String, Object> data = new java.util.HashMap<>();
                    data.put("name", r.getUserName());
                    dataList.add(data);
                    confirmedCount++;
                }
            }
            
            String timeLocation = "";
            if (lecture.getLectureTime() != null) {
                timeLocation = lecture.getLectureTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) + " " + lecture.getLocation();
            }
            
            // 调用工具类生成 Excel
            byte[] excelBytes = ExcelUtil.exportReservationList(
                lecture.getTitle(),
                lecture.getSpeakerName(),
                timeLocation,
                "",  // location 已经包含在 timeLocation 中
                reservations.size(),
                dataList
            );
            
            // 记录操作日志
            adminUserService.logExportReservations(lectureId, lecture.getTitle(), confirmedCount, currentUser.getUserId());
            
            String filename = java.net.URLEncoder.encode(lecture.getTitle() + "_预约名单.xlsx", "UTF-8");
            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Disposition", "attachment; filename=" + filename);
            
            return new ResponseEntity<>(excelBytes, headers, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}