package org.stu.stulecture.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.stu.stulecture.entity.Lecture;
import org.stu.stulecture.entity.OperationLog;
import org.stu.stulecture.entity.Reservation;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.mapper.LectureMapper;
import org.stu.stulecture.mapper.OperationLogMapper;
import org.stu.stulecture.mapper.ReservationMapper;
import org.stu.stulecture.mapper.UserMapper;
import org.stu.stulecture.util.PageInfo;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 讲座业务逻辑处理
 */
@Service
public class LectureService {
    
    @Autowired
    private LectureMapper lectureMapper;
    
    @Autowired
    private OperationLogMapper operationLogMapper;
    
    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private ReservationMapper reservationMapper;
    
    @Autowired
    private UserMapper userMapper;
    
    /**
     * 显示用户名：账号+姓名
     */
    private String formatUserName(Long userId) {
        if (userId == null) {
            return "系统";
        }
        User user = userMapper.findById(userId);
        if (user == null) {
            return "用户 ID:" + userId;
        }
        if (user.getName() != null && !user.getName().isEmpty()) {
            return user.getUsername() + "（" + user.getName() + "）";
        }
        return user.getUsername();
    }
    
    /**
     * 检查讲座是否过期，过期则更新状态
     */
    private void updateLectureStatusIfExpired(Lecture lecture) {
        if (lecture != null && "approved".equals(lecture.getStatus()) && lecture.isExpired()) {
            lecture.setStatus("expired");
            lectureMapper.update(lecture);
        }
    }
    
    /**
     * 处理讲座发布，默认设为待审核
     */
    public boolean publishLecture(Lecture lecture, Long operatorId, String operatorName) {
        // 初始化状态
        if (lecture.getStatus() == null) {
            lecture.setStatus("pending");
        }
        if (lecture.getEnrolledCount() == null) {
            lecture.setEnrolledCount(0);
        }
        
        boolean result = lectureMapper.insert(lecture) > 0;
        
        if (result) {
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "发布新讲座", "讲座管理", 
                "发布讲座 [" + lecture.getTitle() + "]");
            operationLogMapper.insert(log);
        }
        
        return result;
    }
    
    /**
     * 按ID查询讲座详情
     */
    public Lecture getLectureById(Long lectureId) {
        Lecture lecture = lectureMapper.findById(lectureId);
        if (lecture != null) {
            initEnrolledCount(lecture);
        }
        return lecture;
    }
    
    /**
     * 初始化预约人数，避免空指针
     */
    private void initEnrolledCount(Lecture lecture) {
        if (lecture != null && lecture.getEnrolledCount() == null) {
            lecture.setEnrolledCount(0);
        }
    }
    
    /**
     * 处理讲座过期状态
     */
    private void handleExpiredStatus(Lecture lecture) {
        if ("approved".equals(lecture.getStatus()) && lecture.isExpired()) {
            lecture.setStatus("expired");
        }
    }
    
    /**
     * 查询全部讲座（含主讲人信息）
     */
    public List<Lecture> getAllLectures() {
        List<Lecture> lectures = lectureMapper.findAllWithSpeaker();
        for (Lecture lecture : lectures) {
            initEnrolledCount(lecture);
            handleExpiredStatus(lecture);
        }
        return lectures;
    }
    
    /**
     * 按状态筛选讲座
     */
    public List<Lecture> getLecturesByStatus(String status) {
        List<Lecture> lectures = lectureMapper.findByStatus(status);
        for (Lecture lecture : lectures) {
            initEnrolledCount(lecture);
            handleExpiredStatus(lecture);
        }
        return lectures;
    }
    
    /**
     * 按分类查找讲座
     */
    public List<Lecture> getLecturesByCategory(String category) {
        List<Lecture> lectures = lectureMapper.findByCategory(category);
        for (Lecture lecture : lectures) {
            initEnrolledCount(lecture);
            handleExpiredStatus(lecture);
        }
        return lectures;
    }
    
    /**
     * 查询某教师发布的讲座
     */
    public List<Lecture> getLecturesBySpeaker(Long speakerId) {
        List<Lecture> lectures = lectureMapper.findBySpeakerId(speakerId);
        for (Lecture lecture : lectures) {
            initEnrolledCount(lecture);
            handleExpiredStatus(lecture);
        }
        return lectures;
    }
    
    /**
     * 根据时间范围获取讲座
     */
    public List<Lecture> getLecturesByTimeRange(LocalDateTime startTime, LocalDateTime endTime) {
        return lectureMapper.findByTimeRange(startTime, endTime);
    }
    
    /**
     * 关键字搜索讲座
     */
    public List<Lecture> searchLectures(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllLectures();
        }
        List<Lecture> lectures = lectureMapper.searchByKeyword(keyword.trim());
        for (Lecture lecture : lectures) {
            initEnrolledCount(lecture);
            handleExpiredStatus(lecture);
        }
        return lectures;
    }
    
    /**
     * 多条件组合搜索
     */
    public List<Lecture> searchLectures(String title, String speaker, String status) {
        List<Lecture> lectures = lectureMapper.searchLectures(title, speaker, status);
        for (Lecture lecture : lectures) {
            initEnrolledCount(lecture);
            handleExpiredStatus(lecture);
        }
        return lectures;
    }
    
    /**
     * 分页查询讲座数据
     */
    public PageInfo<Lecture> searchLecturesByPage(String title, String speaker, String status,
                                                   int pageNum, int pageSize) {
        int offset = (pageNum - 1) * pageSize;
        
        List<Lecture> lectures = lectureMapper.searchLecturesByPage(title, speaker, status, offset, pageSize);
        
        for (Lecture lecture : lectures) {
            initEnrolledCount(lecture);
            handleExpiredStatus(lecture);
        }
        
        int total = lectureMapper.countSearchLectures(title, speaker, status);
        
        return new PageInfo<>(lectures, pageNum, pageSize, total);
    }
    
    /**
     * 修改讲座信息
     */
    @Transactional
    public boolean updateLecture(Lecture lecture, Long operatorId, String operatorName) {
        Lecture oldLecture = getLectureById(lecture.getLectureId());
        boolean result = lectureMapper.update(lecture) > 0;
        
        if (result) {
            // 记录操作日志
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "更新讲座信息", "讲座管理", 
                "更新讲座 [" + lecture.getTitle() + "] 的信息");
            operationLogMapper.insert(log);
            
            // 检查哪些字段有变更
            boolean timeChanged = (oldLecture.getLectureTime() != null && !oldLecture.getLectureTime().equals(lecture.getLectureTime())) ||
                                  (oldLecture.getLectureTime() == null && lecture.getLectureTime() != null);
            boolean locationChanged = (oldLecture.getLocation() != null && !oldLecture.getLocation().equals(lecture.getLocation())) ||
                                      (oldLecture.getLocation() == null && lecture.getLocation() != null);
            boolean titleChanged = (oldLecture.getTitle() != null && !oldLecture.getTitle().equals(lecture.getTitle())) ||
                                   (oldLecture.getTitle() == null && lecture.getTitle() != null);
            boolean capacityChanged = oldLecture.getCapacity() != null && !oldLecture.getCapacity().equals(lecture.getCapacity());
            boolean descriptionChanged = (oldLecture.getDescription() != null && !oldLecture.getDescription().equals(lecture.getDescription())) ||
                                         (oldLecture.getDescription() == null && lecture.getDescription() != null);
            boolean posterChanged = (oldLecture.getPoster() != null && !oldLecture.getPoster().equals(lecture.getPoster())) ||
                                    (oldLecture.getPoster() == null && lecture.getPoster() != null);
            
            // 任何主要信息变更都要通知已预约用户
            boolean anyChange = timeChanged || locationChanged || titleChanged || 
                               capacityChanged || descriptionChanged || posterChanged;
            
            if (anyChange) {
                List<Reservation> reservations = reservationMapper.findByLectureId(lecture.getLectureId());
                List<Long> reservedUserIds = reservations.stream()
                    .map(Reservation::getUserId)
                    .toList();
                
                // 只有在时间或地点变更时才发送详细信息变更通知
                if (timeChanged || locationChanged) {
                    String oldTime = oldLecture.getLectureTime() != null ? 
                        oldLecture.getLectureTime().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "未设置";
                    String newTime = lecture.getLectureTime() != null ? 
                        lecture.getLectureTime().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "未设置";
                    
                    notificationService.sendLectureChangedNotificationToAll(
                        lecture.getLectureId(),
                        lecture.getTitle(),
                        timeChanged ? oldTime : null,
                        timeChanged ? newTime : null,
                        locationChanged ? oldLecture.getLocation() : null,
                        locationChanged ? lecture.getLocation() : null,
                        "讲座信息更新",
                        lecture.getSpeakerId(),
                        reservedUserIds
                    );
                } else if (anyChange) {
                    // 其他信息变更，发送通用通知
                    notificationService.sendLectureChangedNotificationToAll(
                        lecture.getLectureId(),
                        lecture.getTitle(),
                        null,
                        null,
                        null,
                        null,
                        "讲座信息更新",
                        lecture.getSpeakerId(),
                        reservedUserIds
                    );
                }
            }
        }
        
        return result;
    }
    
    /**
     * 更新讲座状态（审核）
     */
    @Transactional
    public boolean updateLectureStatus(Long lectureId, String status, Long operatorId, String operatorName, String rejectReason) {
        Lecture lecture = getLectureById(lectureId);
        if (lecture == null) {
            return false;
        }
        
        String oldStatus = lecture.getStatus();
        lecture.setStatus(status);
        boolean result = lectureMapper.update(lecture) > 0;
        
        if (result) {
            // 记录操作日志
            String action = "approved".equals(status) ? "通过审核" : "拒绝审核";
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "审核讲座", "讲座管理", 
                "将讲座 [" + lecture.getTitle() + "] 的状态从 [" + oldStatus + "] 变更为 [" + status + "] （" + action + "）");
            operationLogMapper.insert(log);
            
            // 发送审核结果通知给主讲人
            boolean approved = "approved".equals(status);
            String actualRejectReason = approved ? null : (rejectReason != null ? rejectReason : "您的讲座未通过审核，请联系管理员了解详情");
            // 格式化时间和地点
            String lectureTimeStr = lecture.getLectureTime() != null ? 
                lecture.getLectureTime().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "待定";
            String locationStr = lecture.getLocation() != null ? lecture.getLocation() : "待定";
            
            notificationService.sendAuditResultNotification(
                lectureId, 
                lecture.getTitle(), 
                lecture.getSpeakerId(), 
                approved, 
                actualRejectReason, 
                operatorId,
                lectureTimeStr,
                locationStr
            );
        }
        
        return result;
    }
    
    /**
     * 更新讲座状态（不带拒绝理由，兼容旧代码）
     */
    public boolean updateLectureStatus(Long lectureId, String status, Long operatorId, String operatorName) {
        return updateLectureStatus(lectureId, status, operatorId, operatorName, null);
    }
    
    /**
     * 更新已预约人数
     */
    public boolean updateEnrolledCount(Long lectureId, Integer enrolledCount) {
        return lectureMapper.updateEnrolledCount(lectureId, enrolledCount) > 0;
    }
    
    /**
     * 增加预约人数
     */
    public boolean increaseEnrolledCount(Long lectureId) {
        Lecture lecture = getLectureById(lectureId);
        if (lecture != null) {
            int newCount = (lecture.getEnrolledCount() == null ? 0 : lecture.getEnrolledCount()) + 1;
            return updateEnrolledCount(lectureId, newCount);
        }
        return false;
    }
    
    /**
     * 减少预约人数
     */
    public boolean decreaseEnrolledCount(Long lectureId) {
        Lecture lecture = getLectureById(lectureId);
        if (lecture != null && lecture.getEnrolledCount() != null && lecture.getEnrolledCount() > 0) {
            int newCount = lecture.getEnrolledCount() - 1;
            return updateEnrolledCount(lectureId, newCount);
        }
        return false;
    }
    
    /**
     * 删除讲座（简化版：直接删除讲座，预约记录需手动处理）
     */
    @Transactional
    public boolean deleteLecture(Long lectureId, Long operatorId, String operatorName) {
        Lecture lecture = getLectureById(lectureId);
        if (lecture == null) {
            return false;
        }
        
        // 1. 获取所有已预约该讲座的用户（用于发送通知）
        List<org.stu.stulecture.entity.Reservation> reservations = reservationMapper.findByLectureId(lectureId);
        List<Long> reservedUserIds = reservations.stream()
            .map(org.stu.stulecture.entity.Reservation::getUserId)
            .toList();
        
        // 2. 先删除所有相关的预约记录（因为没有配置级联删除，需要手动删除）
        for (org.stu.stulecture.entity.Reservation reservation : reservations) {
            reservationMapper.deleteById(reservation.getReservationId());
        }
        
        // 3. 删除海报文件（如果存在）
        if (lecture.getPoster() != null && !lecture.getPoster().isEmpty()) {
            try {
                org.stu.stulecture.util.FileUploadUtil.deleteFile(lecture.getPoster(), "src/main/resources/static/poster");
            } catch (Exception e) {
                // 海报删除失败不影响讲座删除，仅记录错误
                System.err.println("删除海报文件失败：" + lecture.getPoster());
            }
        }
        
        // 4. 再删除讲座
        boolean result = lectureMapper.deleteById(lectureId) > 0;
        
        if (result) {
            // 5. 记录操作日志
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "删除讲座", "讲座管理", 
                "删除讲座 [" + lecture.getTitle() + "]");
            operationLogMapper.insert(log);
            
            // 6. 发送取消通知给发布人和所有预约用户
            notificationService.sendLectureCancelledNotificationToAll(
                lectureId,
                lecture.getTitle(),
                lecture.getSpeakerId(),
                reservedUserIds
            );
        }
        
        return result;
    }
    
    /**
     * 删除讲座（不发送通知，用于审核拒绝场景）
     */
    @Transactional
    public boolean deleteLectureWithoutNotification(Long lectureId, Long operatorId, String operatorName) {
        Lecture lecture = getLectureById(lectureId);
        if (lecture == null) {
            return false;
        }
        
        // 1. 获取所有已预约该讲座的用户（用于删除预约记录）
        List<org.stu.stulecture.entity.Reservation> reservations = reservationMapper.findByLectureId(lectureId);
        
        // 2. 先删除所有相关的预约记录
        for (org.stu.stulecture.entity.Reservation reservation : reservations) {
            reservationMapper.deleteById(reservation.getReservationId());
        }
        
        // 3. 删除海报文件（如果存在）
        if (lecture.getPoster() != null && !lecture.getPoster().isEmpty()) {
            try {
                org.stu.stulecture.util.FileUploadUtil.deleteFile(lecture.getPoster(), "src/main/resources/static/poster");
            } catch (Exception e) {
                // 海报删除失败不影响讲座删除，仅记录错误
                System.err.println("删除海报文件失败：" + lecture.getPoster());
            }
        }
        
        // 4. 再删除讲座
        boolean result = lectureMapper.deleteById(lectureId) > 0;
        
        if (result) {
            // 5. 记录操作日志
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "删除讲座", "讲座管理", 
                "删除讲座 [" + lecture.getTitle() + "] （审核未通过）");
            operationLogMapper.insert(log);
            // 注意：不发送通知，因为已经发送了审核未通过通知
        }
        
        return result;
    }
    
    /**
     * 获取最新的讲座（按发布时间倒序）
     * @param limit 最大数量
     * @return 最新讲座列表
     */
    public List<Lecture> getLatestLectures(int limit) {
        List<Lecture> lectures = lectureMapper.findByStatus("approved");
        // 过滤掉已失效的讲座，按讲座时间倒序排列，取前 limit 个
        return lectures.stream()
                .filter(lecture -> !lecture.isExpired())
                .sorted((l1, l2) -> {
                    if (l1.getLectureTime() == null) return 1;
                    if (l2.getLectureTime() == null) return -1;
                    return l2.getLectureTime().compareTo(l1.getLectureTime());
                })
                .limit(limit)
                .toList();
    }
    
    /**
     * 统计讲座总数
     */
    public int getTotalLectureCount() {
        return lectureMapper.countTotal();
    }
    
    /**
     * 统计某种状态的讲座数量
     */
    public int getLectureCountByStatus(String status) {
        return lectureMapper.countByStatus(status);
    }
    
    /**
     * 获取即将开始的讲座（未来7天内）
     */
    public List<Lecture> getUpcomingLectures() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime weekLater = now.plusDays(7);
        return lectureMapper.findByTimeRange(now, weekLater);
    }
    
    /**
     * 获取热门讲座（按预约人数排序）
     */
    public List<Lecture> getPopularLectures(int limit) {
        List<Lecture> lectures = getAllLectures();
        // 按预约人数降序排列，取前limit个
        return lectures.stream()
                .sorted((l1, l2) -> {
                    Integer count1 = l1.getEnrolledCount() != null ? l1.getEnrolledCount() : 0;
                    Integer count2 = l2.getEnrolledCount() != null ? l2.getEnrolledCount() : 0;
                    return count2.compareTo(count1);
                })
                .limit(limit)
                .toList();
    }
    
    /**
     * 验证讲座是否可以预约
     */
    public boolean canBookLecture(Long lectureId) {
        Lecture lecture = getLectureById(lectureId);
        if (lecture == null) {
            return false;
        }
        return lecture.canBeBooked();
    }
    
    /**
     * 获取讲座状态的中文
     */
    public String getStatusDescription(String status) {
        if (status == null || status.isEmpty()) {
            return "未知状态";
        }
        switch (status) {
            case "pending": return "待审核";
            case "approved": return "已通过";
            case "expired": return "已结束";
            default: return "未知状态";
        }
    }
    
    /**
     * 获取讲座形式的中文
     */
    public String getFormatDescription(String format) {
        if (format == null || format.isEmpty()) {
            return "未知形式";
        }
        switch (format) {
            case "offline": return "线下";
            case "online": return "线上";
            default: return "未知形式";
        }
    }
}