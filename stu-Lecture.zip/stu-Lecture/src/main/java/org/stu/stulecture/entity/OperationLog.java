package org.stu.stulecture.entity;

import java.time.LocalDateTime;

/**
 * 操作日志实体类
 */
public class OperationLog {
    private Long logId;         // 日志ID
    private Long userId;        // 操作用户ID
    private String username;    // 用户名
    private String operation;   // 操作描述
    private String module;      // 功能模块
    private String description; // 详细说明
    private String ipAddress;   // IP地址
    private String userAgent;   // 客户端信息
    private LocalDateTime createTime; // 创建时间

    // 构造函数
    public OperationLog() {}

    public OperationLog(Long userId, String username, String operation, 
                       String module, String description) {
        this.userId = userId;
        this.username = username;
        this.operation = operation;
        this.module = module;
        this.description = description;
        this.createTime = LocalDateTime.now();
    }

    // Getter和Setter方法
    public Long getLogId() { return logId; }
    public void setLogId(Long logId) { this.logId = logId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getOperation() { return operation; }
    public void setOperation(String operation) { this.operation = operation; }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }

    public String getUserAgent() { return userAgent; }
    public void setUserAgent(String userAgent) { this.userAgent = userAgent; }

    public LocalDateTime getCreateTime() { return createTime; }
    public void setCreateTime(LocalDateTime createTime) { this.createTime = createTime; }

    @Override
    public String toString() {
        return "OperationLog{" +
                "logId=" + logId +
                ", userId=" + userId +
                ", username='" + username + '\'' +
                ", operation='" + operation + '\'' +
                ", module='" + module + '\'' +
                ", createTime=" + createTime +
                '}';
    }
}