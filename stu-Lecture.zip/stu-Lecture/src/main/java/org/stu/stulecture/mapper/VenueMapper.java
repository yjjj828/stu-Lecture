package org.stu.stulecture.mapper;

import org.apache.ibatis.annotations.*;
import org.stu.stulecture.entity.Venue;

import java.util.List;

@Mapper
public interface VenueMapper {
    
    /**
     * 插入新场地
     */
    @Insert("INSERT INTO venues (name, capacity, location, status, created_time) " +
            "VALUES (#{name}, #{capacity}, #{location}, #{status}, NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "venueId")
    int insert(Venue venue);
    
    /**
     * 根据ID查询场地
     */
    @Select("SELECT * FROM venues WHERE venue_id = #{venueId}")
    Venue findById(Long venueId);
    
    /**
     * 查询所有场地
     */
    @Select("SELECT * FROM venues ORDER BY created_time DESC")
    List<Venue> findAll();
    
    /**
     * 根据状态查询场地
     */
    @Select("SELECT * FROM venues WHERE status = #{status} ORDER BY created_time DESC")
    List<Venue> findByStatus(Integer status);
    
    /**
     * 根据名称模糊搜索
     */
    @Select("SELECT * FROM venues WHERE name LIKE CONCAT('%', #{name}, '%') ORDER BY created_time DESC")
    List<Venue> findByNameLike(String name);
    
    /**
     * 分页查询场地
     */
    @Select("<script>" +
            "SELECT * FROM venues WHERE 1=1 " +
            "<if test='name != null and name != \"\"'>" +
            "AND name LIKE CONCAT('%', #{name}, '%') " +
            "</if>" +
            "<if test='status != null'>" +
            "AND status = #{status} " +
            "</if>" +
            "ORDER BY created_time DESC " +
            "LIMIT #{offset}, #{pageSize}" +
            "</script>")
    List<Venue> searchVenuesByPage(@Param("name") String name,
                                  @Param("status") Integer status,
                                  @Param("offset") int offset,
                                  @Param("pageSize") int pageSize);
    
    /**
     * 统计搜索结果的总数
     */
    @Select("<script>" +
            "SELECT COUNT(*) FROM venues WHERE 1=1 " +
            "<if test='name != null and name != \"\"'>" +
            "AND name LIKE CONCAT('%', #{name}, '%') " +
            "</if>" +
            "<if test='status != null'>" +
            "AND status = #{status} " +
            "</if>" +
            "</script>")
    int countSearchVenues(@Param("name") String name,
                         @Param("status") Integer status);
    
    /**
     * 更新场地信息
     */
    @Update("<script>" +
            "UPDATE venues SET " +
            "<if test=\"name != null\">name = #{name},</if>" +
            "<if test=\"capacity != null\">capacity = #{capacity},</if>" +
            "<if test=\"location != null\">location = #{location},</if>" +
            "<if test=\"status != null\">status = #{status},</if>" +
            "created_time = NOW() " +
            "WHERE venue_id = #{venueId}" +
            "</script>")
    int update(Venue venue);
    
    /**
     * 删除场地
     */
    @Delete("DELETE FROM venues WHERE venue_id = #{venueId}")
    int deleteById(Long venueId);
    
    /**
     * 统计场地总数
     */
    @Select("SELECT COUNT(*) FROM venues")
    int countTotal();
    
    /**
     * 统计可用场地数
     */
    @Select("SELECT COUNT(*) FROM venues WHERE status = 1")
    int countAvailable();
}