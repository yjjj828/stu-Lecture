package org.stu.stulecture.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.stu.stulecture.entity.Lecture;
import org.stu.stulecture.entity.Reservation;
import org.stu.stulecture.entity.OperationLog;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.mapper.LectureMapper;
import org.stu.stulecture.mapper.ReservationMapper;
import org.stu.stulecture.mapper.OperationLogMapper;
import org.stu.stulecture.mapper.UserMapper;
import org.stu.stulecture.util.PageInfo;

import java.util.List;

/**
 * 预约业务逻辑处理
 */
@Service
public class ReservationService {
    
    @Autowired
    private ReservationMapper reservationMapper;
    
    @Autowired
    private LectureMapper lectureMapper;
    
    @Autowired
    private LectureService lectureService;
    
    @Autowired
    private OperationLogMapper operationLogMapper;
    
    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private UserMapper userMapper;
    
    /**
     * 显示用户名：账号+姓名
     */
    private String formatUserName(Long userId) {
        if (userId == null) {
            return "系统";
        }
        User user = userMapper.findById(userId);
        if (user == null) {
            return "用户 ID:" + userId;
        }
        if (user.getName() != null && !user.getName().isEmpty()) {
            return user.getUsername() + "（" + user.getName() + "）";
        }
        return user.getUsername();
    }
    
    /**
     * 预约讲座（删除旧记录+重建）
     */
    @Transactional
    public boolean bookLecture(Long userId, String username, Long lectureId) {
        // 获取讲座并校验
        Lecture lecture = lectureService.getLectureById(lectureId);
        if (lecture == null || !lecture.canBeBooked()) {
            return false;
        }
        
        // 主讲人不能预约自己的讲座
        if (lecture.getSpeakerId().equals(userId)) {
            return false;
        }
        
        // 检查是否满员
        if (lecture.isFull()) {
            return false;
        }
        
        // 检查是否已有有效预约
        Reservation existing = reservationMapper.findByUserAndLecture(userId, lectureId);
        if (existing != null && "confirmed".equals(existing.getStatus())) {
            return false;
        }
        
        // 有取消记录则删除
        if (existing != null && "cancelled".equals(existing.getStatus())) {
            reservationMapper.deleteById(existing.getReservationId());
        }
        
        // 创建新预约
        Reservation reservation = new Reservation(userId, lectureId);
        int result = reservationMapper.insert(reservation);
        
        if (result > 0) {
            // 更新预约人数
            lectureService.increaseEnrolledCount(lectureId);
            
            OperationLog log = new OperationLog(userId, formatUserName(userId), 
                "预约讲座", "预约管理", 
                "预约了讲座 [" + lecture.getTitle() + "]");
            operationLogMapper.insert(log);
            
            // 发送成功通知
            String lectureTime = lecture.getLectureTime() != null ? 
                lecture.getLectureTime().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "待定";
            notificationService.sendReservationSuccessNotification(
                lectureId,
                lecture.getTitle(),
                lectureTime,
                lecture.getLocation(),
                userId
            );
            
            // 满员时通知讲师
            if (lecture.getEnrolledCount() != null && lecture.getEnrolledCount() >= lecture.getCapacity()) {
                notificationService.sendFullNotification(
                    lectureId,
                    lecture.getTitle(),
                    lecture.getSpeakerId()
                );
            }
            
            return true;
        }
        
        return false;
    }
    
    /**
     * 取消预约
     */
    @Transactional
    public boolean cancelReservation(Long reservationId, Long userId, String username) {
        Reservation reservation = reservationMapper.findById(reservationId);
        if (reservation == null || !reservation.getUserId().equals(userId)) {
            return false;
        }
        
        // 只允许取消已确认的预约
        if (!"confirmed".equals(reservation.getStatus())) {
            return false;
        }
        
        int result = reservationMapper.cancelReservation(reservationId);
        
        if (result > 0) {
            lectureService.decreaseEnrolledCount(reservation.getLectureId());
            
            OperationLog log = new OperationLog(userId, formatUserName(userId), 
                "取消预约", "预约管理", 
                "取消了讲座 [" + reservation.getLectureTitle() + "] 的预约");
            operationLogMapper.insert(log);
            
            notificationService.sendReservationCancelledNotification(
                reservation.getLectureId(),
                reservation.getLectureTitle(),
                userId
            );
            
            return true;
        }
        
        return false;
    }
    
    /**
     * 按ID查询预约详情
     */
    public Reservation getReservationById(Long reservationId) {
        return reservationMapper.findById(reservationId);
    }
    
    /**
     * 查询用户的预约列表
     */
    public List<Reservation> getUserReservations(Long userId) {
        return reservationMapper.findByUserId(userId);
    }
    
    /**
     * 标记24小时提醒已发送
     */
    @Transactional
    public void markReminded1day(Long reservationId) {
        reservationMapper.markReminded1day(reservationId);
    }
    
    /**
     * 标记2小时提醒已发送
     */
    @Transactional
    public void markReminded2hours(Long reservationId) {
        reservationMapper.markReminded2hours(reservationId);
    }
    
    /**
     * 分页查询用户的预约
     */
    public PageInfo<Reservation> getUserReservationsByPage(Long userId, int pageNum, int pageSize) {
        // 计算偏移量
        int offset = (pageNum - 1) * pageSize;
        
        // 查询当前页数据
        List<Reservation> reservations = reservationMapper.findByUserIdPage(userId, offset, pageSize);
        
        // 检查并更新关联讲座的过期状态
        for (Reservation reservation : reservations) {
            if ("approved".equals(reservation.getLectureStatus()) && reservation.getLectureTime() != null) {
                // 获取讲座对象以检查是否过期
                Lecture lecture = lectureService.getLectureById(reservation.getLectureId());
                if (lecture != null && lecture.isExpired()) {
                    // 更新讲座状态为expired
                    lecture.setStatus("expired");
                    lectureMapper.update(lecture);
                    // 更新预约对象中的讲座状态
                    reservation.setLectureStatus("expired");
                }
            }
        }
        
        // 查询总记录数
        int total = reservationMapper.countUserReservations(userId);
        
        // 封装分页信息
        return new PageInfo<>(reservations, pageNum, pageSize, total);
    }
    
    /**
     * 获取讲座的所有预约
     */
    public List<Reservation> getLectureReservations(Long lectureId) {
        return reservationMapper.findByLectureId(lectureId);
    }
    
    /**
     * 获取特定状态的预约
     */
    public List<Reservation> getReservationsByStatus(String status) {
        return reservationMapper.findByStatus(status);
    }
    
    /**
     * 检查用户是否已预约某个讲座
     */
    public boolean hasUserReservedLecture(Long userId, Long lectureId) {
        return reservationMapper.checkUserReservation(userId, lectureId) > 0;
    }
    
    /**
     * 获取用户的预约统计
     */
    public int getUserReservationCount(Long userId) {
        return reservationMapper.countByUserId(userId);
    }
    
    /**
     * 获取讲座的预约统计
     */
    public int getLectureReservationCount(Long lectureId) {
        return reservationMapper.countByLectureId(lectureId);
    }
    
    /**
     * 更新预约状态（管理员操作）
     */
    @Transactional
    public boolean updateReservationStatus(Long reservationId, String status, Long operatorId, String operatorName) {
        Reservation reservation = reservationMapper.findById(reservationId);
        if (reservation == null) {
            return false;
        }
        
        String oldStatus = reservation.getStatus();
        int result = reservationMapper.updateStatus(reservationId, status) > 0 ? 1 : 0;
        
        if (result > 0) {
            // 记录操作日志
            String action = "confirmed".equals(status) ? "确认预约" : "取消预约";
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                action, "预约管理", 
                "将用户 [" + reservation.getUserName() + "] 对讲座 [" + reservation.getLectureTitle() + 
                "] 的预约从 [" + oldStatus + "] 变更为 [" + status + "]");
            operationLogMapper.insert(log);
            
            // 如果管理员取消了预约，发送通知给用户
            if ("cancelled".equals(status)) {
                notificationService.sendReservationCancelledNotification(
                    reservation.getLectureId(),
                    reservation.getLectureTitle(),
                    reservation.getUserId()
                );
            }
            
            return true;
        }
        
        return false;
    }
    
    /**
     * 删除预约（管理员操作）
     */
    @Transactional
    public boolean deleteReservation(Long reservationId, Long operatorId, String operatorName) {
        Reservation reservation = reservationMapper.findById(reservationId);
        if (reservation == null) {
            return false;
        }
        
        int result = reservationMapper.deleteById(reservationId);
        
        if (result > 0) {
            // 更新讲座的已预约人数
            lectureService.decreaseEnrolledCount(reservation.getLectureId());
            
            // 记录操作日志
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "删除预约记录", "预约管理", 
                "删除了用户 [" + reservation.getUserName() + "] 对讲座 [" + reservation.getLectureTitle() + "] 的预约记录");
            operationLogMapper.insert(log);
            
            // 发送取消通知给用户
            notificationService.sendReservationCancelledNotification(
                reservation.getLectureId(),
                reservation.getLectureTitle(),
                reservation.getUserId()
            );
            
            return true;
        }
        
        return false;
    }
    
    /**
     * 获取用户最近的预约
     */
    public List<Reservation> getRecentUserReservations(Long userId, int limit) {
        List<Reservation> reservations = reservationMapper.findByUserId(userId);
        return reservations.stream().limit(limit).toList();
    }
    
    /**
     * 获取即将开始的讲座预约
     */
    public List<Reservation> getUpcomingReservations(Long userId) {
        List<Reservation> reservations = reservationMapper.findByUserId(userId);
        return reservations.stream()
                .filter(r -> r.getLectureTime() != null && 
                           r.getLectureTime().isAfter(java.time.LocalDateTime.now()))
                .sorted((r1, r2) -> r1.getLectureTime().compareTo(r2.getLectureTime()))
                .toList();
    }
    
    /**
     * 分页查询所有预约（管理员用）
     */
    public PageInfo<Reservation> getAllReservationsByPage(int pageNum, int pageSize) {
        int offset = (pageNum - 1) * pageSize;
        List<Reservation> reservations = reservationMapper.findAllPage(offset, pageSize);
        int total = reservationMapper.countAll();
        return new PageInfo<>(reservations, pageNum, pageSize, total);
    }
    
    /**
     * 获取预约统计
     */
    public int getTotalReservationCount() {
        return reservationMapper.countAll();
    }
    
    /**
     * 分页查询某讲座的预约（管理员用）
     */
    public PageInfo<Reservation> getReservationsByLecturePage(Long lectureId, int pageNum, int pageSize) {
        int offset = (pageNum - 1) * pageSize;
        List<Reservation> reservations = reservationMapper.findByLectureIdPage(lectureId, offset, pageSize);
        
        // 检查并更新讲座的过期状态
        if (!reservations.isEmpty()) {
            Reservation firstReservation = reservations.get(0);
            if ("approved".equals(firstReservation.getLectureStatus()) && firstReservation.getLectureTime() != null) {
                Lecture lecture = lectureService.getLectureById(lectureId);
                if (lecture != null && lecture.isExpired()) {
                    lecture.setStatus("expired");
                    lectureMapper.update(lecture);
                    // 更新所有预约对象中的讲座状态
                    for (Reservation reservation : reservations) {
                        reservation.setLectureStatus("expired");
                    }
                }
            }
        }
        
        int total = reservationMapper.countByLectureId(lectureId);
        return new PageInfo<>(reservations, pageNum, pageSize, total);
    }
}