package org.stu.stulecture.mapper;

import org.apache.ibatis.annotations.*;
import org.stu.stulecture.entity.User;

import java.util.List;

/**
 * 用户数据访问接口
 * 使用MyBatis注解方式操作数据库
 */
@Mapper
public interface UserMapper {

    /**
     * 插入新用户
     */
    @Insert("INSERT INTO users (username, password, role, name, email, phone, department, major, grade, avatar, bio, position, status, created_time) " +
            "VALUES (#{username}, #{password}, #{role}, #{name}, #{email}, #{phone}, #{department}, #{major}, #{grade}, #{avatar}, #{bio}, #{position}, #{status}, NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "userId")
    int insert(User user);

    /**
     * 根据ID查询用户
     */
    @Select("SELECT * FROM users WHERE user_id = #{userId}")
    User findById(Long userId);

    /**
     * 根据用户名查询用户
     */
    @Select("SELECT * FROM users WHERE username = #{username}")
    User findByUsername(String username);

    /**
     * 查询所有用户
     */
    @Select("SELECT * FROM users ORDER BY created_time DESC")
    List<User> findAll();

    /**
     * 根据角色查询用户
     */
    @Select("SELECT * FROM users WHERE role = #{role} ORDER BY created_time DESC")
    List<User> findByRole(String role);

    /**
     * 根据状态查询用户
     */
    @Select("SELECT * FROM users WHERE status = #{status} ORDER BY created_time DESC")
    List<User> findByStatus(Integer status);

    /**
     * 更新用户信息
     * 使用条件判断更新，避免空值覆盖已有数据
     * 包含role和status字段更新
     */
    @Update("<script>" +
            "UPDATE users SET " +
            "<if test=\"name != null\">name = #{name},</if>" +
            "<if test=\"email != null\">email = #{email},</if>" +
            "<if test=\"phone != null\">phone = #{phone},</if>" +
            "<if test=\"department != null\">department = #{department},</if>" +
            "<if test=\"major != null\">major = #{major},</if>" +
            "<if test=\"grade != null\">grade = #{grade},</if>" +
            "<if test=\"avatar != null\">avatar = #{avatar},</if>" +
            "<if test=\"bio != null\">bio = #{bio},</if>" +
            "<if test=\"position != null\">position = #{position},</if>" +
            "<if test=\"role != null\">role = #{role},</if>" +
            "<if test=\"status != null\">status = #{status},</if>" +
            "updated_time = NOW() " +
            "WHERE user_id = #{userId}" +
            "</script>")
    int update(User user);

    /**
     * 更新用户密码
     */
    @Update("UPDATE users SET password = #{password}, updated_time = NOW() WHERE user_id = #{userId}")
    int updatePassword(@Param("userId") Long userId, @Param("password") String password);

    /**
     * 删除用户
     */
    @Delete("DELETE FROM users WHERE user_id = #{userId}")
    int deleteById(Long userId);
    
    /**
     * 多条件搜索用户
     * 使用动态 SQL 根据提供的条件进行搜索
     */
    @Select("<script>" +
            "SELECT * FROM users WHERE 1=1 " +
            "<if test='username != null and username != \"\"'>" +
            "AND username LIKE CONCAT('%', #{username}, '%') " +
            "</if>" +
            "<if test='role != null and role != \"\"'>" +
            "AND role = #{role} " +
            "</if>" +
            "<if test='status != null'>" +
            "AND status = #{status} " +
            "</if>" +
            "ORDER BY created_time DESC" +
            "</script>")
    List<User> searchUsers(@Param("username") String username,
                          @Param("role") String role,
                          @Param("status") Integer status);
        
    /**
     * 分页查询用户
     */
    @Select("<script>" +
            "SELECT * FROM users WHERE 1=1 " +
            "<if test='username != null and username != \"\"'>" +
            "AND username LIKE CONCAT('%', #{username}, '%') " +
            "</if>" +
            "<if test='role != null and role != \"\"'>" +
            "AND role = #{role} " +
            "</if>" +
            "<if test='status != null'>" +
            "AND status = #{status} " +
            "</if>" +
            "ORDER BY created_time DESC " +
            "LIMIT #{offset}, #{pageSize}" +
            "</script>")
    List<User> searchUsersByPage(@Param("username") String username,
                                @Param("role") String role,
                                @Param("status") Integer status,
                                @Param("offset") int offset,
                                @Param("pageSize") int pageSize);
        
    /**
     * 统计搜索结果的总数
     */
    @Select("<script>" +
            "SELECT COUNT(*) FROM users WHERE 1=1 " +
            "<if test='username != null and username != \"\"'>" +
            "AND username LIKE CONCAT('%', #{username}, '%') " +
            "</if>" +
            "<if test='role != null and role != \"\"'>" +
            "AND role = #{role} " +
            "</if>" +
            "<if test='status != null'>" +
            "AND status = #{status} " +
            "</if>" +
            "</script>")
    int countSearchUsers(@Param("username") String username,
                        @Param("role") String role,
                        @Param("status") Integer status);
    
    /**
     * 根据用户名模糊搜索
     */
    @Select("SELECT * FROM users WHERE username LIKE CONCAT('%', #{username}, '%') ORDER BY created_time DESC")
    List<User> findByUsernameLike(String username);
    
    /**
     * 统计用户总数
     */
    @Select("SELECT COUNT(*) FROM users")
    int countTotal();
    
    /**
     * 根据角色统计用户数
     */
    @Select("SELECT COUNT(*) FROM users WHERE role = #{role}")
    int countByRole(String role);
    
    /**
     * 根据状态统计用户数
     */
    @Select("SELECT COUNT(*) FROM users WHERE status = #{status}")
    int countByStatus(Integer status);
}