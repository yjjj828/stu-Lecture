package org.stu.stulecture.entity;

import java.time.LocalDateTime;

/**
 * 预约实体类
 * 对应数据库reservations表
 */
public class Reservation {
    private Long reservationId; // 预约ID
    private Long userId;        // 用户ID
    private Long lectureId;     // 讲座ID
    private String status;      // 预约状态：confirmed/cancelled
    private Boolean reminded1day; // 是否已发送1天提醒
    private Boolean reminded2hours; // 是否已发送2小时提醒
    private LocalDateTime applyTime; // 申请时间
    private String checkinStatus;  // 签到状态：NULL-未签到 checked-已签到
    private LocalDateTime checkinTime; // 签到时间
    
    // 扩展属性（不在数据库中，用于页面显示）
    private String userName;    // 用户姓名
    private String userUsername; // 用户账号
    private String userDepartment; // 用户院系
    private String lectureTitle; // 讲座标题
    private LocalDateTime lectureTime; // 讲座时间
    private String location;    // 讲座地点
    private Integer lectureDuration; // 讲座时长（分钟）
    private String notice;      // 注意事项（来自讲座）
    private String lectureStatus; // 讲座状态（用于判断讲座是否过期）
    
    // 构造函数
    public Reservation() {}
    
    public Reservation(Long userId, Long lectureId) {
        this.userId = userId;
        this.lectureId = lectureId;
        this.status = "confirmed";  // 预约成功即为已确认
        this.applyTime = LocalDateTime.now();
    }
    
    // Getter和Setter方法
    public Long getReservationId() { return reservationId; }
    public void setReservationId(Long reservationId) { this.reservationId = reservationId; }
    
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    
    public Long getLectureId() { return lectureId; }
    public void setLectureId(Long lectureId) { this.lectureId = lectureId; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Boolean getReminded1day() { return reminded1day; }
    public void setReminded1day(Boolean reminded1day) { this.reminded1day = reminded1day; }
    
    public Boolean getReminded2hours() { return reminded2hours; }
    public void setReminded2hours(Boolean reminded2hours) { this.reminded2hours = reminded2hours; }
    
    public boolean isReminded1day() { return reminded1day != null && reminded1day; }
    public boolean isReminded2hours() { return reminded2hours != null && reminded2hours; }
    
    public LocalDateTime getApplyTime() { return applyTime; }
    public void setApplyTime(LocalDateTime applyTime) { this.applyTime = applyTime; }
    
    public String getCheckinStatus() { return checkinStatus; }
    public void setCheckinStatus(String checkinStatus) { this.checkinStatus = checkinStatus; }
    
    public LocalDateTime getCheckinTime() { return checkinTime; }
    public void setCheckinTime(LocalDateTime checkinTime) { this.checkinTime = checkinTime; }
    
    // 扩展属性的Getter和Setter
    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
    
    public String getUserUsername() { return userUsername; }
    public void setUserUsername(String userUsername) { this.userUsername = userUsername; }
    
    public String getUserDepartment() { return userDepartment; }
    public void setUserDepartment(String userDepartment) { this.userDepartment = userDepartment; }
    
    public String getLectureTitle() { return lectureTitle; }
    public void setLectureTitle(String lectureTitle) { this.lectureTitle = lectureTitle; }
    
    public LocalDateTime getLectureTime() { return lectureTime; }
    public void setLectureTime(LocalDateTime lectureTime) { this.lectureTime = lectureTime; }
    
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    
    public Integer getLectureDuration() { return lectureDuration; }
    public void setLectureDuration(Integer lectureDuration) { this.lectureDuration = lectureDuration; }
    
    public String getNotice() { return notice; }
    public void setNotice(String notice) { this.notice = notice; }
    
    public String getLectureStatus() { return lectureStatus; }
    public void setLectureStatus(String lectureStatus) { this.lectureStatus = lectureStatus; }
    
    // 获取状态的中文描述
    public String getStatusDescription() {
        // 如果讲座已过期，显示特殊状态
        if ("expired".equals(lectureStatus)) {
            return "已过期";
        }
        
        switch (status) {
            case "confirmed": return "已确认";
            case "cancelled": return "已取消";
            default: return "未知状态";
        }
    }
    
    // 判断讲座是否已过期
    public boolean isLectureExpired() {
        return "expired".equals(lectureStatus);
    }
    
    // 判断是否可以取消预约（讲座未过期且预约状态为已确认）
    public boolean canCancel() {
        return "confirmed".equals(status) && !"expired".equals(lectureStatus);
    }
    
    // 判断是否已签到
    public boolean isCheckedIn() {
        return "checked".equals(checkinStatus);
    }
    
    // 获取签到状态描述
    public String getCheckinStatusDescription() {
        if (isLectureExpired()) {
            return isCheckedIn() ? "已签到" : "未签到";
        }
        return null; // 讲座未开始时返回null，不显示签到状态
    }
    
    @Override
    public String toString() {
        return "Reservation{" +
                "reservationId=" + reservationId +
                ", userId=" + userId +
                ", lectureId=" + lectureId +
                ", status='" + status + '\'' +
                ", applyTime=" + applyTime +
                '}';
    }
}