package org.stu.stulecture.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.HttpSession;
import org.stu.stulecture.entity.Lecture;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.entity.Notification;
import org.stu.stulecture.service.LectureService;
import org.stu.stulecture.service.NotificationService;
import org.stu.stulecture.service.ReservationService;

import java.util.List;


@Controller
public class IndexController {
    
    @Autowired
    private LectureService lectureService;
    
    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private ReservationService reservationService;

    @GetMapping("/")
    public String index(Model model, 
                      @RequestParam(required = false) String loginSuccess,
                      HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        model.addAttribute("pageTitle", "首页");
        model.addAttribute("user", user);
        
        // 如果有登录成功参数，传递给页面
        if (loginSuccess != null && "true".equals(loginSuccess)) {
            model.addAttribute("loginSuccess", true);
        }
        
        // 获取统计数据
        int totalLectures = lectureService.getTotalLectureCount();
        model.addAttribute("totalLectures", totalLectures);
        
        // 获取最新讲座（最新的 5 条，已通过审核的）
        List<Lecture> latestLectures = lectureService.getLatestLectures(5);
        model.addAttribute("latestLectures", latestLectures);

        // 获取最新通知（最新的 3 条）
        if (user != null) {
            List<Notification> notifications = notificationService.getUserNotifications(user.getUserId(), 1, 3).getList();
            model.addAttribute("notifications", notifications);
        } else {
            // 未登录用户显示系统公告（如果有公共通知的话）
            model.addAttribute("notifications", new java.util.ArrayList<>());
        }
        
        return "index";
    }

    @GetMapping("/teacher/dashboard")
    public String teacherDashboard(Model model, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }
        
        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "教师中心");
        
        // 获取该教师的讲座列表
        java.util.List<Lecture> myLectures = lectureService.getLecturesBySpeaker(currentUser.getUserId());
        model.addAttribute("myLectures", myLectures);
        model.addAttribute("lectureCount", myLectures.size());
        
        // 统计数据
        long totalBookings = myLectures.stream()
                .mapToInt(lecture -> lecture.getEnrolledCount() != null ? lecture.getEnrolledCount() : 0)
                .sum();
        model.addAttribute("totalBookings", totalBookings);
        
        // 待审核讲座数量
        long pendingCount = myLectures.stream()
                .filter(lecture -> "pending".equals(lecture.getStatus()))
                .count();
        model.addAttribute("pendingCount", pendingCount);
        
        // 已完成讲座数量（已批准的状态）
        long completedCount = myLectures.stream()
                .filter(lecture -> "approved".equals(lecture.getStatus()))
                .count();
        model.addAttribute("completedCount", completedCount);
        
        return "teacher/dashboard";
    }
}