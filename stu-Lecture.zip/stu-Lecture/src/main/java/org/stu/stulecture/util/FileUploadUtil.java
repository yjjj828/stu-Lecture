package org.stu.stulecture.util;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

/**
 * 文件上传工具类
 * 提供通用的文件上传功能
 */
public class FileUploadUtil {
    
    // 最大文件大小：5MB
    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024;
    
    // 允许的图片扩展名
    private static final String[] ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp"};
    
    /**
     * 上传文件
     * @param file 上传的文件
     * @param uploadDir 上传目录（相对于项目根目录）
     * @return 保存的文件名（UUID 生成）
     * @throws IOException 上传失败时抛出异常
     */
    public static String uploadFile(MultipartFile file, String uploadDir) throws IOException {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("上传文件不能为空");
        }
        
        // 检查文件大小
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new IOException("文件大小不能超过 5MB");
        }
        
        // 检查文件扩展名
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || originalFilename.trim().isEmpty()) {
            throw new IOException("文件名不能为空");
        }
        
        String extension = getFileExtension(originalFilename);
        if (!isAllowedImageExtension(extension)) {
            throw new IOException("不支持的文件格式，仅支持：JPG, JPEG, PNG, GIF, BMP, WEBP");
        }
        
        // 获取项目根路径
        String rootPath = System.getProperty("user.dir");
        String targetDir = rootPath + "/" + uploadDir;
        
        // 创建目录
        File dir = new File(targetDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        
        // 生成唯一文件名
        String filename = UUID.randomUUID().toString() + extension;
        
        // 保存文件
        Path filePath = Paths.get(targetDir + "/" + filename);
        Files.write(filePath, file.getBytes());
        
        return filename;
    }
    
    /**
     * 获取文件扩展名
     */
    private static String getFileExtension(String filename) {
        int lastDotIndex = filename.lastIndexOf(".");
        if (lastDotIndex == -1) {
            return "";
        }
        return filename.substring(lastDotIndex).toLowerCase();
    }
    
    /**
     * 检查文件扩展名是否允许
     */
    private static boolean isAllowedImageExtension(String extension) {
        if (extension == null || extension.isEmpty()) {
            return false;
        }
        for (String allowedExt : ALLOWED_IMAGE_EXTENSIONS) {
            if (allowedExt.equals(extension)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 删除文件
     * @param filename 文件名
     * @param uploadDir 上传目录（相对于项目根目录）
     * @return 是否删除成功
     */
    public static boolean deleteFile(String filename, String uploadDir) {
        if (filename == null || filename.trim().isEmpty()) {
            return false;
        }
        
        String rootPath = System.getProperty("user.dir");
        String filePath = rootPath + "/" + uploadDir + "/" + filename;
        
        File file = new File(filePath);
        if (file.exists()) {
            return file.delete();
        }
        return false;
    }
}
