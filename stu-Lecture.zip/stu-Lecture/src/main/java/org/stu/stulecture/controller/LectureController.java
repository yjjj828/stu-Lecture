package org.stu.stulecture.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.stu.stulecture.entity.Lecture;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.entity.Venue;
import org.stu.stulecture.mapper.ReservationMapper;
import org.stu.stulecture.service.LectureService;
import org.stu.stulecture.service.ReservationService;
import org.stu.stulecture.service.VenueService;
import org.stu.stulecture.util.FileUploadUtil;
import org.stu.stulecture.util.PageInfo;

import jakarta.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * 讲座相关请求处理
 */
@Controller
@RequestMapping("/lecture")
public class LectureController {

    @Autowired
    private LectureService lectureService;

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private VenueService venueService;

    @Autowired
    private ReservationMapper reservationMapper;

    /**
     * 展示讲座列表，支持多条件筛选
     */
    @GetMapping("/list")
    public String lectureList(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String timeRange,
            @RequestParam(required = false) String date,
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "5") int pageSize,
            Model model,
            HttpSession session) {

        model.addAttribute("user", session.getAttribute("currentUser"));
        model.addAttribute("pageTitle", "讲座列表");

        List<Lecture> lectureDataList;
        if (keyword != null && !keyword.trim().isEmpty()) {
            lectureDataList = lectureService.searchLectures(keyword);
        } else if (category != null && !category.isEmpty()) {
            lectureDataList = lectureService.getLecturesByCategory(category);
        } else {
            lectureDataList = lectureService.getLecturesByStatus("approved");
        }

        // 排除已过期的讲座
        lectureDataList = lectureDataList.stream()
                .filter(item -> !"expired".equals(item.getStatus()))
                .collect(Collectors.toList());

        // 标记用户预约状态
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser != null) {
            for (Lecture item : lectureDataList) {
                boolean hasReserved = reservationService.hasUserReservedLecture(currentUser.getUserId(), item.getLectureId());
                item.setReserved(hasReserved);
                item.setBookable(item.canBeBooked());
            }
        } else {
            for (Lecture item : lectureDataList) {
                item.setBookable(item.canBeBooked());
            }
        }

        // 按具体日期过滤
        if (date != null && !date.isEmpty()) {
            try {
                LocalDateTime targetDate = LocalDateTime.parse(date + " 00:00",
                        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
                LocalDateTime nextDay = targetDate.plusDays(1);

                lectureDataList = lectureDataList.stream()
                        .filter(item -> item.getLectureTime() != null &&
                                !item.getLectureTime().isBefore(targetDate) &&
                                item.getLectureTime().isBefore(nextDay))
                        .toList();
            } catch (Exception e) {
                // 日期格式不对则跳过此条件
            }
        }

        // 按时间范围筛选
        if (timeRange != null && !timeRange.isEmpty()) {
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime endTime;

            switch (timeRange) {
                case "today" -> endTime = now.with(LocalTime.MAX);
                case "week" -> endTime = now.plusDays(7);
                case "month" -> endTime = now.plusMonths(1);
                default -> endTime = now.plusYears(1);
            }

            LocalDateTime finalEndTime = endTime;
            lectureDataList = lectureDataList.stream()
                    .filter(item -> item.getLectureTime() != null &&
                            item.getLectureTime().isAfter(now) &&
                            item.getLectureTime().isBefore(finalEndTime))
                    .toList();
        }

        // 分页处理
        int total = lectureDataList.size();
        int fromIndex = (pageNum - 1) * pageSize;
        int toIndex = Math.min(fromIndex + pageSize, total);
        List<Lecture> pageData = lectureDataList.subList(fromIndex, toIndex);

        PageInfo<Lecture> pageInfo = new PageInfo<>(pageData, pageNum, pageSize, total);

        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("pageSize", pageSize);

        model.addAttribute("keyword", keyword);
        model.addAttribute("category", category);
        model.addAttribute("timeRange", timeRange);
        model.addAttribute("searchDate", date);

        return "lecture/list";
    }

    /**
     * 查看讲座详情
     */
    @GetMapping("/detail")
    public String lectureDetail(@RequestParam(required = false) Long id, Model model, HttpSession session) {
        if (id == null) {
            return "redirect:/lecture/list";
        }

        Lecture lecture = lectureService.getLectureById(id);
        if (lecture == null) {
            model.addAttribute("error", "讲座不存在");
            return "error/404";
        }

        // 标记可预约状态
        lecture.setBookable(lecture.canBeBooked());

        User currentUser = (User) session.getAttribute("currentUser");
        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", lecture.getTitle());
        model.addAttribute("lecture", lecture);

        // 查询预约情况
        boolean hasReserved = false;
        Long reservationId = null;
        String checkinStatus = null;
        if (currentUser != null) {
            hasReserved = reservationService.hasUserReservedLecture(currentUser.getUserId(), lecture.getLectureId());
            if (hasReserved) {
                var reservation = reservationMapper.findByUserAndLecture(currentUser.getUserId(), lecture.getLectureId());
                if (reservation != null && "confirmed".equals(reservation.getStatus())) {
                    reservationId = reservation.getReservationId();
                    checkinStatus = reservation.getCheckinStatus();
                }
            }
        }
        model.addAttribute("hasReserved", hasReserved);
        model.addAttribute("reservationId", reservationId);
        model.addAttribute("checkinStatus", checkinStatus);

        // 状态文本转换
        model.addAttribute("statusDesc", lectureService.getStatusDescription(lecture.getStatus()));
        model.addAttribute("formatDesc", lectureService.getFormatDescription(lecture.getFormat()));

        return "lecture/detail";
    }

    /**
     * 展示发布讲座表单
     */
    @GetMapping("/publish")
    public String showPublishPage(Model model, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }

        // 只有教师和管理员可以发布讲座
        if (!("teacher".equals(currentUser.getRole()) || "admin".equals(currentUser.getRole()))) {
            model.addAttribute("error", "只有教师和管理员可以发布讲座");
            return "error/403";
        }

        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "发布讲座");

        // 获取可用场地列表
        List<Venue> availableVenues = venueService.getAvailableVenues();
        model.addAttribute("availableVenues", availableVenues);

        return "lecture/publish";
    }

    /**
     * 处理发布讲座请求
     */
    @PostMapping("/publish")
    public String publishLecture(
            @RequestParam String title,
            @RequestParam String speaker,
            @RequestParam String category,
            @RequestParam String date,
            @RequestParam String time,
            @RequestParam(required = false) Integer duration,
            @RequestParam String location,
            @RequestParam(required = false) Long venueId,
            @RequestParam Integer capacity,
            @RequestParam String description,
            @RequestParam String format,
            @RequestParam(required = false) String notice,
            @RequestParam(required = false) MultipartFile poster,
            HttpSession session,
            Model model) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }

        // 验证容量是否超过场地限制
        if (venueId != null) {
            Venue venue = venueService.getVenueById(venueId);
            if (venue != null && venue.getCapacity() != null && capacity > venue.getCapacity()) {
                model.addAttribute("error", "预约人数上限不能超过场地容量（" + venue.getCapacity() + "人）");
                model.addAttribute("user", currentUser);
                model.addAttribute("pageTitle", "发布讲座");
                List<Venue> availableVenues = venueService.getAvailableVenues();
                model.addAttribute("availableVenues", availableVenues);
                return "lecture/publish";
            }
        }

        try {
            // 组合日期和时间
            LocalDateTime lectureTime = LocalDateTime.parse(date + " " + time,
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));

            // 创建讲座对象
            Lecture lecture = new Lecture();
            lecture.setTitle(title);
            lecture.setSpeakerId(currentUser.getUserId());
            lecture.setDescription(description);
            lecture.setLectureTime(lectureTime);
            lecture.setLocation(location);
            lecture.setVenueId(venueId);
            lecture.setCapacity(capacity);
            lecture.setCategory(category);
            lecture.setDuration(duration != null ? duration : 90); // 默认 90 分钟
            lecture.setFormat(format); // 设置讲座形式
            lecture.setNotice(notice); // 设置注意事项
            lecture.setStatus("pending"); // 默认待审核状态

            // 处理海报上传（必须成功才能继续）
            if (poster != null && !poster.isEmpty()) {
                try {
                    String posterFilename = FileUploadUtil.uploadFile(poster, "src/main/resources/static/poster");
                    lecture.setPoster(posterFilename);
                } catch (Exception e) {
                    model.addAttribute("error", "海报上传失败：" + e.getMessage());
                    model.addAttribute("user", currentUser);
                    model.addAttribute("pageTitle", "发布讲座");
                    return "lecture/publish";
                }
            }

            // 保存讲座
            boolean success = lectureService.publishLecture(lecture, currentUser.getUserId(), currentUser.getName());

            if (success) {
                // 发布成功，重定向到教师中心并显示成功消息
                return "redirect:/teacher/dashboard?success=" + encodeUrlParam("讲座发布成功，等待管理员审核");
            } else {
                // 发布失败，返回发布页并显示错误
                model.addAttribute("error", "发布失败，请重试");
            }

        } catch (org.springframework.web.multipart.MaxUploadSizeExceededException e) {
            // 文件大小超限
            model.addAttribute("error", "海报文件大小不能超过 5MB，请重新选择");
        } catch (Exception e) {
            model.addAttribute("error", "发布失败：" + e.getMessage());
        }

        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "发布讲座");
        return "lecture/publish";
    }

    /**
     * 教师讲座管理页面
     */
    @GetMapping("/my")
    public String myLectures(HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }

        if (!("teacher".equals(currentUser.getRole()) || "admin".equals(currentUser.getRole()))) {
            return "redirect:/";
        }

        // 重定向到教师中心，由 IndexController 处理数据
        return "redirect:/teacher/dashboard";
    }

    /**
     * 删除讲座
     */
    @PostMapping("/delete/{id}")
    public String deleteLecture(@PathVariable Long id, HttpSession session) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }

        Lecture lecture = lectureService.getLectureById(id);
        if (lecture == null) {
            return "redirect:/lecture/my";
        }

        // 权限检查
        if (!lecture.getSpeakerId().equals(currentUser.getUserId()) &&
                !"admin".equals(currentUser.getRole())) {
            return "redirect:/lecture/my";
        }

        lectureService.deleteLecture(id, currentUser.getUserId(), currentUser.getName());

        return "redirect:/lecture/my";
    }

    /**
     * 预约讲座（表单提交模式）
     */
    @PostMapping("/book/{id}")
    public String bookLecture(@PathVariable Long id,
                              @RequestParam(required = false, defaultValue = "detail") String source,
                              HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }

        try {
            boolean success = reservationService.bookLecture(currentUser.getUserId(), currentUser.getUsername(), id);
            if (success) {
                // 根据来源页面决定返回位置
                if ("list".equals(source)) {
                    // 从列表页预约，返回列表页
                    return "redirect:/lecture/list?success=" + encodeUrlParam("预约成功");
                } else {
                    // 从详情页预约，返回详情页
                    return "redirect:/lecture/detail?id=" + id + "&success=" + encodeUrlParam("预约成功");
                }
            } else {
                // 预约失败
                if ("list".equals(source)) {
                    return "redirect:/lecture/list?error=" + encodeUrlParam("预约失败，可能已满员或已预约");
                }
                return "redirect:/lecture/detail?id=" + id + "&error=" + encodeUrlParam("预约失败，可能已满员或已预约");
            }
        } catch (Exception e) {
            if ("list".equals(source)) {
                return "redirect:/lecture/list?error=" + encodeUrlParam("预约失败，请稍后重试");
            }
            return "redirect:/lecture/detail?id=" + id + "&error=" + encodeUrlParam("预约失败，请稍后重试");
        }
    }

    /**
     * 取消预约（表单提交）
     */
    @PostMapping("/cancel/{reservationId}")
    public String cancelReservation(@PathVariable Long reservationId,
                                    @RequestParam(required = false, defaultValue = "detail") String source,
                                    HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }

        try {
            // 获取预约信息以便返回详情页
            var reservation = reservationService.getReservationById(reservationId);
            Long lectureId = reservation != null ? reservation.getLectureId() : null;

            boolean success = reservationService.cancelReservation(reservationId, currentUser.getUserId(), currentUser.getUsername());
            if (success) {
                // 根据来源页面决定返回位置
                if ("profile".equals(source)) {
                    // 从我的预约页取消，返回我的预约页
                    return "redirect:/user/profile?success=" + encodeUrlParam("取消预约成功");
                } else if ("detail".equals(source)) {
                    // 从详情页取消，返回详情页
                    if (lectureId != null) {
                        return "redirect:/lecture/detail?id=" + lectureId + "&success=" + encodeUrlParam("取消预约成功");
                    }
                    return "redirect:/lecture/list?success=" + encodeUrlParam("取消预约成功");
                } else {
                    // 默认返回我的预约页
                    return "redirect:/user/profile?success=" + encodeUrlParam("取消预约成功");
                }
            } else {
                // 取消失败
                if ("profile".equals(source)) {
                    return "redirect:/user/profile?error=" + encodeUrlParam("取消失败，请稍后重试");
                }
                if (lectureId != null) {
                    return "redirect:/lecture/detail?id=" + lectureId + "&error=" + encodeUrlParam("取消失败，请稍后重试");
                }
                return "redirect:/lecture/list?error=" + encodeUrlParam("取消失败，请稍后重试");
            }
        } catch (Exception e) {
            if ("profile".equals(source)) {
                return "redirect:/user/profile?error=" + encodeUrlParam("操作异常，请稍后重试");
            }
            return "redirect:/lecture/list?error=" + encodeUrlParam("操作异常，请稍后重试");
        }
    }
    
    /**
     * URL 参数编码辅助方法
     */
    private String encodeUrlParam(String param) {
        try {
            return java.net.URLEncoder.encode(param, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            return param;
        }
    }
}