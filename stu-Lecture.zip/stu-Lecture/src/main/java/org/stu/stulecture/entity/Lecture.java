package org.stu.stulecture.entity;

import java.time.LocalDateTime;

/**
 * 讲座实体类
 * 对应数据库lectures表
 */
public class Lecture {
    private Long lectureId;     // 讲座 ID
    private String title;         // 讲座标题
    private String description;   // 讲座描述
    private String poster;        // 海报图片路径
    private LocalDateTime lectureTime;  // 讲座时间
    private String location;      // 讲座地点
    private Integer capacity;     // 容量
    private Integer enrolledCount; // 已预约人数
    private Long speakerId;       // 主讲人 ID
    private String status;        // 状态：pending-待审核 approved-已通过 expired-已失效
    private String category;    // 分类
    private Integer duration;   // 讲座时长 (分钟)
    private String format;      // 讲座形式：offline/online/hybrid
    private String notice;      // 注意事项
    private Long venueId;       // 场地 ID
    private LocalDateTime createdTime; // 创建时间
    private LocalDateTime updatedTime; // 更新时间
    
    // 扩展属性（不在数据库中，用于页面显示）
    private String speakerName; // 主讲人姓名
    private String speakerDepartment; // 主讲人院系
    private String speakerAvatar; // 主讲人头像
    private String speakerBio; // 主讲人简介
    private boolean reserved; // 用户是否已预约该讲座
    private String venueName; // 场地名称
    private boolean bookable; // 是否可预约
    
    // 构造函数
    public Lecture() {}
    
    public Lecture(String title, Long speakerId, String description, LocalDateTime lectureTime, 
                   String location, Integer capacity, String category) {
       this.title = title;
       this.speakerId = speakerId;
       this.description = description;
       this.lectureTime= lectureTime;
       this.location = location;
       this.capacity = capacity;
       this.category = category;
       this.enrolledCount = 0;
       this.status = "pending";  // 默认状态为待审核
    }
    
    // Getter和Setter方法
    public Long getLectureId() { return lectureId; }
    public void setLectureId(Long lectureId) { this.lectureId = lectureId; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public Long getSpeakerId() { return speakerId; }
    public void setSpeakerId(Long speakerId) { this.speakerId = speakerId; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getPoster() { return poster; }
    public void setPoster(String poster) { this.poster = poster; }
    
    public LocalDateTime getLectureTime() { return lectureTime; }
    public void setLectureTime(LocalDateTime lectureTime) { this.lectureTime = lectureTime; }
    
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    
    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    
    public Integer getEnrolledCount() { return enrolledCount; }
    public void setEnrolledCount(Integer enrolledCount) { this.enrolledCount = enrolledCount; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    
    public Integer getDuration() { return duration; }
    public void setDuration(Integer duration) { this.duration = duration; }
    
    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }
    
    public String getNotice() { return notice; }
    public void setNotice(String notice) { this.notice = notice; }
    
    public Long getVenueId() { return venueId; }
    public void setVenueId(Long venueId) { this.venueId = venueId; }
    
    public LocalDateTime getCreatedTime() { return createdTime; }
    public void setCreatedTime(LocalDateTime createdTime) { this.createdTime = createdTime; }
    
    public LocalDateTime getUpdatedTime() { return updatedTime; }
    public void setUpdatedTime(LocalDateTime updatedTime) { this.updatedTime = updatedTime; }
    
    // 扩展属性的Getter和Setter
    public String getSpeakerName() { return speakerName; }
    public void setSpeakerName(String speakerName) { this.speakerName = speakerName; }
    
    public String getSpeakerDepartment() { return speakerDepartment; }
    public void setSpeakerDepartment(String speakerDepartment) { this.speakerDepartment = speakerDepartment; }
    
    public String getSpeakerAvatar() { return speakerAvatar; }
    public void setSpeakerAvatar(String speakerAvatar) { this.speakerAvatar = speakerAvatar; }
    
    public String getSpeakerBio() { return speakerBio; }
    public void setSpeakerBio(String speakerBio) { this.speakerBio = speakerBio; }
    
    public boolean isReserved() { return reserved; }
    public void setReserved(boolean reserved) { this.reserved = reserved; }
    
    public String getVenueName() { return venueName; }
    public void setVenueName(String venueName) { this.venueName = venueName; }
    
    // bookable 字段的 getter/setter（用于页面显示）
    public boolean isBookable() { return bookable; }
    public void setBookable(boolean bookable) { this.bookable = bookable; }
    
    // 计算剩余座位数
    public Integer getAvailableSeats() {
        if (capacity == null) {
            return 0;
        }
        // enrolledCount 为 null 时按 0 处理
        int count = (enrolledCount == null) ? 0 : enrolledCount;
        return Math.max(0, capacity - count);
    }
    
    // 判断是否已满员
    public boolean isFull() {
        if (capacity == null || capacity <= 0) {
            return true; // 容量未设置或为 0 时视为满员
        }
        int count = (enrolledCount == null) ? 0 : enrolledCount;
        return count >= capacity;
    }
    
    // 判断是否可预约（内部业务逻辑方法）
    public boolean canBeBooked() {
        // 必须同时满足：已通过、未过期、未满员
       return "approved".equals(status) && !isExpired() && !isFull();
   }
   
   // 判断是否已过期（基于讲座结束时间）
  public boolean isExpired() {
       if (lectureTime == null) {
           return false; // 时间未设置，不算过期
       }
       // 如果有 duration 字段，使用讲座时长计算结束时间
       if (duration != null && duration > 0) {
           LocalDateTime endTime = lectureTime.plusMinutes(duration);
           return LocalDateTime.now().isAfter(endTime);
       } else {
           // 如果没有 duration，默认使用开始时间作为过期时间
           return LocalDateTime.now().isAfter(lectureTime);
       }
   }
    
    @Override
    public String toString() {
        return "Lecture{" +
                "lectureId=" + lectureId +
                ", title='" + title + '\'' +
                ", speakerId=" + speakerId +
                ", lectureTime=" + lectureTime +
                ", location='" + location + '\'' +
                ", capacity=" + capacity +
                ", enrolledCount=" + enrolledCount +
                ", status='" + status + '\'' +
                ", category='" + category + '\'' +
                '}';
    }
}