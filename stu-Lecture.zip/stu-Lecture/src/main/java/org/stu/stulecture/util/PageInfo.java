package org.stu.stulecture.util;

import java.util.List;

/**
 * 分页信息封装类
 */
public class PageInfo<T> {
    private List<T> list;           // 当前页数据
    private int pageNum;            // 当前页码
    private int pageSize;           // 每页大小
    private int total;              // 总记录数
    private int pages;              // 总页数
    
    // 构造函数
    public PageInfo() {}
    
    public PageInfo(List<T> list, int pageNum, int pageSize, int total) {
        this.list = list;
        this.pageNum = pageNum;
        this.pageSize = pageSize;
        this.total = total;
        // 计算总页数，确保至少有 1 页（即使总数为 0）
        if (total == 0) {
            this.pages = 1;
        } else {
            this.pages = (int) Math.ceil((double) total / pageSize);
        }
    }
    
    // Getter和Setter方法
    public List<T> getList() { return list; }
    public void setList(List<T> list) { this.list = list; }
    
    public int getPageNum() { return pageNum; }
    public void setPageNum(int pageNum) { this.pageNum = pageNum; }
    
    public int getPageSize() { return pageSize; }
    public void setPageSize(int pageSize) { this.pageSize = pageSize; }
    
    public int getTotal() { return total; }
    public void setTotal(int total) { this.total = total; }
    
    public int getPages() { return pages; }
    public void setPages(int pages) { this.pages = pages; }
    
    // 工具方法
    public boolean isFirstPage() {
        return pageNum == 1;
    }
    
    public boolean isLastPage() {
        return pageNum == pages;
    }
    
    public boolean hasNextPage() {
        return pageNum < pages;
    }
    
    public boolean hasPreviousPage() {
        return pageNum > 1;
    }
    
    // 获取起始页码（固定显示最多3个连续页码）
    public int getStartPage() {
        int total = getPages();
        if (total <= 3) {
            return 1;
        }
        int start = pageNum - 1;
        return Math.max(start, 1);
    }
    
    // 获取结束页码
    public int getEndPage() {
        int total = getPages();
        if (total <= 3) {
            return total;
        }
        int end = pageNum + 1;
        return Math.min(end, total);
    }
    
    // 是否显示前置省略号
    public boolean showPreEllipsis() {
        return getPages() > 3 && pageNum > 2;
    }
    
    // 是否显示后置省略号
    public boolean showEndEllipsis() {
        return getPages() > 3 && pageNum < getPages() - 1;
    }
    
    // 获取第一页码（用于显示省略号后）
    public int getFirstPage() {
        return 1;
    }
    
    // 获取最后一页码
    public int getLastPage() {
        return getPages();
    }
}