package org.stu.stulecture.util;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.stu.stulecture.entity.OperationLog;

/**
 * Excel 导出工具类
 */
public class ExcelUtil {
    
    /**
     * 导出讲座预约名单为 Excel
     * 
     * @param lectureTitle 讲座标题
     * @param speakerName 主讲人姓名
     * @param lectureTime 讲座时间
     * @param location 地点
     * @param total 总人数
     * @param reservations 预约数据列表
     * @return Excel 文件的字节数组
     * @throws Exception 导出异常
     */
    public static byte[] exportReservationList(
            String lectureTitle,
            String speakerName,
            String lectureTime,
            String location,
            int total,
            List<Map<String, Object>> reservations) throws Exception {
        
        // 创建 Excel 工作簿
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("预约名单");
        
        // 创建标题样式
        CellStyle titleStyle = workbook.createCellStyle();
        Font titleFont = workbook.createFont();
        titleFont.setBold(true);
        titleFont.setFontHeightInPoints((short) 16);
        titleStyle.setFont(titleFont);
        
        // 创建标题行
        Row titleRow = sheet.createRow(0);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue("讲座预约名单");
        titleCell.setCellStyle(titleStyle);
        
        // 创建基本信息行
        int rowNum = 2;
        createInfoRow(sheet, rowNum++, "讲座名称：", lectureTitle);
        createInfoRow(sheet, rowNum++, "主讲人：", speakerName);
        createInfoRow(sheet, rowNum++, "时间地点：", lectureTime + " " + location);
        createInfoRow(sheet, rowNum++, "总预约人数：", String.valueOf(total));
        
        rowNum += 2; // 空一行
        
        // 创建表头
        Row headerRow = sheet.createRow(rowNum++);
        String[] headers = {"序号", "姓名"};
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerStyle.setFont(headerFont);
        
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }
        
        // 填充数据
        int index = 1;
        for (Map<String, Object> data : reservations) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(index++);
            row.createCell(1).setCellValue(getStringValue(data.get("name")));
        }
        
        // 自动调整列宽
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }
        
        // 写入输出流
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();
        
        return outputStream.toByteArray();
    }
    
    /**
     * 导出操作日志为 Excel
     * 
     * @param logs 操作日志列表
     * @return Excel 文件的字节数组
     * @throws Exception 导出异常
     */
    public static byte[] exportOperationLogs(List<OperationLog> logs) throws Exception {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("操作日志");
        
        // 创建表头样式
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setBorderBottom(BorderStyle.THIN);
        headerStyle.setBorderTop(BorderStyle.THIN);
        headerStyle.setBorderLeft(BorderStyle.THIN);
        headerStyle.setBorderRight(BorderStyle.THIN);
        
        // 创建单元格样式
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
        
        // 创建表头行
        Row headerRow = sheet.createRow(0);
        String[] headers = {"序号", "操作用户", "操作类型", "所属模块", "操作描述", "操作时间"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }
        
        // 填充数据
        int rowNum = 1;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        for (OperationLog log : logs) {
            Row row = sheet.createRow(rowNum++);
            
            Cell idCell = row.createCell(0);
            idCell.setCellValue(rowNum - 1);
            idCell.setCellStyle(cellStyle);
            
            Cell userCell = row.createCell(1);
            userCell.setCellValue(log.getUsername() != null ? log.getUsername() : "系统");
            userCell.setCellStyle(cellStyle);
            
            Cell operationCell = row.createCell(2);
            operationCell.setCellValue(log.getOperation());
            operationCell.setCellStyle(cellStyle);
            
            Cell moduleCell = row.createCell(3);
            moduleCell.setCellValue(log.getModule());
            moduleCell.setCellStyle(cellStyle);
            
            Cell descriptionCell = row.createCell(4);
            descriptionCell.setCellValue(log.getDescription());
            descriptionCell.setCellStyle(cellStyle);
            
            Cell timeCell = row.createCell(5);
            if (log.getCreateTime() != null) {
                timeCell.setCellValue(log.getCreateTime().format(formatter));
            }
            timeCell.setCellStyle(cellStyle);
        }
        
        // 自动调整列宽
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }
        
        // 写入输出流
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();
        
        return outputStream.toByteArray();
    }
    
    /**
     * 创建信息行
     */
    private static void createInfoRow(Sheet sheet, int rowNum, String label, String value) {
        Row row = sheet.createRow(rowNum);
        row.createCell(0).setCellValue(label);
        row.createCell(1).setCellValue(value);
    }
    
    /**
     * 安全获取字符串值
     */
    private static String getStringValue(Object obj) {
        return obj != null ? obj.toString() : "";
    }
}
