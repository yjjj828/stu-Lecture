package org.stu.stulecture.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.stu.stulecture.entity.Venue;
import org.stu.stulecture.entity.OperationLog;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.mapper.VenueMapper;
import org.stu.stulecture.mapper.LectureMapper;
import org.stu.stulecture.mapper.OperationLogMapper;
import org.stu.stulecture.mapper.UserMapper;
import org.stu.stulecture.util.PageInfo;

import java.util.List;

@Service
public class VenueService {
    
    @Autowired
    private VenueMapper venueMapper;
    
    @Autowired
    private OperationLogMapper operationLogMapper;
    
    @Autowired
    private LectureMapper lectureMapper;
    
    @Autowired
    private UserMapper userMapper;
    
    /**
     * 显示用户名：账号+姓名
     */
    private String formatUserName(Long userId) {
        if (userId == null) {
            return "系统";
        }
        User user = userMapper.findById(userId);
        if (user == null) {
            return "用户 ID:" + userId;
        }
        if (user.getName() != null && !user.getName().isEmpty()) {
            return user.getUsername() + "（" + user.getName() + "）";
        }
        return user.getUsername();
    }
    
    /**
     * 添加新场地
     */
    @Transactional
    public boolean addVenue(Venue venue, Long operatorId, String operatorName) {
        boolean result = venueMapper.insert(venue) > 0;
        
        if (result) {
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "添加场地", "场地管理", 
                "添加新场地 [" + venue.getName() + "] （容纳" + venue.getCapacity() + "人）");
            operationLogMapper.insert(log);
        }
        
        return result;
    }
    
    /**
     * 按ID查询场地
     */
    public Venue getVenueById(Long venueId) {
        return venueMapper.findById(venueId);
    }
    
    /**
     * 查询全部场地
     */
    public List<Venue> getAllVenues() {
        return venueMapper.findAll();
    }
    
    /**
     * 查询可用场地
     */
    public List<Venue> getAvailableVenues() {
        return venueMapper.findByStatus(1);
    }
    
    /**
     * 按状态查询场地
     */
    public List<Venue> getVenuesByStatus(Integer status) {
        return venueMapper.findByStatus(status);
    }
    
    /**
     * 按名称搜索场地
     */
    public List<Venue> searchVenuesByName(String name) {
        return venueMapper.findByNameLike(name);
    }
    
    /**
     * 分页查询场地
     */
    public PageInfo<Venue> searchVenuesByPage(String name, Integer status,
                                               int pageNum, int pageSize) {
        int offset = (pageNum - 1) * pageSize;
        
        List<Venue> venues = venueMapper.searchVenuesByPage(name, status, offset, pageSize);
        int total = venueMapper.countSearchVenues(name, status);
        
        return new PageInfo<>(venues, pageNum, pageSize, total);
    }
    
    /**
     * 修改场地信息
     */
    @Transactional
    public boolean updateVenue(Venue venue, Long operatorId, String operatorName) {
        boolean result = venueMapper.update(venue) > 0;
        
        if (result) {
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "编辑场地", "场地管理", 
                "更新场地 [" + venue.getName() + "] 的信息");
            operationLogMapper.insert(log);
        }
        
        return result;
    }
    
    /**
     * 删除场地（检查占用）
     */
    @Transactional
    public boolean deleteVenue(Long venueId, Long operatorId, String operatorName) {
        Venue venue = getVenueById(venueId);
        if (venue == null) {
            return false;
        }
        
        // 检查是否有讲座正在使用
        int lectureCount = lectureMapper.countByVenueId(venueId);
        if (lectureCount > 0) {
            throw new RuntimeException("该场地已被 " + lectureCount + " 个讲座使用，无法删除。请先删除或修改相关讲座。");
        }
        
        boolean result = venueMapper.deleteById(venueId) > 0;
        
        if (result) {
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "删除场地", "场地管理", 
                "删除了场地 [" + venue.getName() + "]");
            operationLogMapper.insert(log);
        }
        
        return result;
    }
    
    /**
     * 启用场地
     */
    @Transactional
    public boolean enableVenue(Long venueId, Long operatorId, String operatorName) {
        Venue venue = getVenueById(venueId);
        Venue venueToUpdate = new Venue();
        venueToUpdate.setVenueId(venueId);
        venueToUpdate.setStatus(1);
        boolean result = venueMapper.update(venueToUpdate) > 0;
        
        if (result) {
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "启用场地", "场地管理", 
                "将场地 [" + venue.getName() + "] 设为可用状态");
            operationLogMapper.insert(log);
        }
        
        return result;
    }
    
    /**
     * 禁用场地（设为维护）
     */
    @Transactional
    public boolean disableVenue(Long venueId, Long operatorId, String operatorName) {
        Venue venue = getVenueById(venueId);
        Venue venueToUpdate = new Venue();
        venueToUpdate.setVenueId(venueId);
        venueToUpdate.setStatus(0);
        boolean result = venueMapper.update(venueToUpdate) > 0;
        
        if (result) {
            // 记录操作日志
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "设为维护", "场地管理", 
                "将场地 [" + venue.getName() + "] 设为维护状态");
            operationLogMapper.insert(log);
        }
        
        return result;
    }
    
    /**
     * 统计场地总数
     */
    public int getTotalVenueCount() {
        return venueMapper.countTotal();
    }
    
    /**
     * 统计可用场地数
     */
    public int getAvailableVenueCount() {
        return venueMapper.countAvailable();
    }
}