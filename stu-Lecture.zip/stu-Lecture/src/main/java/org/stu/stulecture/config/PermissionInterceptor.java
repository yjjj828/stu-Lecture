package org.stu.stulecture.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.stu.stulecture.entity.User;

/**
 * 权限验证拦截器
 * 统一控制管理员和教师专属页面的访问权限
 */
@Component
public class PermissionInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, 
                            HttpServletResponse response, 
                            Object handler) throws Exception {
        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("currentUser") : null;
        
        String path = request.getRequestURI();
        
        // 管理员页面：只允许 admin 角色访问
        if (path.startsWith("/admin/")) {
            if (currentUser == null || !"admin".equals(currentUser.getRole())) {
                response.sendRedirect("/user/login");
                return false;
            }
        }
        
        // 教师页面：允许 teacher 或 admin 角色访问
        if (path.startsWith("/teacher/")) {
            if (currentUser == null || 
                (!"teacher".equals(currentUser.getRole()) && !"admin".equals(currentUser.getRole()))) {
                response.sendRedirect("/user/login");
                return false;
            }
        }
        
        // 其他页面放行
        return true;
    }
}
