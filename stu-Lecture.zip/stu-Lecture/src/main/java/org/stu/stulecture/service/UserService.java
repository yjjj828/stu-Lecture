package org.stu.stulecture.service;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.entity.OperationLog;
import org.stu.stulecture.mapper.UserMapper;
import org.stu.stulecture.mapper.OperationLogMapper;

import java.util.Base64;
import java.util.List;

/**
 * 用户业务逻辑处理
 */
@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;
    
    @Autowired
    private OperationLogMapper operationLogMapper;

    /**
     * 注册新用户
     */
    @Transactional
    public boolean register(User user) {
        // 检查账号是否已被占用
        if (userMapper.findByUsername(user.getUsername()) != null) {
            return false;
        }
                
        // 默认启用状态
        user.setStatus(1);
                
        boolean result = userMapper.insert(user) > 0;
        
        if (result) {
            OperationLog log = new OperationLog(user.getUserId(), user.getUsername(), 
                "用户注册", "用户管理", 
                "新用户注册：" + user.getUsername() + " （" + user.getName() + "）");
            operationLogMapper.insert(log);
        }
        
        return result;
    }

    /**
     * 登录验证
     */
    public User login(String username, String password) {
        User user = userMapper.findByUsername(username);
        if (user != null) {
            // 只有启用状态才能登录
            if (user.getStatus() != 1) {
                return null;
            }
            if (user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }
    
    /**
     * 激活账号（首次登录自动启用）
     * @return true-新激活 false-已经是启用状态
     */
    @Transactional
    public boolean activateUser(Long userId) {
        User user = userMapper.findById(userId);
        if (user == null) {
            return false;
        }
        // 未激活状态（0）改为启用（1）
        if (user.getStatus() == 0) {
            user.setStatus(1);
            return userMapper.update(user) > 0;
        }
        return false;
    }

    /**
     * 按ID查询用户
     */
    public User getUserById(Long userId) {
        return userMapper.findById(userId);
    }

    /**
     * 按账号查询用户
     */
    public User getUserByUsername(String username) {
        return userMapper.findByUsername(username);
    }

    /**
     * 拼接用户显示名：账号（姓名）
     */
    private String formatUserName(Long userId) {
        if (userId == null) {
            return "系统";
        }
        User user = userMapper.findById(userId);
        if (user == null) {
            return "用户 ID:" + userId;
        }
        if (user.getName() != null && !user.getName().isEmpty()) {
            return user.getUsername() + "（" + user.getName() + "）";
        }
        return user.getUsername();
    }
    
    /**
     * 修改用户信息（本人操作）
     */
    @Transactional
    public boolean updateUser(User user, Long operatorId, String operatorName) {
        boolean result = userMapper.update(user) > 0;
        
        if (result) {
            if (operatorId.equals(user.getUserId())) {
                OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                    "修改个人信息", "用户管理", 
                    "用户 [" + formatUserName(operatorId) + "] 修改了自己的个人信息");
                operationLogMapper.insert(log);
            }
        }
        
        return result;
    }

    /**
     * 修改密码（本人操作）
     */
    @Transactional
    public boolean updatePassword(Long userId, String newPassword, Long operatorId, String operatorName) {
        boolean result = userMapper.updatePassword(userId, newPassword) > 0;
        
        if (result) {
            if (operatorId.equals(userId)) {
                OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                    "修改密码", "用户管理", 
                    "用户 [" + formatUserName(operatorId) + "] 修改了自己的登录密码");
                operationLogMapper.insert(log);
            }
        }
        
        return result;
    }

    /**
     * 查询全部用户
     */
    public List<User> getAllUsers() {
        return userMapper.findAll();
    }

    /**
     * 按角色查询用户
     */
    public List<User> getUsersByRole(String role) {
        return userMapper.findByRole(role);
    }

    /**
     * 按状态查询用户
     */
    public List<User> getUsersByStatus(Integer status) {
        return userMapper.findByStatus(status);
    }

    /**
     * 删除指定用户
     */
    public boolean deleteUser(Long userId) {
        return userMapper.deleteById(userId) > 0;
    }

    /**
     * 验证管理员账号是否存在，不存在则创建默认管理员
     */
    public void initAdminUser() {
        User admin = userMapper.findByUsername("admin");
        if (admin == null) {
            User defaultAdmin = new User();
            defaultAdmin.setUsername("admin");
            defaultAdmin.setPassword("admin"); // 默认密码，生产环境应修改
            defaultAdmin.setRole("admin");
            defaultAdmin.setName("系统管理员");
            defaultAdmin.setEmail("admin@university.edu");
            defaultAdmin.setDepartment("信息技术中心");
            defaultAdmin.setStatus(1);
            userMapper.insert(defaultAdmin);
        }
    }

    // ==================== 记住我功能 ====================

    /**
     * 生成记住我 Cookie（7天有效期）
     */
    public void rememberMe(User user, HttpServletResponse response) {
        String value = user.getUserId() + "|" + (System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000);
        String encoded = Base64.getEncoder().encodeToString(value.getBytes());
        Cookie cookie = new Cookie("rm", encoded);
        cookie.setMaxAge(7 * 24 * 60 * 60);
        cookie.setPath("/");
        response.addCookie(cookie);
    }

    /**
     * 验证记住我 Cookie，返回用户对象
     */
    public User checkRememberMe(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) return null;

        for (Cookie c : cookies) {
            if ("rm".equals(c.getName())) {
                try {
                    String decoded = new String(Base64.getDecoder().decode(c.getValue()));
                    String[] parts = decoded.split("\\|");
                    if (parts.length == 2) {
                        long expire = Long.parseLong(parts[1]);
                        if (System.currentTimeMillis() < expire) {
                            return userMapper.findById(Long.parseLong(parts[0]));
                        }
                    }
                } catch (Exception e) {}
            }
        }
        return null;
    }

    /**
     * 清除记住我 Cookie
     */
    public void clearRememberMe(HttpServletResponse response) {
        Cookie cookie = new Cookie("rm", "");
        cookie.setMaxAge(0);
        cookie.setPath("/");
        response.addCookie(cookie);
    }
}