package org.stu.stulecture.mapper;

import org.apache.ibatis.annotations.*;
import org.stu.stulecture.entity.Reservation;

import java.util.List;

/**
 * 预约数据访问接口
 * 使用MyBatis注解方式操作数据库
 */
@Mapper
public interface ReservationMapper {
    
    /**
     * 插入新预约
     */
    @Insert("INSERT INTO reservations (user_id, lecture_id, status, apply_time) " +
            "VALUES (#{userId}, #{lectureId}, #{status}, NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "reservationId")
    int insert(Reservation reservation);
    
    /**
     * 根据 ID 查询预约
     * 使用@Results 显式映射多表关联查询结果
     */
    @Select("SELECT r.*, u.name as user_name, l.title as lecture_title, l.lecture_time, l.location, l.duration, l.notice, l.status as lecture_status " +
            "FROM reservations r " +
            "LEFT JOIN users u ON r.user_id = u.user_id " +
            "LEFT JOIN lectures l ON r.lecture_id = l.lecture_id " +
            "WHERE r.reservation_id = #{reservationId}")
    @Results({
        @Result(property = "reservationId", column = "reservation_id"),  // reservations 表字段
        @Result(property = "userId", column = "user_id"),              // reservations 表字段
        @Result(property = "lectureId", column = "lecture_id"),        // reservations 表字段
        @Result(property = "status", column = "status"),
        @Result(property = "reminded1day", column = "reminded_1day"),
        @Result(property = "reminded2hours", column = "reminded_2hours"),
        @Result(property = "applyTime", column = "apply_time"),        // reservations 表字段
        @Result(property = "userName", column = "user_name"),          // 关联 users 表 name 字段
        @Result(property = "lectureTitle", column = "lecture_title"),   // 关联 lectures 表 title 字段
        @Result(property = "lectureTime", column = "lecture_time"),      // 关联 lectures 表时间字段
        @Result(property = "location", column = "location"),      // 关联 lectures 表地点字段
        @Result(property = "notice", column = "notice"),      // 关联 lectures 表注意事项字段
        @Result(property = "lectureStatus", column = "lecture_status")   // 关联 lectures 表状态字段
    })
    Reservation findById(Long reservationId);
    
    /**
     * 根据用户 ID 查询预约
     */
    @Select("SELECT r.*, u.name as user_name, l.title as lecture_title, l.lecture_time, l.location, l.notice, l.status as lecture_status " +
            "FROM reservations r " +
            "LEFT JOIN users u ON r.user_id = u.user_id " +
            "LEFT JOIN lectures l ON r.lecture_id = l.lecture_id " +
            "WHERE r.user_id = #{userId} " +
            "ORDER BY r.apply_time DESC")
    @Results({
        @Result(property = "reservationId", column = "reservation_id"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "status", column = "status"),
        @Result(property = "reminded1day", column = "reminded_1day"),
        @Result(property = "reminded2hours", column = "reminded_2hours"),
        @Result(property = "applyTime", column = "apply_time"),
        @Result(property = "userName", column = "user_name"),
        @Result(property = "lectureTitle", column = "lecture_title"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "location", column = "location"),
        @Result(property = "notice", column = "notice"),
        @Result(property = "lectureStatus", column = "lecture_status")
    })
    List<Reservation> findByUserId(Long userId);
    
    /**
     * 分页查询用户的预约
     */
    @Select("SELECT r.*, u.name as user_name, l.title as lecture_title, l.lecture_time, l.notice, l.status as lecture_status " +
            "FROM reservations r " +
            "LEFT JOIN users u ON r.user_id = u.user_id " +
            "LEFT JOIN lectures l ON r.lecture_id = l.lecture_id " +
            "WHERE r.user_id = #{userId} " +
            "ORDER BY r.apply_time DESC " +
            "LIMIT #{offset}, #{pageSize}")
    @Results({
        @Result(property = "reservationId", column = "reservation_id"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "applyTime", column = "apply_time"),
        @Result(property = "userName", column = "user_name"),
        @Result(property = "lectureTitle", column = "lecture_title"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "notice", column = "notice"),
        @Result(property = "lectureStatus", column = "lecture_status")
    })
    List<Reservation> findByUserIdPage(@Param("userId") Long userId,
                                      @Param("offset") int offset,
                                      @Param("pageSize") int pageSize);
    
    /**
     * 统计用户的预约总数
     */
    @Select("SELECT COUNT(*) FROM reservations WHERE user_id = #{userId}")
    int countUserReservations(Long userId);
    
    /**
     * 根据讲座 ID 查询预约
     */
    @Select("SELECT r.*, u.name as user_name, l.title as lecture_title, l.lecture_time, l.notice, l.status as lecture_status " +
            "FROM reservations r " +
            "LEFT JOIN users u ON r.user_id = u.user_id " +
            "LEFT JOIN lectures l ON r.lecture_id = l.lecture_id " +
            "WHERE r.lecture_id = #{lectureId} " +
            "ORDER BY r.apply_time DESC")
    @Results({
        @Result(property = "reservationId", column = "reservation_id"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "applyTime", column = "apply_time"),
        @Result(property = "userName", column = "user_name"),
        @Result(property = "lectureTitle", column = "lecture_title"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "notice", column = "notice"),
        @Result(property = "lectureStatus", column = "lecture_status")
    })
    List<Reservation> findByLectureId(Long lectureId);
    
    /**
     * 查询用户的特定讲座预约
     */
    @Select("SELECT * FROM reservations WHERE user_id = #{userId} AND lecture_id = #{lectureId}")
    Reservation findByUserAndLecture(@Param("userId") Long userId, @Param("lectureId") Long lectureId);
    
    /**
     * 分页查询某讲座的预约（管理员用）
     */
    @Select("SELECT r.*, u.name as user_name, u.username as user_username, u.department as user_department, " +
            "l.title as lecture_title, l.lecture_time, l.duration, l.notice, l.status as lecture_status " +
            "FROM reservations r " +
            "LEFT JOIN users u ON r.user_id = u.user_id " +
            "LEFT JOIN lectures l ON r.lecture_id = l.lecture_id " +
            "WHERE r.lecture_id = #{lectureId} " +
            "ORDER BY r.apply_time DESC " +
            "LIMIT #{offset}, #{pageSize}")
    @Results({
        @Result(property = "reservationId", column = "reservation_id"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "status", column = "status"),
        @Result(property = "applyTime", column = "apply_time"),
        @Result(property = "checkinStatus", column = "checkin_status"),
        @Result(property = "checkinTime", column = "checkin_time"),
        @Result(property = "userName", column = "user_name"),
        @Result(property = "userUsername", column = "user_username"),
        @Result(property = "userDepartment", column = "user_department"),
        @Result(property = "lectureTitle", column = "lecture_title"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "lectureDuration", column = "duration"),
        @Result(property = "notice", column = "notice"),
        @Result(property = "lectureStatus", column = "lecture_status")
    })
    List<Reservation> findByLectureIdPage(@Param("lectureId") Long lectureId, @Param("offset") int offset, @Param("pageSize") int pageSize);
    
    /**
     * 根据状态查询预约
     */
    @Select("SELECT r.*, u.name as user_name, l.title as lecture_title, l.lecture_time, l.notice, l.status as lecture_status " +
            "FROM reservations r " +
            "LEFT JOIN users u ON r.user_id = u.user_id " +
            "LEFT JOIN lectures l ON r.lecture_id = l.lecture_id " +
            "WHERE r.status = #{status} " +
            "ORDER BY r.apply_time DESC")
    @Results({
        @Result(property = "reservationId", column = "reservation_id"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "applyTime", column = "apply_time"),
        @Result(property = "userName", column = "user_name"),
        @Result(property = "lectureTitle", column = "lecture_title"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "notice", column = "notice"),
        @Result(property = "lectureStatus", column = "lecture_status")
    })
    List<Reservation> findByStatus(String status);
    
    /**
     * 更新预约状态
     */
    @Update("UPDATE reservations SET status = #{status}, apply_time = NOW() WHERE reservation_id = #{reservationId}")
    int updateStatus(@Param("reservationId") Long reservationId, @Param("status") String status);
    
    /**
     * 标记1天提醒已发送
     */
    @Update("UPDATE reservations SET reminded_1day = TRUE WHERE reservation_id = #{reservationId}")
    int markReminded1day(@Param("reservationId") Long reservationId);
    
    /**
     * 标记2小时提醒已发送
     */
    @Update("UPDATE reservations SET reminded_2hours = TRUE WHERE reservation_id = #{reservationId}")
    int markReminded2hours(@Param("reservationId") Long reservationId);
    
    /**
     * 取消预约
     */
    @Update("UPDATE reservations SET status = 'cancelled' WHERE reservation_id = #{reservationId}")
    int cancelReservation(Long reservationId);
    
    /**
     * 删除预约
     */
    @Delete("DELETE FROM reservations WHERE reservation_id = #{reservationId}")
    int deleteById(Long reservationId);
    
    /**
     * 统计某个讲座的预约人数
     */
    @Select("SELECT COUNT(*) FROM reservations WHERE lecture_id = #{lectureId} AND status != 'cancelled'")
    int countByLectureId(Long lectureId);
    
    /**
     * 统计某个用户的预约数量
     */
    @Select("SELECT COUNT(*) FROM reservations WHERE user_id = #{userId} AND status != 'cancelled'")
    int countByUserId(Long userId);
    
    /**
     * 检查用户是否已预约某个讲座
     */
    @Select("SELECT COUNT(*) FROM reservations WHERE user_id = #{userId} AND lecture_id = #{lectureId} AND status != 'cancelled'")
    int checkUserReservation(@Param("userId") Long userId, @Param("lectureId") Long lectureId);
    
    /**
     * 签到
     */
    @Update("UPDATE reservations SET checkin_status = 'checked', checkin_time = NOW() WHERE reservation_id = #{reservationId}")
    int checkin(Long reservationId);
    
    /**
     * 查询所有预约（管理员用）
     */
    @Select("SELECT r.*, u.name as user_name, u.username as user_username, " +
            "l.title as lecture_title, l.lecture_time, l.notice, l.status as lecture_status " +
            "FROM reservations r " +
            "LEFT JOIN users u ON r.user_id = u.user_id " +
            "LEFT JOIN lectures l ON r.lecture_id = l.lecture_id " +
            "ORDER BY r.apply_time DESC " +
            "LIMIT #{offset}, #{pageSize}")
    @Results({
        @Result(property = "reservationId", column = "reservation_id"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "status", column = "status"),
        @Result(property = "applyTime", column = "apply_time"),
        @Result(property = "checkinStatus", column = "checkin_status"),
        @Result(property = "checkinTime", column = "checkin_time"),
        @Result(property = "userName", column = "user_name"),
        @Result(property = "lectureTitle", column = "lecture_title"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "lectureDuration", column = "duration"),
        @Result(property = "notice", column = "notice"),
        @Result(property = "lectureStatus", column = "lecture_status")
    })
    List<Reservation> findAllPage(@Param("offset") int offset, @Param("pageSize") int pageSize);
    
    /**
     * 统计所有预约数量
     */
    @Select("SELECT COUNT(*) FROM reservations")
    int countAll();
}