package org.stu.stulecture.entity;

import java.time.LocalDateTime;

/**
 * 通知实体类
 * 对应数据库 notifications 表（简化版）
 */
public class Notification {
    private Long notificationId;        // 通知 ID
    private String title;               // 通知标题
    private String content;             // 通知内容
    private String type;                // 通知类型：system-系统通知 lecture-讲座通知 reservation-预约通知 reminder-提醒通知
    private Long receiverId;            // 接收者 ID
    private Long senderId;              // 发送者 ID（系统通知为 null）
    private String status;              // 阅读状态：unread-未读 read-已读
    private LocalDateTime sendTime;     // 发送时间
    private LocalDateTime readTime;     // 阅读时间
    
    // 扩展属性（不在数据库中，用于页面显示）
    private String receiverName;        // 接收者姓名
    private String senderName;          // 发送者姓名
    
    // 构造函数
    public Notification() {}
    
    /**
     * 创建通知（不含发送者和扩展属性）
     */
    public Notification(String title, String content, String type, Long receiverId) {
        this.title = title;
        this.content = content;
        this.type = type;
        this.receiverId = receiverId;
        this.status = "unread";
    }
    
    /**
     * 创建通知（含发送者）
     */
    public Notification(String title, String content, String type, Long receiverId, Long senderId) {
        this.title = title;
        this.content = content;
        this.type = type;
        this.receiverId = receiverId;
        this.senderId = senderId;
        this.status = "unread";
    }
    
    // Getter 和 Setter 方法
    public Long getNotificationId() { return notificationId; }
    public void setNotificationId(Long notificationId) { this.notificationId = notificationId; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    
    public Long getReceiverId() { return receiverId; }
    public void setReceiverId(Long receiverId) { this.receiverId = receiverId; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Long getSenderId() { return senderId; }
    public void setSenderId(Long senderId) { this.senderId = senderId; }
    
    public LocalDateTime getSendTime() { return sendTime; }
    public void setSendTime(LocalDateTime sendTime) { this.sendTime = sendTime; }
    
    public LocalDateTime getReadTime() { return readTime; }
    public void setReadTime(LocalDateTime readTime) { this.readTime = readTime; }
    
    // 扩展属性的 Getter 和 Setter
    public String getReceiverName() { return receiverName; }
    public void setReceiverName(String receiverName) { this.receiverName = receiverName; }
    
    public String getSenderName() { return senderName; }
    public void setSenderName(String senderName) { this.senderName = senderName; }
    
    @Override
    public String toString() {
        return "Notification{" +
                "notificationId=" + notificationId +
                ", title='" + title + '\'' +
                ", type='" + type + '\'' +
                ", receiverId=" + receiverId +
                ", status='" + status + '\'' +
                '}';
    }
}
