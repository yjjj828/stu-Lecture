package org.stu.stulecture.mapper;

import org.apache.ibatis.annotations.*;
import org.stu.stulecture.entity.OperationLog;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 操作日志数据访问接口
 * 使用MyBatis注解方式操作数据库
 */
@Mapper
public interface OperationLogMapper {

    /**
     * 插入新日志
     */
    @Insert("<script>" +
            "INSERT INTO operation_logs (user_id, username, operation, module, description, create_time) " +
            "VALUES (#{userId}, #{username}, #{operation}, #{module}, #{description}, NOW())" +
            "</script>")
    @Options(useGeneratedKeys = true, keyProperty = "logId")
    int insert(OperationLog log);

    /**
     * 根据ID查询日志
     */
    @Select("SELECT * FROM operation_logs WHERE log_id = #{logId}")
    OperationLog findById(Long logId);

    /**
     * 查询所有日志（按时间倒序）
     */
    @Select("SELECT * FROM operation_logs ORDER BY create_time DESC")
    List<OperationLog> findAll();

    /**
     * 根据用户ID查询日志
     */
    @Select("SELECT * FROM operation_logs WHERE user_id = #{userId} ORDER BY create_time DESC")
    List<OperationLog> findByUserId(Long userId);

    /**
     * 根据模块查询日志
     */
    @Select("SELECT * FROM operation_logs WHERE module = #{module} ORDER BY create_time DESC")
    List<OperationLog> findByModule(String module);

    /**
     * 根据操作类型查询日志
     */
    @Select("SELECT * FROM operation_logs WHERE operation = #{operation} ORDER BY create_time DESC")
    List<OperationLog> findByOperation(String operation);

    /**
     * 根据时间范围查询日志
     */
    @Select("SELECT * FROM operation_logs WHERE create_time >= #{startTime} AND create_time <= #{endTime} ORDER BY create_time DESC")
    List<OperationLog> findByTimeRange(@Param("startTime") LocalDateTime startTime, 
                                      @Param("endTime") LocalDateTime endTime);

    /**
     * 搜索日志（按用户名、操作描述、模块等）
     */
    @Select("SELECT * FROM operation_logs WHERE " +
            "(#{username} IS NULL OR username LIKE CONCAT('%', #{username}, '%')) AND " +
            "(#{operation} IS NULL OR operation LIKE CONCAT('%', #{operation}, '%')) AND " +
            "(#{module} IS NULL OR module LIKE CONCAT('%', #{module}, '%')) AND " +
            "(#{logDate} IS NULL OR DATE(create_time) = #{logDate}) " +
            "ORDER BY create_time DESC")
    List<OperationLog> searchLogs(@Param("username") String username,
                                 @Param("operation") String operation,
                                 @Param("module") String module,
                                 @Param("logDate") String logDate);

    /**
     * 分页搜索日志（按用户名、操作描述、模块等）
     */
    @Select("SELECT * FROM operation_logs WHERE " +
            "(#{username} IS NULL OR username LIKE CONCAT('%', #{username}, '%')) AND " +
            "(#{operation} IS NULL OR operation LIKE CONCAT('%', #{operation}, '%')) AND " +
            "(#{module} IS NULL OR module LIKE CONCAT('%', #{module}, '%')) AND " +
            "(#{logDate} IS NULL OR DATE(create_time) = #{logDate}) " +
            "ORDER BY create_time DESC " +
            "LIMIT #{offset}, #{pageSize}")
    List<OperationLog> searchLogsByPage(@Param("username") String username,
                                       @Param("operation") String operation,
                                       @Param("module") String module,
                                       @Param("logDate") String logDate,
                                       @Param("offset") int offset,
                                       @Param("pageSize") int pageSize);

    /**
     * 统计符合条件的日志总数
     */
    @Select("SELECT COUNT(*) FROM operation_logs WHERE " +
            "(#{username} IS NULL OR username LIKE CONCAT('%', #{username}, '%')) AND " +
            "(#{operation} IS NULL OR operation LIKE CONCAT('%', #{operation}, '%')) AND " +
            "(#{module} IS NULL OR module LIKE CONCAT('%', #{module}, '%')) AND " +
            "(#{logDate} IS NULL OR DATE(create_time) = #{logDate})")
    int countSearchLogs(@Param("username") String username,
                       @Param("operation") String operation,
                       @Param("module") String module,
                       @Param("logDate") String logDate);

    /**
     * 删除指定时间之前的日志（用于日志清理）
     */
    @Delete("DELETE FROM operation_logs WHERE create_time < #{beforeTime}")
    int deleteBeforeTime(LocalDateTime beforeTime);

    /**
     * 统计总日志数
     */
    @Select("SELECT COUNT(*) FROM operation_logs")
    int countTotal();

    /**
     * 统计某用户的操作次数
     */
    @Select("SELECT COUNT(*) FROM operation_logs WHERE user_id = #{userId}")
    int countByUserId(Long userId);

    /**
     * 统计某模块的操作次数
     */
    @Select("SELECT COUNT(*) FROM operation_logs WHERE module = #{module}")
    int countByModule(String module);
}