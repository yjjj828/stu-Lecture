package org.stu.stulecture.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.service.NotificationService;

/**
 * 通知未读数量拦截器
 * 为所有需要显示通知红点的页面统一注入未读通知数量
 */
@Component
public class NotificationInterceptor implements HandlerInterceptor {

    @Autowired
    private NotificationService notificationService;

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, 
                          Object handler, ModelAndView modelAndView) throws Exception {
        // 只有在返回视图时才处理
        if (modelAndView != null) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                User currentUser = (User) session.getAttribute("currentUser");
                if (currentUser != null) {
                    // 获取未读通知数量并添加到模型中
                    int unreadCount = notificationService.getUnreadCount(currentUser.getUserId());
                    modelAndView.addObject("unreadCount", unreadCount);
                }
            }
        }
    }
}
