package org.stu.stulecture.mapper;

import org.apache.ibatis.annotations.*;
import org.stu.stulecture.entity.Lecture;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 讲座数据访问接口
 * 使用MyBatis注解方式操作数据库
 */
@Mapper
public interface LectureMapper {
    
    /**
     * 插入新讲座
     */
    @Insert("INSERT INTO lectures (title, speaker_id, description, poster, lecture_time, location, " +
            "capacity, enrolled_count, status, category, duration, format, notice, venue_id, created_time) " +
            "VALUES (#{title}, #{speakerId}, #{description}, #{poster}, #{lectureTime}, #{location}, " +
            "#{capacity}, #{enrolledCount}, #{status}, #{category}, #{duration}, #{format}, #{notice}, #{venueId}, NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "lectureId")
    int insert(Lecture lecture);
    
    /**
     * 根据ID查询讲座
     * 使用@Results映射讲座信息和主讲人关联信息
     */
    @Select("SELECT l.*, u.name as speaker_name, u.department as speaker_department, u.avatar as speaker_avatar, u.bio as speaker_bio, v.name as venue_name " +
            "FROM lectures l " +
            "LEFT JOIN users u ON l.speaker_id = u.user_id " +
            "LEFT JOIN venues v ON l.venue_id = v.venue_id " +
            "WHERE l.lecture_id = #{lectureId}")
    @Results({
        @Result(property = "lectureId", column = "lecture_id"),           // lectures 表主键
        @Result(property = "speakerId", column = "speaker_id"),          // lectures 表外键
        @Result(property = "lectureTime", column = "lecture_time"),       // lectures 表时间字段
        @Result(property = "enrolledCount", column = "enrolled_count"),   // lectures 表预约人数
        @Result(property = "createdTime", column = "created_time"),       // lectures 表创建时间
        @Result(property = "updatedTime", column = "updated_time"),       // lectures 表更新时间
        @Result(property = "poster", column = "poster"),                  // lectures 表海报字段
        @Result(property = "speakerName", column = "speaker_name"),       // 关联 users 表 name 字段
        @Result(property = "speakerDepartment", column = "speaker_department"), // 关联 users 表 department 字段
        @Result(property = "speakerAvatar", column = "speaker_avatar"),   // 关联 users 表 avatar 字段
        @Result(property = "speakerBio", column = "speaker_bio")          // 关联 users 表 bio 字段
    })
    Lecture findById(Long lectureId);
    
    /**
     * 查询所有讲座（带主讲人信息）
     */
    @Select("SELECT l.*, u.name as speaker_name, u.department as speaker_department, u.avatar as speaker_avatar, u.bio as speaker_bio, v.name as venue_name " +
            "FROM lectures l " +
            "LEFT JOIN users u ON l.speaker_id = u.user_id " +
            "LEFT JOIN venues v ON l.venue_id = v.venue_id " +
            "ORDER BY l.lecture_time DESC")
    @Results({
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "speakerId", column = "speaker_id"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "enrolledCount", column = "enrolled_count"),
        @Result(property = "createdTime", column = "created_time"),
        @Result(property = "updatedTime", column = "updated_time"),
        @Result(property = "poster", column = "poster"),
        @Result(property = "speakerName", column = "speaker_name"),
        @Result(property = "speakerDepartment", column = "speaker_department"),
        @Result(property = "speakerAvatar", column = "speaker_avatar"),
        @Result(property = "speakerBio", column = "speaker_bio")
    })
    List<Lecture> findAllWithSpeaker();
    
    /**
     * 根据状态查询讲座
     */
    @Select("SELECT l.*, u.name as speaker_name, u.department as speaker_department, v.name as venue_name " +
            "FROM lectures l " +
            "LEFT JOIN users u ON l.speaker_id = u.user_id " +
            "LEFT JOIN venues v ON l.venue_id = v.venue_id " +
            "WHERE l.status = #{status} " +
            "ORDER BY l.lecture_time DESC")
    @Results({
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "speakerId", column = "speaker_id"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "enrolledCount", column = "enrolled_count"),
        @Result(property = "createdTime", column = "created_time"),
        @Result(property = "updatedTime", column = "updated_time"),
        @Result(property = "poster", column = "poster"),
        @Result(property = "speakerName", column = "speaker_name"),
        @Result(property = "speakerDepartment", column = "speaker_department"),
        @Result(property = "speakerAvatar", column = "speaker_avatar"),
        @Result(property = "speakerBio", column = "speaker_bio")
    })
    List<Lecture> findByStatus(String status);
    
    /**
     * 根据分类查询讲座
     */
    @Select("SELECT l.*, u.name as speaker_name, u.department as speaker_department, v.name as venue_name " +
            "FROM lectures l " +
            "LEFT JOIN users u ON l.speaker_id = u.user_id " +
            "LEFT JOIN venues v ON l.venue_id = v.venue_id " +
            "WHERE l.category = #{category} " +
            "ORDER BY l.lecture_time DESC")
    @Results({
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "speakerId", column = "speaker_id"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "enrolledCount", column = "enrolled_count"),
        @Result(property = "createdTime", column = "created_time"),
        @Result(property = "updatedTime", column = "updated_time"),
        @Result(property = "poster", column = "poster"),
        @Result(property = "speakerName", column = "speaker_name"),
        @Result(property = "speakerDepartment", column = "speaker_department"),
        @Result(property = "speakerAvatar", column = "speaker_avatar"),
        @Result(property = "speakerBio", column = "speaker_bio")
    })
    List<Lecture> findByCategory(String category);
    
    /**
     * 根据主讲人ID查询讲座
     */
    @Select("SELECT l.*, u.name as speaker_name, u.department as speaker_department, v.name as venue_name " +
            "FROM lectures l " +
            "LEFT JOIN users u ON l.speaker_id = u.user_id " +
            "LEFT JOIN venues v ON l.venue_id = v.venue_id " +
            "WHERE l.speaker_id = #{speakerId} " +
            "ORDER BY l.lecture_time DESC")
    @Results({
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "speakerId", column = "speaker_id"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "enrolledCount", column = "enrolled_count"),
        @Result(property = "createdTime", column = "created_time"),
        @Result(property = "updatedTime", column = "updated_time"),
        @Result(property = "poster", column = "poster"),
        @Result(property = "speakerName", column = "speaker_name"),
        @Result(property = "speakerDepartment", column = "speaker_department"),
        @Result(property = "speakerAvatar", column = "speaker_avatar"),
        @Result(property = "speakerBio", column = "speaker_bio")
    })
    List<Lecture> findBySpeakerId(Long speakerId);
    
    /**
     * 根据时间范围查询讲座
     */
    @Select("SELECT l.*, u.name as speaker_name, u.department as speaker_department, v.name as venue_name " +
            "FROM lectures l " +
            "LEFT JOIN users u ON l.speaker_id = u.user_id " +
            "LEFT JOIN venues v ON l.venue_id = v.venue_id " +
            "WHERE l.lecture_time >= #{startTime} AND l.lecture_time <= #{endTime} " +
            "ORDER BY l.lecture_time ASC")
    @Results({
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "speakerId", column = "speaker_id"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "enrolledCount", column = "enrolled_count"),
        @Result(property = "createdTime", column = "created_time"),
        @Result(property = "updatedTime", column = "updated_time"),
        @Result(property = "poster", column = "poster"),
        @Result(property = "speakerName", column = "speaker_name"),
        @Result(property = "speakerDepartment", column = "speaker_department"),
        @Result(property = "speakerAvatar", column = "speaker_avatar"),
        @Result(property = "speakerBio", column = "speaker_bio")
    })
    List<Lecture> findByTimeRange(@Param("startTime") LocalDateTime startTime, 
                                 @Param("endTime") LocalDateTime endTime);
    
    /**
     * 搜索讲座（按标题、主讲人或学科领域）
     */
    @Select("SELECT l.*, u.name as speaker_name, u.department as speaker_department, v.name as venue_name " +
            "FROM lectures l " +
            "LEFT JOIN users u ON l.speaker_id= u.user_id " +
            "LEFT JOIN venues v ON l.venue_id = v.venue_id " +
            "WHERE (l.title LIKE CONCAT('%', #{keyword}, '%') " +
            "OR u.name LIKE CONCAT('%', #{keyword}, '%') " +
            "OR l.category LIKE CONCAT('%', #{keyword}, '%')) " +
            "ORDER BY l.lecture_time DESC")
    @Results({
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "speakerId", column = "speaker_id"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "enrolledCount", column = "enrolled_count"),
        @Result(property = "createdTime", column = "created_time"),
        @Result(property = "updatedTime", column = "updated_time"),
        @Result(property = "poster", column = "poster"),
        @Result(property = "speakerName", column = "speaker_name"),
        @Result(property = "speakerDepartment", column = "speaker_department"),
        @Result(property = "speakerAvatar", column = "speaker_avatar"),
        @Result(property = "speakerBio", column = "speaker_bio")
    })
    List<Lecture> searchByKeyword(String keyword);
    
    /**
     * 搜索讲座（多条件）
     */
    @Select("<script>" +
            "SELECT l.*, u.name as speaker_name, u.department as speaker_department, v.name as venue_name " +
            "FROM lectures l " +
            "LEFT JOIN users u ON l.speaker_id = u.user_id " +
            "LEFT JOIN venues v ON l.venue_id = v.venue_id " +
            "WHERE 1=1 " +
            "<if test='title != null and title != \"\"'>" +
            "AND l.title LIKE CONCAT('%', #{title}, '%')" +
            "</if>" +
            "<if test='speaker != null and speaker != \"\"'>" +
            "AND u.name LIKE CONCAT('%', #{speaker}, '%')" +
            "</if>" +
            "<if test='status != null and status != \"\"'>" +
            "AND l.status = #{status}" +
            "</if>" +
            "ORDER BY l.lecture_time DESC" +
            "</script>")
    @Results({
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "speakerId", column = "speaker_id"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "enrolledCount", column = "enrolled_count"),
        @Result(property = "createdTime", column = "created_time"),
        @Result(property = "updatedTime", column = "updated_time"),
        @Result(property = "poster", column = "poster"),
        @Result(property = "speakerName", column = "speaker_name"),
        @Result(property = "speakerDepartment", column = "speaker_department"),
        @Result(property = "speakerAvatar", column = "speaker_avatar"),
        @Result(property = "speakerBio", column = "speaker_bio")
    })
    List<Lecture> searchLectures(@Param("title") String title,
                                @Param("speaker") String speaker,
                                @Param("status") String status);
    
    /**
     * 分页查询讲座
     */
    @Select("<script>" +
            "SELECT l.*, u.name as speaker_name, u.department as speaker_department, v.name as venue_name " +
            "FROM lectures l " +
            "LEFT JOIN users u ON l.speaker_id = u.user_id " +
            "LEFT JOIN venues v ON l.venue_id = v.venue_id " +
            "WHERE 1=1 " +
            "<if test='title != null and title != \"\"'>" +
            "AND l.title LIKE CONCAT('%', #{title}, '%')" +
            "</if>" +
            "<if test='speaker != null and speaker != \"\"'>" +
            "AND u.name LIKE CONCAT('%', #{speaker}, '%')" +
            "</if>" +
            "<if test='status != null and status != \"\"'>" +
            "AND l.status = #{status}" +
            "</if>" +
            "ORDER BY l.lecture_time DESC " +
            "LIMIT #{offset}, #{pageSize}" +
            "</script>")
    @Results({
        @Result(property = "lectureId", column = "lecture_id"),
        @Result(property = "speakerId", column = "speaker_id"),
        @Result(property = "lectureTime", column = "lecture_time"),
        @Result(property = "enrolledCount", column = "enrolled_count"),
        @Result(property = "createdTime", column = "created_time"),
        @Result(property = "updatedTime", column = "updated_time"),
        @Result(property = "poster", column = "poster"),
        @Result(property = "speakerName", column = "speaker_name"),
        @Result(property = "speakerDepartment", column = "speaker_department"),
        @Result(property = "speakerAvatar", column = "speaker_avatar"),
        @Result(property = "speakerBio", column = "speaker_bio")
    })
    List<Lecture> searchLecturesByPage(@Param("title") String title,
                                      @Param("speaker") String speaker,
                                      @Param("status") String status,
                                      @Param("offset") int offset,
                                      @Param("pageSize") int pageSize);
    
    /**
     * 统计搜索结果的总数
     */
    @Select("<script>" +
            "SELECT COUNT(*) FROM lectures l " +
            "LEFT JOIN users u ON l.speaker_id = u.user_id " +
            "WHERE 1=1 " +
            "<if test='title != null and title != \"\"'>" +
            "AND l.title LIKE CONCAT('%', #{title}, '%')" +
            "</if>" +
            "<if test='speaker != null and speaker != \"\"'>" +
            "AND u.name LIKE CONCAT('%', #{speaker}, '%')" +
            "</if>" +
            "<if test='status != null and status != \"\"'>" +
            "AND l.status = #{status}" +
            "</if>" +
            "</script>")
    int countSearchLectures(@Param("title") String title,
                           @Param("speaker") String speaker,
                           @Param("status") String status);
    
    /**
     * 更新讲座信息
     */
    @Update("<script>" +
            "UPDATE lectures SET " +
            "<if test=\"title != null\">title = #{title},</if>" +
            "<if test=\"description != null\">description = #{description},</if>" +
            "<if test=\"poster != null\">poster = #{poster},</if>" +
            "<if test=\"lectureTime != null\">lecture_time = #{lectureTime},</if>" +
            "<if test=\"location != null\">location = #{location},</if>" +
            "<if test=\"capacity != null\">capacity = #{capacity},</if>" +
            "<if test=\"enrolledCount != null\">enrolled_count = #{enrolledCount},</if>" +
            "<if test=\"status != null\">status = #{status},</if>" +
            "<if test=\"category != null\">category = #{category},</if>" +
            "<if test=\"duration != null\">duration = #{duration},</if>" +
            "<if test=\"format != null\">format = #{format},</if>" +
            "<if test=\"notice != null\">notice = #{notice},</if>" +
            "<if test=\"venueId != null\">venue_id = #{venueId},</if>" +
            "updated_time = NOW() " +
            "WHERE lecture_id = #{lectureId}" +
            "</script>")
    int update(Lecture lecture);
    
    /**
     * 更新已预约人数
     */
    @Update("UPDATE lectures SET enrolled_count = #{enrolledCount}, updated_time = NOW() " +
            "WHERE lecture_id = #{lectureId}")
    int updateEnrolledCount(@Param("lectureId") Long lectureId, 
                           @Param("enrolledCount") Integer enrolledCount);
    
    /**
     * 删除讲座
     */
    @Delete("DELETE FROM lectures WHERE lecture_id = #{lectureId}")
    int deleteById(Long lectureId);
    
    /**
     * 统计讲座总数
     */
    @Select("SELECT COUNT(*) FROM lectures")
    int countTotal();
    
    /**
     * 统计某种状态的讲座数量
     */
    @Select("SELECT COUNT(*) FROM lectures WHERE status = #{status}")
    int countByStatus(String status);
    
    /**
     * 统计使用某个场地的讲座数量（用于删除前校验）
     */
    @Select("SELECT COUNT(*) FROM lectures WHERE venue_id = #{venueId}")
    int countByVenueId(Long venueId);
}