package org.stu.stulecture.entity;

import java.time.LocalDateTime;

/**
 * 用户实体类
 * 手动实现getter/setter方法确保兼容性
 */
public class User {
    private Long userId;        // 用户ID
    private String username;    // 用户名
    private String password;    // 密码
    private String role;        // 角色：admin/teacher/student
    private String name;        // 姓名
    private String email;       // 邮箱
    private String phone;       // 电话
    private String department;  // 院系
    private String major;       // 专业/研究方向
    private String grade;       // 年级
    private String avatar;      // 用户头像路径
    private String bio;         // 个人简介
    private String position;    // 职位
    private Integer status;     // 状态：1启用 0禁用
    private LocalDateTime createdTime;  // 创建时间
    private LocalDateTime updatedTime;  // 更新时间

    // 构造函数
    public User() {}

    public User(String username, String password, String role, String name) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.name = name;
        this.status = 1;
    }

    public User(Long userId, String username, String password, String role, String name, 
                String email, String phone, String department, String major, String grade, 
                String avatar, String bio, String position, Integer status, 
                LocalDateTime createdTime, LocalDateTime updatedTime) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.role = role;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.major = major;
        this.grade = grade;
        this.avatar = avatar;
        this.bio = bio;
        this.position = position;
        this.status = status;
        this.createdTime = createdTime;
        this.updatedTime = updatedTime;
    }

    // Getter方法
    public Long getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getRole() { return role; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getDepartment() { return department; }
    public String getMajor() { return major; }
    public String getGrade() { return grade; }
    public String getAvatar() { return avatar; }
    public String getBio() { return bio; }
    public String getPosition() { return position; }
    public Integer getStatus() { return status; }
    public LocalDateTime getCreatedTime() { return createdTime; }
    public LocalDateTime getUpdatedTime() { return updatedTime; }

    // Setter方法
    public void setUserId(Long userId) { this.userId = userId; }
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
    public void setRole(String role) { this.role = role; }
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setDepartment(String department) { this.department = department; }
    public void setMajor(String major) { this.major = major; }
    public void setGrade(String grade) { this.grade = grade; }
    public void setAvatar(String avatar) { this.avatar = avatar; }
    public void setBio(String bio) { this.bio = bio; }
    public void setPosition(String position) { this.position = position; }
    public void setStatus(Integer status) { this.status = status; }
    public void setCreatedTime(LocalDateTime createdTime) { this.createdTime = createdTime; }
    public void setUpdatedTime(LocalDateTime updatedTime) { this.updatedTime = updatedTime; }

    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", role='" + role + '\'' +
                ", name='" + name + '\'' +
                ", status=" + status +
                '}';
    }
}