package org.stu.stulecture.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.entity.Reservation;
import org.stu.stulecture.service.UserService;
import org.stu.stulecture.util.FileUploadUtil;
import org.stu.stulecture.util.PageInfo;
import org.stu.stulecture.service.ReservationService;
import org.stu.stulecture.service.NotificationService;



import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.List;

/**
 * Thymeleaf版本的用户控制器
 */
@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private ReservationService reservationService;
    
    @Autowired
    private NotificationService notificationService;

    /**
     * 显示首页
     */
    @GetMapping("/")
    public String index(@RequestParam(required = false) Boolean loginSuccess, 
                       Model model, 
                       HttpSession session) {
        model.addAttribute("pageTitle", "首页");
        model.addAttribute("user", session.getAttribute("currentUser"));
        
        if (loginSuccess != null && loginSuccess) {
            model.addAttribute("loginSuccess", true);
        }
        
        return "index";
    }

    /**
     * 显示登录页面
     */
    @GetMapping("/login")
    public String showLoginPage(Model model, HttpSession session) {
        // 如果已登录，重定向到首页
        if (session.getAttribute("currentUser") != null) {
            return "redirect:/";
        }
        
        model.addAttribute("pageTitle", "用户登录");
        return "user/login";
    }

    /**
     * 处理登录请求
     */
    @PostMapping("/login")
    public String login(@RequestParam String username,
                       @RequestParam String password,
                       @RequestParam(required = false) Boolean rememberMe,
                       HttpSession session,
                       HttpServletResponse response,
                       Model model) {

        User user = userService.login(username, password);

        if (user != null) {
            // 登录成功，将用户信息存入session
            session.setAttribute("currentUser", user);
            session.setAttribute("userRole", user.getRole());

            // 首次登录自动激活（仅对未激活用户生效）
            userService.activateUser(user.getUserId());
            // 刷新用户信息
            user = userService.getUserById(user.getUserId());
            session.setAttribute("currentUser", user);
            
            // 检查并发送预约提醒
            checkAndSendReminders(user);

            // 记住我功能
            if (Boolean.TRUE.equals(rememberMe)) {
                userService.rememberMe(user, response);
            }

            // 根据不同角色跳转到不同页面
            switch (user.getRole()) {
                case "admin":
                    return "redirect:/admin/dashboard";
                case "teacher":
                    return "redirect:/teacher/dashboard";
                case "student":
                    return "redirect:/?loginSuccess=true";
                default:
                    return "redirect:/";
            }
        } else {
            // 登录失败
            model.addAttribute("loginError", "用户名或密码错误");
            model.addAttribute("pageTitle", "用户登录");
            return "user/login";
        }
    }

    /**
     * 显示注册页面
     */
    @GetMapping("/register")
    public String showRegisterPage(Model model, HttpSession session) {
        // 如果已登录，重定向到首页
        if (session.getAttribute("currentUser") != null) {
            return "redirect:/";
        }
        
        model.addAttribute("pageTitle", "用户注册");
        return "user/register";
    }

    /**
     * 处理注册请求
     */
    @PostMapping("/register")
    public String register(@RequestParam String username,
                          @RequestParam String password,
                          @RequestParam String confirmPassword,
                          @RequestParam String role,
                          @RequestParam String name,
                          @RequestParam(required = false) String email,
                          @RequestParam(required = false) String phone,
                          @RequestParam(required = false) String department,
                          @RequestParam(required = false) String major,
                          @RequestParam(required = false) String grade,
                          Model model) {
        
        // 管理员和教师不能注册
        if ("admin".equals(role) || "teacher".equals(role)) {
            model.addAttribute("error", "不能注册管理员或教师账号");
            model.addAttribute("pageTitle", "用户注册");
            return "user/register";
        }

        // 验证两次密码是否一致
        if (!password.equals(confirmPassword)) {
            model.addAttribute("error", "两次输入的密码不一致");
            model.addAttribute("pageTitle", "用户注册");
            return "user/register";
        }

        // 创建用户对象
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setRole(role);
        user.setName(name);
        user.setEmail(email);
        user.setPhone(phone);
        user.setDepartment(department);

        // 设置学生专业信息
        user.setMajor(major);
        user.setGrade(grade);

        // 执行注册
        boolean success = userService.register(user);
        
        if (success) {
            model.addAttribute("success", "注册成功，请登录");
            model.addAttribute("pageTitle", "用户登录");
            return "user/login";
        } else {
            model.addAttribute("error", "用户名已存在");
            model.addAttribute("pageTitle", "用户注册");
            return "user/register";
        }
    }

    /**
     * 用户个人中心页面
     */
    @GetMapping("/usercenter")
    public String userCenter(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }
        
        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "个人中心");
        model.addAttribute("active", "usercenter");
        return "user/usercenter";
    }

    /**
     * 更新用户个人信息
     */
    @PostMapping("/updateProfile")
    public String updateProfile(@RequestParam(required = false) String name,
                               @RequestParam(required = false) String email,
                               @RequestParam(required = false) String phone,
                               @RequestParam(required = false) String department,
                               @RequestParam(required = false) String major,
                               @RequestParam(required = false) String grade,
                               @RequestParam(required = false) String position,
                               @RequestParam(required = false) String bio,
                               @RequestParam(required = false) MultipartFile avatar,
                               HttpSession session,
                               Model model) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }
        
        // 验证姓名不能为空
        if (name == null || name.trim().isEmpty()) {
            return "redirect:/user/usercenter?error=" + encodeUrlParam("姓名不能为空");
        }
        
        // 处理头像上传
        if (avatar != null && !avatar.isEmpty()) {
            try {
                String filename = FileUploadUtil.uploadFile(avatar, "src/main/resources/static/avatar");
                // 更新用户头像路径
                currentUser.setAvatar(filename);
            } catch (org.springframework.web.multipart.MaxUploadSizeExceededException e) {
                return "redirect:/user/usercenter?error=" + encodeUrlParam("头像文件大小不能超过 5MB");
            } catch (IOException e) {
                return "redirect:/user/usercenter?error=" + encodeUrlParam("头像上传失败：" + e.getMessage());
            }
        }
        
        // 更新用户信息
        currentUser.setName(name.trim());
        currentUser.setEmail(email);
        currentUser.setPhone(phone);
        currentUser.setDepartment(department);
        currentUser.setMajor(major);
        currentUser.setGrade(grade);
        currentUser.setPosition(position);
        currentUser.setBio(bio);
        
        boolean success = userService.updateUser(currentUser, currentUser.getUserId(), currentUser.getName());
        
        if (success) {
            session.setAttribute("currentUser", currentUser);
            return "redirect:/user/usercenter?success=" + encodeUrlParam("个人信息更新成功");
        } else {
            return "redirect:/user/usercenter?error=" + encodeUrlParam("更新失败，请稍后重试");
        }
    }

    /**
     * 账户安全（修改密码）页面
     */
    @GetMapping("/security")
    public String security(HttpSession session, Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }
        
        model.addAttribute("user", currentUser);
        model.addAttribute("pageTitle", "账户安全");
        model.addAttribute("active", "security");
        return "user/security";
    }
    
    /**
     * 我的预约页面（支持分页）
     */
    @GetMapping("/profile")
    public String profile(HttpSession session, Model model,
                         @RequestParam(defaultValue = "1") Integer pageNum,
                         @RequestParam(defaultValue = "10") Integer pageSize) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }
        
        model.addAttribute("user", currentUser);
        
        // 分页获取用户的预约列表
        PageInfo<Reservation> pageInfo = reservationService.getUserReservationsByPage(currentUser.getUserId(), pageNum, pageSize);
        
        // 过滤出已确认且讲座时间是将来的预约
        long upcomingCount = pageInfo.getList().stream()
            .filter(r -> "confirmed".equals(r.getStatus()) && 
                        r.getLectureTime() != null && 
                        r.getLectureTime().isAfter(java.time.LocalDateTime.now()))
            .count();
        
        model.addAttribute("reservations", pageInfo.getList());
        model.addAttribute("totalReservations", pageInfo.getTotal());
        model.addAttribute("upcomingCount", (int) upcomingCount);
        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("pageNum", pageNum);
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("pageTitle", "我的预约");
        model.addAttribute("active", "profile");
        return "user/profile";
    }

    /**
     * 修改密码
     */
    @PostMapping("/changePassword")
    public String changePassword(@RequestParam String currentPassword,
                                @RequestParam String newPassword,
                                @RequestParam String confirmPassword,
                                HttpSession session,
                                Model model) {
        
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/user/login";
        }
        
        // 验证当前密码
        if (!currentUser.getPassword().equals(currentPassword)) {
            return "redirect:/user/security?error=" + encodeUrlParam("当前密码错误");
        }
        
        // 验证两次密码是否一致
        if (!newPassword.equals(confirmPassword)) {
            return "redirect:/user/security?error=" + encodeUrlParam("两次输入的密码不一致");
        }
        
        // 验证新密码不能与旧密码相同
        if (currentPassword.equals(newPassword)) {
            return "redirect:/user/security?error=" + encodeUrlParam("新密码不能与当前密码相同");
        }
        
        // 更新密码
        boolean success = userService.updatePassword(currentUser.getUserId(), newPassword, currentUser.getUserId(), currentUser.getName());
        
        if (success) {
            currentUser.setPassword(newPassword);
            session.setAttribute("currentUser", currentUser);
            return "redirect:/user/security?success=" + encodeUrlParam("密码修改成功");
        } else {
            return "redirect:/user/security?error=" + encodeUrlParam("密码修改失败");
        }
    }

    /**
     * 用户退出登录
     */
    @GetMapping("/logout")
    public String logout(HttpSession session, HttpServletResponse response) {
        userService.clearRememberMe(response);
        session.invalidate();
        return "redirect:/";
    }
    
    
    /**
     * URL 参数编码辅助方法
     */
    private String encodeUrlParam(String param) {
        try {
            return java.net.URLEncoder.encode(param, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            // UTF-8 总是受支持的，这种情况不会发生
            return param;
        }
    }
    
    /**
     * 检查并发送预约提醒
     */
    private void checkAndSendReminders(User user) {
        List<Reservation> reservations = reservationService.getUserReservations(user.getUserId());
        LocalDateTime now = LocalDateTime.now();
        
        for (Reservation r : reservations) {
            if (r.getLectureTime() == null || !"confirmed".equals(r.getStatus())) continue;
            
            long minutesUntil = ChronoUnit.MINUTES.between(now, r.getLectureTime());
            
            // 1天提醒（24小时内即1440分钟内，且未提醒过）
            if (minutesUntil <= 1440 && minutesUntil > 0 && !r.isReminded1day()) {
                sendReminderNotification(user.getUserId(), r, "reminder_less_1day");
                reservationService.markReminded1day(r.getReservationId());
            }
            
            // 2小时提醒（120分钟内，且未提醒过）
            if (minutesUntil <= 120 && minutesUntil > 0 && !r.isReminded2hours()) {
                sendReminderNotification(user.getUserId(), r, "reminder_less_2hours");
                reservationService.markReminded2hours(r.getReservationId());
            }
        }
    }
    
    /**
     * 发送提醒通知
     */
    private void sendReminderNotification(Long userId, Reservation r, String scene) {
        String timeStr = r.getLectureTime() != null ? 
            r.getLectureTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "待定";
        String location = r.getLocation() != null ? r.getLocation() : "待定";
        
        Map<String, String> variables = new HashMap<>();
        variables.put("lectureTitle", r.getLectureTitle());
        variables.put("lectureTime", timeStr);
        variables.put("location", location);
        
        notificationService.sendTemplateNotification(scene, variables, userId, null);
    }
}