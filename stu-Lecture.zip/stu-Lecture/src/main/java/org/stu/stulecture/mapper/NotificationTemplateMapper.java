package org.stu.stulecture.mapper;

import org.apache.ibatis.annotations.*;
import org.stu.stulecture.entity.NotificationTemplate;

import java.util.List;

/**
 * 通知模板 Mapper 接口
 */
@Mapper
public interface NotificationTemplateMapper {
    
    /**
     * 查询所有模板
     */
    @Select("SELECT template_id, template_name, type, scene, title_template, content_template, " +
            "is_enabled, created_time, updated_time " +
            "FROM notification_templates ORDER BY type, scene")
    @Results({
        @Result(property = "templateId", column = "template_id"),
        @Result(property = "templateName", column = "template_name"),
        @Result(property = "type", column = "type"),
        @Result(property = "scene", column = "scene"),
        @Result(property = "titleTemplate", column = "title_template"),
        @Result(property = "contentTemplate", column = "content_template"),
        @Result(property = "isEnabled", column = "is_enabled"),
        @Result(property = "createdTime", column = "created_time"),
        @Result(property = "updatedTime", column = "updated_time")
    })
    List<NotificationTemplate> findAll();
    
    /**
     * 根据 ID 查询模板
     */
    @Select("SELECT template_id, template_name, type, scene, title_template, content_template, " +
            "is_enabled, created_time, updated_time " +
            "FROM notification_templates WHERE template_id = #{templateId}")
    @Results({
        @Result(property = "templateId", column = "template_id"),
        @Result(property = "templateName", column = "template_name"),
        @Result(property = "type", column = "type"),
        @Result(property = "scene", column = "scene"),
        @Result(property = "titleTemplate", column = "title_template"),
        @Result(property = "contentTemplate", column = "content_template"),
        @Result(property = "isEnabled", column = "is_enabled"),
        @Result(property = "createdTime", column = "created_time"),
        @Result(property = "updatedTime", column = "updated_time")
    })
    NotificationTemplate findById(@Param("templateId") Long templateId);
    
    /**
     * 根据场景查询模板
     */
    @Select("SELECT template_id, template_name, type, scene, title_template, content_template, " +
            "is_enabled, created_time, updated_time " +
            "FROM notification_templates WHERE scene = #{scene} AND is_enabled = 1")
    @Results({
        @Result(property = "templateId", column = "template_id"),
        @Result(property = "templateName", column = "template_name"),
        @Result(property = "type", column = "type"),
        @Result(property = "scene", column = "scene"),
        @Result(property = "titleTemplate", column = "title_template"),
        @Result(property = "contentTemplate", column = "content_template"),
        @Result(property = "isEnabled", column = "is_enabled"),
        @Result(property = "createdTime", column = "created_time"),
        @Result(property = "updatedTime", column = "updated_time")
    })
    NotificationTemplate findByScene(@Param("scene") String scene);
    
    /**
     * 更新模板
     */
    @Update("UPDATE notification_templates SET " +
            "title_template = #{titleTemplate}, " +
            "content_template = #{contentTemplate}, " +
            "is_enabled = #{isEnabled}, " +
            "updated_time = NOW() " +
            "WHERE template_id = #{templateId}")
    int update(NotificationTemplate template);
}
