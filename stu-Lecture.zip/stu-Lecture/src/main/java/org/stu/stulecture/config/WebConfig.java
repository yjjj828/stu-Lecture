package org.stu.stulecture.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.stu.stulecture.config.RememberMeInterceptor;

import java.nio.file.Paths;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    private RememberMeInterceptor rememberMeInterceptor;

    @Autowired
    private NotificationInterceptor notificationInterceptor;

    @Autowired
    private PermissionInterceptor permissionInterceptor;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 配置静态资源映射 - 包括编译后的目录和开发时的源码目录
        registry.addResourceHandler("/**")
                .addResourceLocations(
                    "classpath:/static/",
                    "file:" + Paths.get(System.getProperty("user.dir"), "src/main/resources/static/").toAbsolutePath() + "/"
                );
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // 注册记住我拦截器（最先执行）
        registry.addInterceptor(rememberMeInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns(
                    "/user/login",
                    "/user/register",
                    "/css/**",
                    "/js/**",
                    "/images/**",
                    "/icons/**",
                    "/avatar/**",
                    "/poster/**"
                );

        // 注册权限验证拦截器（第二个执行）
        registry.addInterceptor(permissionInterceptor)
                .addPathPatterns("/admin/**", "/teacher/**")
                .excludePathPatterns(
                    "/css/**",
                    "/js/**",
                    "/images/**",
                    "/icons/**",
                    "/avatar/**",
                    "/poster/**"
                );

        // 注册通知未读数量拦截器（最后执行）
        registry.addInterceptor(notificationInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns(
                    "/user/login",
                    "/user/register",
                    "/css/**",
                    "/js/**",
                    "/images/**",
                    "/icons/**",
                    "/avatar/**",
                    "/poster/**"
                );
    }
}
