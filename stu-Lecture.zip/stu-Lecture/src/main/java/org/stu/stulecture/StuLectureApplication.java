package org.stu.stulecture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StuLectureApplication {

    public static void main(String[] args) {
        SpringApplication.run(StuLectureApplication.class, args);
    }

}
