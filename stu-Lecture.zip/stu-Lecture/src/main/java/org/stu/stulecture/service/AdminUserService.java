package org.stu.stulecture.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.stu.stulecture.entity.User;
import org.stu.stulecture.entity.OperationLog;
import org.stu.stulecture.mapper.UserMapper;
import org.stu.stulecture.mapper.OperationLogMapper;
import org.stu.stulecture.util.PageInfo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * 管理员用户管理
 */
@Service
public class AdminUserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private OperationLogMapper operationLogMapper;

    /**
     * 查询全部用户
     */
    public List<User> getAllUsers() {
        return userMapper.findAll();
    }

    /**
     * 按ID查询用户
     */
    public User getUserById(Long userId) {
        return userMapper.findById(userId);
    }

    /**
     * 按账号搜索用户
     */
    public List<User> searchUsersByUsername(String username) {
        User user = userMapper.findByUsername(username);
        return user != null ? java.util.Collections.singletonList(user) : java.util.Collections.emptyList();
    }

    /**
     * 按角色筛选用户
     */
    public List<User> getUsersByRole(String role) {
        return userMapper.findByRole(role);
    }

    /**
     * 按状态筛选用户
     */
    public List<User> getUsersByStatus(Integer status) {
        return userMapper.findByStatus(status);
    }

    /**
     * 多条件搜索
     */
    public List<User> searchUsers(String username, String role, Integer status) {
        return userMapper.searchUsers(username, role, status);
    }

    /**
     * 分页查询用户
     */
    public PageInfo<User> searchUsersByPage(String username, String role, Integer status,
                                            int pageNum, int pageSize) {
        int offset = (pageNum - 1) * pageSize;
        
        List<User> users = userMapper.searchUsersByPage(username, role, status, offset, pageSize);
        int total = userMapper.countSearchUsers(username, role, status);
        
        return new PageInfo<>(users, pageNum, pageSize, total);
    }

    /**
     * 拼接用户显示名：账号+姓名
     */
    private String formatUserName(Long userId) {
        if (userId == null) {
            return "系统";
        }
        User user = userMapper.findById(userId);
        if (user == null) {
            return "用户 ID:" + userId;
        }
        if (user.getName() != null && !user.getName().isEmpty()) {
            return user.getUsername() + "（" + user.getName() + "）";
        }
        return user.getUsername();
    }
    
    /**
     * 修改用户信息
     */
    @Transactional
    public boolean updateUser(User user, Long operatorId, String operatorName) {
        User targetUser = userMapper.findById(user.getUserId());
        if (targetUser == null) {
            return false;
        }
        
        boolean result = userMapper.update(user) > 0;
        if (result) {
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "更新用户信息", "用户管理", 
                "更新用户 [" + targetUser.getUsername() + "] 的基本信息");
            operationLogMapper.insert(log);
        }
        return result;
    }

    /**
     * 重置密码为默认值
     */
    @Transactional
    public boolean resetUserPassword(Long userId, Long operatorId, String operatorName) {
        User user = userMapper.findById(userId);
        if (user == null) {
            return false;
        }
        
        String defaultPassword = "123456";
        boolean result = userMapper.updatePassword(userId, defaultPassword) > 0;
        
        if (result) {
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "重置用户密码", "用户管理", 
                "将用户 [" + user.getUsername() + "] 的密码重置为默认密码");
            operationLogMapper.insert(log);
        }
        return result;
    }

    /**
     * 启用账号
     */
    @Transactional
    public boolean enableUser(Long userId, Long operatorId, String operatorName) {
        User user = new User();
        user.setUserId(userId);
        user.setStatus(1);
            
        boolean result = userMapper.update(user) > 0;
        if (result) {
            User updatedUser = userMapper.findById(userId);
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "启用用户账号", "用户管理", 
                "启用用户 [" + updatedUser.getUsername() + "] 的账号");
            operationLogMapper.insert(log);
        }
        return result;
    }

    /**
     * 禁用账号
     */
    @Transactional
    public boolean disableUser(Long userId, Long operatorId, String operatorName) {
        User user = new User();
        user.setUserId(userId);
        user.setStatus(0);
            
        boolean result = userMapper.update(user) > 0;
        if (result) {
            User updatedUser = userMapper.findById(userId);
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "禁用用户账号", "用户管理", 
                "禁用用户 [" + updatedUser.getUsername() + "] 的账号");
            operationLogMapper.insert(log);
        }
        return result;
    }

    /**
     * 变更用户角色
     */
    @Transactional
    public boolean changeUserRole(Long userId, String newRole, Long operatorId, String operatorName) {
        User user = userMapper.findById(userId);
        if (user == null) {
            return false;
        }
        
        String oldRole = user.getRole();
        user.setRole(newRole);
        
        boolean result = userMapper.update(user) > 0;
        if (result) {
            // 记录操作日志
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "变更用户角色", "用户管理", 
                "将用户 [" + user.getUsername() + "] 的角色从 [" + oldRole + "] 变更为 [" + newRole + "]");
            operationLogMapper.insert(log);
        }
        return result;
    }
    
    /**
     * 添加用户（管理员添加，默认未激活）
     */
    @Transactional
    public boolean addUser(String username, String password, String name, String role, 
                          String email, String department, Long operatorId, String operatorName) {
        // 检查用户名是否已存在
        if (userMapper.findByUsername(username) != null) {
            return false;
        }
        
        // 创建用户对象
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setName(name);
        user.setRole(role);
        user.setEmail(email);
        user.setDepartment(department);
        user.setStatus(0); // 默认未激活
        
        boolean result = userMapper.insert(user) > 0;
        if (result) {
            // 记录操作日志
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "添加用户", "用户管理", 
                "添加用户 [" + username + "]（" + name + "），角色：" + role + "，状态：未激活");
            operationLogMapper.insert(log);
        }
        return result;
    }

    /**
     * 删除用户
     */
    @Transactional
    public boolean deleteUser(Long userId, Long operatorId, String operatorName) {
        User user = userMapper.findById(userId);
        if (user == null) {
            return false;
        }
        
        // 管理员不能删除自己
        if (userId.equals(operatorId) && "admin".equals(user.getRole())) {
            return false;
        }
        
        boolean result = userMapper.deleteById(userId) > 0;
        if (result) {
            // 记录操作日志
            OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
                "删除用户", "用户管理", 
                "删除用户 [" + user.getUsername() + "]");
            operationLogMapper.insert(log);
        }
        return result;
    }

    /**
     * 获取操作日志
     */
    public List<OperationLog> getOperationLogs() {
        return operationLogMapper.findAll();
    }

    /**
     * 根据条件搜索操作日志
     */
  public List<OperationLog> searchOperationLogs(String username, String operation, String module, String logDate) {
       return operationLogMapper.searchLogs(username, operation, module, logDate);
   }

    /**
     * 分页查询操作日志
     */
    public PageInfo<OperationLog> searchOperationLogsByPage(String username, String operation, String module, 
                                                           String logDate, int pageNum, int pageSize) {
        // 计算偏移量
        int offset = (pageNum - 1) * pageSize;
        
        // 查询当前页数据
        List<OperationLog> logs = operationLogMapper.searchLogsByPage(username, operation, module, logDate, offset, pageSize);
        
        // 查询总记录数
        int total = operationLogMapper.countSearchLogs(username, operation, module, logDate);
        
        // 封装分页信息
        return new PageInfo<>(logs, pageNum, pageSize, total);
    }

    /**
     * 根据时间范围查询操作日志
     */
    public List<OperationLog> getOperationLogsByTimeRange(LocalDateTime startTime, LocalDateTime endTime) {
        return operationLogMapper.findByTimeRange(startTime, endTime);
    }

    /**
     * 清理指定时间之前的日志
     */
    @Transactional
    public int cleanOldLogs(LocalDateTime beforeTime, Long operatorId, String operatorName) {
        int deletedCount = operationLogMapper.deleteBeforeTime(beforeTime);
        
        // 记录清理操作日志
        OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
            "清理操作日志", "系统管理", 
            "清理 [" + beforeTime + "] 之前的日志，共删除 " + deletedCount + " 条记录");
        operationLogMapper.insert(log);
        
        return deletedCount;
    }
    
    /**
     * 导出预约名单（记录日志）
     */
    public void logExportReservations(Long lectureId, String lectureTitle, int count, Long operatorId) {
        OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
            "导出预约名单", "预约管理", 
            "导出讲座 [" + lectureTitle + "] 的预约名单，共 " + count + " 人");
        operationLogMapper.insert(log);
    }
    
    /**
     * 导出操作日志（记录日志）
     */
    public void logExportLogs(int count, Long operatorId) {
        OperationLog log = new OperationLog(operatorId, formatUserName(operatorId), 
            "导出操作日志", "系统管理", 
            "导出操作日志，共 " + count + " 条记录");
        operationLogMapper.insert(log);
    }

    /**
     * 获取用户统计数据
     */
    public UserStatistics getUserStatistics() {
        List<User> allUsers = getAllUsers();
        
        long totalUsers = allUsers.size();
        long activeUsers = allUsers.stream().filter(u -> u.getStatus() == 1).count();
        long adminUsers = allUsers.stream().filter(u -> "admin".equals(u.getRole())).count();
        long teacherUsers = allUsers.stream().filter(u -> "teacher".equals(u.getRole())).count();
        long studentUsers = allUsers.stream().filter(u -> "student".equals(u.getRole())).count();
        
        return new UserStatistics(totalUsers, activeUsers, adminUsers, teacherUsers, studentUsers);
    }
    
    /**
     * 获取总用户数
     */
    public int getTotalUserCount() {
        return userMapper.countTotal();
    }
    
    /**
     * 根据角色统计用户数
     */
    public int getUserCountByRole(String role) {
        return userMapper.countByRole(role);
    }
    
    /**
     * 根据状态统计用户数
     */
    public int getUserCountByStatus(Integer status) {
        return userMapper.countByStatus(status);
    }

    /**
     * 用户统计内部类
     */
    public static class UserStatistics {
        private long totalUsers;
        private long activeUsers;
        private long adminUsers;
        private long teacherUsers;
        private long studentUsers;

        public UserStatistics(long totalUsers, long activeUsers, long adminUsers, long teacherUsers, long studentUsers) {
            this.totalUsers = totalUsers;
            this.activeUsers = activeUsers;
            this.adminUsers = adminUsers;
            this.teacherUsers = teacherUsers;
            this.studentUsers = studentUsers;
        }

        // Getter方法
        public long getTotalUsers() { return totalUsers; }
        public long getActiveUsers() { return activeUsers; }
        public long getAdminUsers() { return adminUsers; }
        public long getTeacherUsers() { return teacherUsers; }
        public long getStudentUsers() { return studentUsers; }
    }
}