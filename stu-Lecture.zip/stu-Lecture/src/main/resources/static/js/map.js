/**
 * 地图查看模块 - 学术讲座与报告预约管理系统
 */

/**
 * 查看地图大图
 * 在新窗口中打开校园地图
 */
function viewMap() {
    const mapImg = document.querySelector('.map-container img');
    if (mapImg) {
        const src = mapImg.src;
        const newWindow = window.open('', '_blank');
        if (newWindow) {
            newWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>校园场地分布图</title>
                    <style>
                        body {
                            margin: 0;
                            padding: 20px;
                            background: #f5f5f5;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            min-height: 100vh;
                        }
                        img {
                            max-width: 100%;
                            height: auto;
                            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                            border-radius: 8px;
                        }
                    </style>
                </head>
                <body>
                    <img src="${src}" alt="校园地图">
                </body>
                </html>
            `);
            newWindow.document.close();
        }
    }
}
