// 场地管理模块 - 学术讲座与报告预约管理系统

// 根据场地更新地点显示
function updateLocation(select) {
    const selectedOption = select.options[select.selectedIndex];
    const location = selectedOption.dataset.location;
    
    if (location) {
        const locationInput = document.getElementById('locationDisplay');
        if (locationInput) {
            locationInput.value = location;
        }
    }
}

// 预览海报图片
function previewPoster(input) {
    const file = input.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const posterPreview = document.getElementById('posterPreview');
        if (posterPreview) {
            // 查找已有的 img 标签
            let img = posterPreview.querySelector('img');
            const placeholder = posterPreview.querySelector('span');
            
            if (!img) {
                // 如果没有 img，创建一个新的
                img = document.createElement('img');
                img.style.maxWidth = '100%';
                img.style.maxHeight = '100%';
                img.style.objectFit = 'contain';
                img.style.borderRadius = '6px';
                posterPreview.insertBefore(img, posterPreview.firstChild);
            }
            
            // 设置新图片
            img.src = e.target.result;
            img.style.display = 'block';
            
            // 隐藏占位文字
            if (placeholder) placeholder.style.display = 'none';
        }
    };
    reader.readAsDataURL(file);
}
