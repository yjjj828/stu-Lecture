// 登录注册验证模块 - 学术讲座与报告预约管理系统

// 初始化登录页面
function initLoginPage() {
    const form = document.querySelector('form');
    const errorContainer = document.getElementById('errorContainer');
    
    if (form && errorContainer) {
        form.addEventListener('submit', function() {
            errorContainer.innerHTML = '';
        });
    }
}

// 初始化注册页面
function initRegisterPage() {
    // Thymeleaf 已处理提示显示，此处无需额外逻辑
}

// 密码确认验证
function validatePasswordMatch(e) {
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirmPassword');
    
    if (password && confirmPassword) {
        if (password.value !== confirmPassword.value) {
            e.preventDefault();
            alert('两次输入的密码不一致');
            return false;
        }
        
        if (password.value.length < 6) {
            e.preventDefault();
            alert('密码长度至少 6 位');
            return false;
        }
    }
    
    return true;
}

// 年级字段根据角色动态显示
function initRoleSelector() {
    const roleRadios = document.querySelectorAll('input[name="role"]');
    
    roleRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            const gradeField = document.querySelector('input[name="grade"]');
            if (gradeField) {
                const gradeGroup = gradeField.closest('.form-group');
                
                if (this.value === 'student') {
                    if (gradeGroup) gradeGroup.style.display = 'block';
                    gradeField.required = true;
                } else {
                    if (gradeGroup) gradeGroup.style.display = 'none';
                    gradeField.required = false;
                    gradeField.value = '';
                }
            }
        });
    });
}

// 页面加载时初始化
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('errorContainer')) {
        initLoginPage();
    }
    
    if (document.getElementById('messageContainer')) {
        initRegisterPage();
        initRoleSelector();
        
        const form = document.querySelector('form');
        if (form) {
            form.addEventListener('submit', validatePasswordMatch);
        }
    }
});
