// 轮播图模块 - 学术讲座与报告预约管理系统

// 全局变量
let currentSlideIndex = 0;
let autoPlayInterval = null;

// 初始化轮播图
function initCarousel() {
    const items = document.querySelectorAll('.carousel-item');
    if (items.length <= 1) {
        const indicators = document.getElementById('carouselIndicators');
        if (indicators) {
            indicators.style.display = 'none';
        }
        return;
    }
    startAutoPlay();
}

// 切换到指定幻灯片
function switchSlide(index) {
    const items = document.querySelectorAll('.carousel-item');
    const dots = document.querySelectorAll('.indicator-dot');
    if (items.length === 0) return;

    if (index < 0) index = items.length - 1;
    if (index >= items.length) index = 0;

    items.forEach(item => item.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));

    items[index].classList.add('active');
    if (dots[index]) {
        dots[index].classList.add('active');
    }

    currentSlideIndex = index;
}

// 下一张幻灯片
function nextSlide() {
    switchSlide(currentSlideIndex + 1);
}

// 上一张幻灯片
function prevSlide() {
    switchSlide(currentSlideIndex - 1);
}

// 跳转到指定幻灯片
function goToSlide(index) {
    switchSlide(index);
}

// 开始自动播放
function startAutoPlay() {
    if (autoPlayInterval) {
        clearInterval(autoPlayInterval);
    }
    autoPlayInterval = setInterval(nextSlide, 4000);
}

// 停止自动播放
function stopAutoPlay() {
    if (autoPlayInterval) {
        clearInterval(autoPlayInterval);
        autoPlayInterval = null;
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    initCarousel();

    const carousel = document.getElementById('lectureCarousel');
    if (carousel) {
        carousel.addEventListener('mouseenter', stopAutoPlay);
        carousel.addEventListener('mouseleave', startAutoPlay);
    }
});
