// 审核管理模块 - 学术讲座与报告预约管理系统

// 通过审核
function approveLecture(lectureId) {
    if (confirm('确定要通过这个讲座吗？')) {
        submitReviewFormWithReason(lectureId, 'approve', null);
    }
}

// 拒绝审核
function rejectLecture(lectureId) {
    const reason = prompt('请输入拒绝理由：\n（请详细说明拒绝原因，方便教师修改）', 
                         '内容不完整/信息有误，请补充完善后重新提交');
    
    if (reason === null) return;
    
    if (reason.trim() !== '') {
        submitReviewFormWithReason(lectureId, 'reject', reason.trim());
    } else {
        alert('拒绝理由不能为空！');
        rejectLecture(lectureId);
    }
}

// 执行审核操作
function submitReviewFormWithReason(lectureId, action, reason) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '/admin/lectures/review/' + lectureId;
    
    const actionInput = document.createElement('input');
    actionInput.type = 'hidden';
    actionInput.name = 'action';
    actionInput.value = action;
    form.appendChild(actionInput);
    
    if (reason !== null) {
        const reasonInput = document.createElement('input');
        reasonInput.type = 'hidden';
        reasonInput.name = 'rejectReason';
        reasonInput.value = reason;
        form.appendChild(reasonInput);
    }
    
    document.body.appendChild(form);
    form.submit();
}

// 检查审核结果提示
function checkReviewResultMessage() {
    const urlParams = new URLSearchParams(window.location.search);
    const success = urlParams.get('success');
    const error = urlParams.get('error');
    
    if (success === '1') {
        showSuccess('讲座已通过审核');
    } else if (success === '2') {
        showSuccess('讲座已拒绝');
    } else if (error) {
        showError('操作失败，请稍后重试');
    }
    
    if (success || error) {
        history.replaceState({}, document.title, window.location.pathname);
    }
}

// 页面加载时检查
document.addEventListener('DOMContentLoaded', function() {
    checkReviewResultMessage();
});
