// 通知管理模块 - 学术讲座与报告预约管理系统

// 全选/取消全选
function toggleSelectAll(selectAllId, checkboxName) {
    const selectAllCheckbox = document.getElementById(selectAllId);
    const checkboxes = document.querySelectorAll('input[name="' + checkboxName + '"]');
    
    if (!checkboxes || checkboxes.length === 0) return;
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAllCheckbox.checked;
    });
    
    if (typeof window.updateBatchDeleteButton === 'function') {
        window.updateBatchDeleteButton();
    }
}

// 批量删除
function batchDelete(checkboxName, actionUrl, paramName) {
    checkboxName = checkboxName || window.batchCheckboxName || 'notificationIds';
    actionUrl = actionUrl || window.batchActionUrl || '/admin/notifications/batch-delete';
    paramName = paramName || 'ids';
    
    const checkboxes = document.querySelectorAll('input[name="' + checkboxName + '"]:checked');
    
    if (checkboxes.length === 0) {
        alert('请至少选择一条记录');
        return;
    }
    
    if (confirm('确定要删除选中的 ' + checkboxes.length + ' 条吗？此操作无法恢复！')) {
        submitBatchForm(checkboxes, 'POST', actionUrl, paramName);
    }
}

// 批量标记已读
function batchMarkAsRead(checkboxName, actionUrl, paramName) {
    checkboxName = checkboxName || window.batchCheckboxName || 'notificationIds';
    actionUrl = actionUrl || window.batchActionUrl || '/notification/batch-mark-read';
    paramName = paramName || 'ids';
    
    const checkboxes = document.querySelectorAll('input[name="' + checkboxName + '"]:checked');
    
    if (checkboxes.length === 0) {
        alert('请至少选择一条通知');
        return;
    }
    
    if (confirm('确定要将选中的 ' + checkboxes.length + ' 条通知标记为已读吗？')) {
        submitBatchForm(checkboxes, 'POST', actionUrl, paramName);
    }
}

// 提交批量操作表单
function submitBatchForm(checkboxes, method, action, paramName) {
    const ids = Array.from(checkboxes).map(cb => cb.value);
    
    const form = document.createElement('form');
    form.method = method;
    form.action = action;
    
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = paramName;
    input.value = ids.join(',');
    form.appendChild(input);
    
    if (window.batchExtraParams) {
        for (const key in window.batchExtraParams) {
            const extraInput = document.createElement('input');
            extraInput.type = 'hidden';
            extraInput.name = key;
            extraInput.value = window.batchExtraParams[key];
            form.appendChild(extraInput);
        }
    }
    
    document.body.appendChild(form);
    form.submit();
}
