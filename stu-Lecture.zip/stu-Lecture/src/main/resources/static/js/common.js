// 公共JavaScript函数 - 学术讲座与报告预约管理系统

// 获取上下文路径
function getContextPath() {
    return window.location.pathname.substring(0, window.location.pathname.indexOf("/", 2));
}

// 显示成功提示
function showSuccess(message) {
    showMessage(message, 'success');
}

// 显示错误提示
function showError(message) {
    showMessage(message, 'error');
}

// 显示警告提示
function showWarning(message) {
    showMessage(message, 'warning');
}

// 显示信息提示
function showInfo(message) {
    showMessage(message, 'info');
}

// 通用消息提示函数
function showMessage(message, type) {
    // 创建提示元素
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <span class="toast-icon">${getToastIcon(type)}</span>
        <span class="toast-message">${message}</span>
    `;
    
    // 添加样式
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 9999;
        animation: slideIn 0.3s ease;
        border-left: 4px solid ${getToastColor(type)};
    `;
    
    document.body.appendChild(toast);
    
    // 3秒后自动移除
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}

// 获取提示图标
function getToastIcon(type) {
    const icons = {
        success: '✓',
        error: '✕',
        warning: '⚠',
        info: 'ℹ'
    };
    return icons[type] || 'ℹ';
}

// 获取提示颜色
function getToastColor(type) {
    const colors = {
        success: '#2ecc71',
        error: '#e74c3c',
        warning: '#f39c12',
        info: '#3498db'
    };
    return colors[type] || '#3498db';
}

// 添加动画样式
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// 表单验证
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;
    
    let isValid = true;
    const inputs = form.querySelectorAll('[required]');
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            isValid = false;
            input.style.borderColor = '#e74c3c';
            
            // 显示错误提示
            let errorMsg = input.nextElementSibling;
            if (!errorMsg || !errorMsg.classList.contains('form-error')) {
                errorMsg = document.createElement('div');
                errorMsg.className = 'form-error';
                input.parentNode.insertBefore(errorMsg, input.nextSibling);
            }
            errorMsg.textContent = '此字段不能为空';
        } else {
            input.style.borderColor = '#e1e8ed';
            const errorMsg = input.nextElementSibling;
            if (errorMsg && errorMsg.classList.contains('form-error')) {
                errorMsg.remove();
            }
        }
    });
    
    return isValid;
}

// 邮箱验证
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// 格式化日期
function formatDate(dateString) {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// 格式化时间
function formatDateTime(dateString) {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}`;
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 为所有表单添加验证
    const forms = document.querySelectorAll('form[data-validate="true"]');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(form.id)) {
                e.preventDefault();
                showError('请填写所有必填项');
            }
        });
    });
    
    // 汉堡菜单切换功能
    const menuToggle = document.getElementById('menuToggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            navMenu.classList.toggle('mobile-show');
            
            // 切换 aria-expanded 属性
            const isExpanded = navMenu.classList.contains('mobile-show');
            menuToggle.setAttribute('aria-expanded', isExpanded);
        });
        
        // 点击菜单外部区域时关闭菜单
        document.addEventListener('click', function(e) {
            if (navMenu.classList.contains('mobile-show') && 
                !navMenu.contains(e.target) && 
                !menuToggle.contains(e.target)) {
                navMenu.classList.remove('mobile-show');
                menuToggle.setAttribute('aria-expanded', 'false');
            }
        });
        
        // 点击菜单链接时关闭菜单
        const menuLinks = navMenu.querySelectorAll('a');
        menuLinks.forEach(link => {
            link.addEventListener('click', function() {
                navMenu.classList.remove('mobile-show');
                menuToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }
});

/**
 * 清除 URL 参数
 * @param {number} delay - 延迟清除时间（毫秒）
 */
function clearUrlParams(delay = 3000) {
    setTimeout(function() {
        window.history.replaceState({}, document.title, window.location.pathname);
    }, delay);
}

/**
 * 检查并显示 URL 参数中的提示信息
 * 自动识别 success 和 error 参数
 */
function checkUrlParamsForMessage() {
    const urlParams = new URLSearchParams(window.location.search);
    const success = urlParams.get('success');
    const error = urlParams.get('error');
    
    // 纯数字参数不显示（兼容旧逻辑），仅处理含中文的文案参数
    if (success && !/^\d+$/.test(success)) {
        showSuccess(decodeURIComponent(success));
        clearUrlParams();
    } else if (error && !/^\d+$/.test(error)) {
        showError(decodeURIComponent(error));
        clearUrlParams();
    }
}

/**
 * 统一的模态框控制函数
 */
const ModalUtil = {
    /**
     * 打开模态框
     * @param {string} modalId - 模态框 ID
     */
    open: function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden'; // 防止背景滚动
        }
    },
    
    /**
     * 关闭模态框
     * @param {string} modalId - 模态框 ID
     */
    close: function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = ''; // 恢复背景滚动
        }
    },
    
    /**
     * 初始化模态框关闭功能
     * @param {string} modalId - 模态框 ID
     */
    initClose: function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            // 点击模态框外部关闭
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    this.close(modalId);
                }
            }.bind(this));
        }
    }
};

// ===== 分页相关函数 =====

/**
 * 改变每页显示数量（通用分页功能）
 * 自动保留当前搜索参数，只修改 pageSize 和 pageNum
 * 
 * @param {number} newPageSize - 新的每页数量
 */
function changePageSize(newPageSize) {
    const url = new URL(window.location.href);
    
    // 设置分页参数
    url.searchParams.set('pageSize', newPageSize);
    url.searchParams.set('pageNum', '1'); // 重置到第一页
    
    window.location.href = url.toString();
}

/**
 * 跳转到指定页码
 * 
 * @param {number} pageNum - 目标页码
 */
function goToPage(pageNum) {
    const url = new URL(window.location.href);
    url.searchParams.set('pageNum', pageNum);
    window.location.href = url.toString();
}

/**
 * 跳转到首页
 */
function goToFirstPage() {
    goToPage(1);
}

/**
 * 跳转到末页
 */
function goToLastPage(totalPages) {
    goToPage(totalPages);
}

/**
 * 上一页
 */
function goToPreviousPage(currentPage) {
    if (currentPage > 1) {
        goToPage(currentPage - 1);
    }
}

/**
 * 下一页
 */
function goToNextPage(currentPage, totalPages) {
    if (currentPage < totalPages) {
        goToPage(currentPage + 1);
    }
}

/**
 * 动态加载未读通知数量（用于页面初始加载）
 */
function loadUnreadCount() {
    fetch('/notification/unread-count')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const badge = document.getElementById('unread-badge');
                if (badge) {
                    if (data.count > 0) {
                        badge.textContent = data.count;
                        badge.style.display = 'inline-block';
                    } else {
                        badge.style.display = 'none';
                    }
                }
            }
        })
        .catch(error => {
            console.error('加载未读数失败:', error);
        });
}

/**
 * 启用页面自动刷新
 * @param {number} interval - 刷新间隔（毫秒），默认 60000ms（1 分钟）
 */
function enableAutoRefresh(interval) {
    if (interval === undefined || interval === null) {
        interval = 60000; // 默认 1 分钟
    }
    
    setTimeout(function() {
        console.log('页面自动刷新...');
        location.reload();
    }, interval);
}

/**
 * 批量删除操作
 * @param {string} checkboxName - 复选框 name 属性
 * @param {string} actionUrl - 删除操作 URL
 */
function batchDelete(checkboxName, actionUrl) {
    const checkboxes = document.querySelectorAll(`input[name="${checkboxName}"]:checked`);
    
    if (checkboxes.length === 0) {
        showError('请至少选择一项');
        return;
    }
    
    if (!confirm(`确定要删除选中的 ${checkboxes.length} 项吗？此操作不可恢复！`)) {
        return;
    }
    
    // 收集所有选中的 ID
    const ids = Array.from(checkboxes).map(cb => cb.value).join(',');
    
    // 创建临时表单并提交
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = actionUrl;
    
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'ids';
    input.value = ids;
    
    form.appendChild(input);
    document.body.appendChild(form);
    form.submit();
}

/**
 * 全选/取消全选
 * @param {string} selectAllId - 全选复选框 ID
 * @param {string} checkboxName - 子复选框的 name 属性
 */
function toggleSelectAll(selectAllId, checkboxName) {
    const selectAll = document.getElementById(selectAllId);
    const checkboxes = document.querySelectorAll(`input[name="${checkboxName}"]`);
    
    checkboxes.forEach(cb => {
        cb.checked = selectAll.checked;
    });
    
    // 触发更新批量删除按钮状态
    if (typeof window.updateBatchDeleteButton === 'function') {
        window.updateBatchDeleteButton();
    }
}

/**
 * 更新批量删除按钮显示状态（标准实现）
 * 依赖全局变量：window.batchCheckboxName, window.batchActionUrl
 */
function updateBatchDeleteButton() {
    const checkboxName = window.batchCheckboxName || 'ids';
    const checkboxes = document.querySelectorAll(`input[name="${checkboxName}"]:checked`);
    const count = checkboxes.length;
    const btn = document.getElementById('batchDeleteBtn');
    
    if (btn) {
        btn.style.display = count > 0 ? 'inline-block' : 'none';
        btn.textContent = count > 0 ? `批量删除 (${count})` : '批量删除';
    }
}
