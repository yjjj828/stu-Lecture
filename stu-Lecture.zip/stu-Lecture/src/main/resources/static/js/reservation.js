// 预约管理模块 - 学术讲座与报告预约管理系统

// 取消预约
function cancelReservation(reservationId) {
    if (!confirm('确定要取消这个预约吗？')) {
        return;
    }
    
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '/lecture/cancel/' + reservationId;
    document.body.appendChild(form);
    form.submit();
}

// 预约讲座
function bookLecture(lectureId) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '/lecture/book/' + lectureId;
    document.body.appendChild(form);
    form.submit();
}

// 返回上一页并刷新
function goBackWithRefresh() {
    const referrer = document.referrer;
    if (referrer) {
        window.location.replace(referrer);
    } else {
        window.location.href = '/';
    }
}

// 检查 URL 参数显示提示消息
function checkUrlParamsForMessage(messageMap) {
    const urlParams = new URLSearchParams(window.location.search);
    const success = urlParams.get('success');
    const error = urlParams.get('error');
    
    if (success && messageMap && messageMap.success && messageMap.success[success]) {
        showSuccess(messageMap.success[success]);
    } else if (error && messageMap && messageMap.error && messageMap.error[error]) {
        showError(messageMap.error[error]);
    }
    
    if (success || error) {
        history.replaceState({}, document.title, window.location.pathname);
    }
}
