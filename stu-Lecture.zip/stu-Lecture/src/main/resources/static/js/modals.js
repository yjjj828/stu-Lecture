// 模态框通用模块 - 学术讲座与报告预约管理系统

// 关闭模态框
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

// 初始化所有模态框
function initAllModals() {
    const modals = document.querySelectorAll('.modal');
    
    modals.forEach(modal => {
        const modalId = modal.id;
        if (modalId) {
            modal.addEventListener('click', function(event) {
                if (event.target === modal) {
                    closeModal(modalId);
                }
            });
        }
    });
}

// 页面加载时初始化
document.addEventListener('DOMContentLoaded', function() {
    initAllModals();
});
