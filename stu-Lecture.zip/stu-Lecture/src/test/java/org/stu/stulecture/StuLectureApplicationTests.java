package org.stu.stulecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StuLectureApplicationTests {

    @Test
    void contextLoads() {
    }

}
